# Locked partial spatial replication: GSE283052

Locked 8 October 2026 after archive-format and gene-coverage audit, before
computing any GSE283052 IS/SS scores or neighborhood effects.

## Scientific status

GSE283052 has 12 public Visium CRC tumor samples with distinct source patient
labels, expression matrices, tissue-spot coordinates, and histology images.
All 18 IS and 13 SS genes in the source spatial algorithm are represented.
The GEO archive does **not** contain machine-readable, spot-level pathology
labels equivalent to GSE294385 `Layer3`. Thus this analysis cannot replicate
the manuscript's pathology-layer-matched joint-control estimand. It is an
independent-cohort **partial spatial replication**, not full validation.

## Frozen input and scoring

- Use all 12 source-labeled patients with expression-coordinate alignment and
  no sample excluded on effect direction or significance.
- Use the unmodified 18-gene IS and 13-gene SS panels from
  `manuscript/CRC_NKT_v11_1/code_release/scripts/05_spatial_neighborhood_analysis.py`.
- Per spot: `log1p(count / spot_total * 1e4)` for panel genes. Within each
  section, z-standardize each gene using sample SD (`ddof=1`) and average
  z-scores across its fixed panel. Define IS-high and SS-high at their
  respective within-section 75th percentiles.
- Restrict to tissue spots with matching barcodes, nonmissing pixel and Visium
  array coordinates. One source patient label corresponds to one section;
  verify this in the audit table.

## Frozen partial estimand

Reproduce the original six-nearest-neighbor graph in pixel coordinates,
retaining directed edges with distance <= 1.6 times median nearest-neighbor
pitch. Restrict source spots to SS-low. For each of the 96 fixed intact SS-map
translations (16 offsets per hex radius 5 through 10, seed 42), compare the
IS-high versus IS-low fraction of SS-high neighbors on the *same eligible*
edges before and after translation. Require >=30 edges in each IS group,
>=100 matched IS-high edges, >=10% matched-edge coverage, and at least 24
valid translations per section. The section effect is the arithmetic mean of
the observed-minus-shifted difference in these two IS-group contrasts.

The sole deliberate change from the GSE294385 joint-control code is replacing
`Layer3` source-target pathology-pair matching with one unstratified tissue
group. This change is forced by unavailable target labels and must be named
in every output. The same pathology-free estimand will be recomputed in all
37 source sections, summarized by mean within patient then equal mean across
11 patients, and shown separately for source primary-CRC sections as context.
Do not compare the target estimate numerically to the manuscript's
pathology-adjusted +1.65 percentage-point estimate as though they were the
same effect.

## Reporting and interpretation

- Report each section/patient effect, accepted shifts, matched-edge coverage,
  same-spot IS-high/SS-high overlap, and failures with reasons.
- Each cohort is summarized separately by patient-equal mean, 10,000-draw
  patient-bootstrap percentile 95% CI (seed 42), positive-patient count, and
  leave-one-patient-out range. Convert fractions to percentage points for
  prose. Do not infer independence from spots or translations.
- No new gene selection, cutoff search, score reweighting, subgroup choice,
  or outcome model is allowed based on these results. No cross-cohort pooled
  P value is planned. A positive target direction supports only partial
  repeatability; a null or negative direction must also be reported.
- Histology images do not substitute for missing author pathology labels;
  no automated labels derived from IS/SS will be treated as independent
  pathology. No ICI or recurrence outcomes are linked to GSE283052 here.

## Primary source material

- GEO: https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE283052
- Source study: https://pmc.ncbi.nlm.nih.gov/articles/PMC12796597/
- Original algorithm in this workspace:
  `manuscript/CRC_NKT_v11_1/code_release/scripts/05_spatial_neighborhood_analysis.py`
  and `scripts/gse294385_spatial_autocorr_audit.py`.
