# Supplementary score specification

The fixed immune-activity (IS) panel contains NKG7, KLRC1, KLRB1, GZMK, GZMB, PRF1, TBX21, IFNG, ICOS, STAT4, CXCR3, CXCL13, IL7R, IL32, IFITM1, CD3E, GIMAP7, and HAVCR2 (18 genes). The fixed stromal score (SS) panel contains COL1A1, COL1A2, COL3A1, SPARC, BGN, LUM, IGFBP7, FAP, ACTA2, DCN, P4HA1, LOX, and FN1 (13 genes).

For each Visium spot, the analysis divided each gene count by the spot's total count, multiplied the result by 10,000, and applied log1p. Each gene was then standardized within its section before averaging panel genes. IS-high and SS-high were defined by section-specific upper-quartile thresholds. This is a within-section spot score, not a cell-type abundance estimate.

The GPL570 microarray lock file `Table_S6_locked_score_definition_GPL570.csv` has one selected probe, center, and scale for each covered panel gene. KLRC1 was unavailable on GPL570, leaving 17 IS genes; all 13 SS genes were covered. The probe assignments and gene-wise centers/scales came from the pre-existing GSE39582-based lock and were reused in the repaired bulk cohort analysis without reselecting probes. This is a platform-specific computational specification, not a clinically calibrated assay threshold. The spatial and GPL570 scores should not be compared numerically.

All 30 records and five fields in the included GPL570 lock CSV were checked against the original score-definition file in their original order; field values matched exactly.
