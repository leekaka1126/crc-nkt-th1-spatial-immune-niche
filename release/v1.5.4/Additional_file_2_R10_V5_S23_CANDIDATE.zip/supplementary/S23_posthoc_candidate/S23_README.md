# S23: post hoc pair-gate effect sensitivity (author-review candidate)

Execution date: 2026-10-19. The user authorized the fixed-frame six-threshold analysis; this record is **not** a two-author signed protocol or a replacement for the original E4 30/30 analysis. The earlier S19 audit remains support-only. The first exploratory output directory (`posthoc_pair_gate_effect_20261019`) is superseded by this v2 directory; neither was used to overwrite E4, S19, S20, or the R3 manuscript.

## Estimand and fixed frame

The original 16 passing sections (seven GSE294385, nine Valdeolivas) and their 1,395 accepted translations (672 and 723) are fixed. Each of the four directed tumor/stroma pathology pairs is examined separately. At a threshold of 10, 15, 20, 25, 30, or 40 *compatible directed edges in each source IS group*, an offset qualifies only when both groups meet the threshold. The observed and translated SS-high target rates are computed on the **same compatible edges**, reconstructed from frozen spot coordinates and labels. The pair effect is (observed IS-high minus IS-low rate) minus (translated IS-high minus IS-low rate), in percentage points. Qualifying offset effects are averaged within section, contributing section effects within patient, then patients equally within dataset. A patient with no qualifying offset is NE, not zero. No failed section or rejected offset is rescued. The 24-qualifying-offset tier is an availability descriptor, not a replacement analysis. No P values or confidence intervals were calculated.

This changes the pair gate only. It is *not* a full-pipeline threshold rerun, a common-edge analysis, or evidence that the pair effects at different thresholds target the same population of edges and patients. Directional arrows denote source and target indexing, not biological signaling.

## Files

- `S23a_offset_pair_effects.csv`: all 1,395 accepted offsets × four pairs × six thresholds, including `qualified=False` and blank (`NA`) effects. Low/high edge counts, observed and shifted SS-high successes, the original E4 pair weight (minimum of the two counts), and unique source/original-target/translated-target spots are preserved for each pair-offset.
- `S23b_section_pair_effects.csv`: every original passing section × pair × threshold, including NE rows; offset counts and the mean of qualified offset effects.
- `S23c_patient_pair_effects.csv`: every original contributing patient × pair × threshold, including NE rows; equal-section patient effect; contributing section/offset counts; whether any section has ≥24 qualifying offsets; and minimum/median technical edge and distinct-spot support across its qualifying offsets. These spot summaries are *not* counts of unique spots pooled over a patient.
- `S23d_cohort_pair_threshold_summary.csv`: patient-equal point estimate only among estimable patients, patient IDs and denominator, positive-patient count, qualified technical offset/section counts, ≥24-offset patient count, and leave-one-patient-out range where at least two patients are estimable. No between-threshold contrast is an inferential comparison.
- `S23_manifest.json`: checks, environment, SHA-256 hashes of inputs/code and the four CSV outputs.

## Reconciliation and interpretation

The script independently rebuilt all 15,360 candidate section–offset–pair–IS-group compatible-edge counts from spot coordinates. For originally passing pairs, observed/shifted success counts matched S14b. Every original 30/30 broad offset effect matched S14a (maximum absolute discrepancy 1.81e-16 in fractional units), and the 30/30 TT/StSt section and patient effects matched S16a/S16b. All six threshold-specific support counts matched S19b; accepted compatible counts matched S20a. The run passed the strict generated-code check. Reproduction from frozen score/label inputs is **not** an independent raw-expression or third-party replication.

The external cross-compartment pairs become technically estimable at low gates but not at the original 30/30 gate. At 10/10, tumor→stroma uses 183/723 accepted offsets from three of six patients (patient-equal +21.04 pp); stroma→tumor uses 48/723 offsets from three patients (−1.32 pp). At 15/15 and 20/20 the support narrows sharply; both are NE at 25/25, 30/30, and 40/40. Some 10/10 patient offsets have only four distinct source spots in the smaller IS group despite ten edges. Therefore, the large tumor→stroma value is a sparse-support, threshold-selected *diagnostic*, not external biological validation, a treatment-response prediction, or a clinical biomarker claim. The cross-pair effects are not mutually corroborating and are not robust to the pre-existing 30/30 gate.

Before submission, both authors should review the post hoc wording and decide whether S23 belongs in the supplement. The manuscript's main E4 estimate and its 30/30 NE statements remain unchanged.

The study-generated CSV, JSON, and text results in this S23 candidate are offered under CC BY 4.0 by Jiaozhen Hao and Minghui Li, subject to their final release review. The analysis code is separately MIT-licensed. Public GEO and Valdeolivas source data remain with their original providers and terms; no third-party raw archive is included here.
