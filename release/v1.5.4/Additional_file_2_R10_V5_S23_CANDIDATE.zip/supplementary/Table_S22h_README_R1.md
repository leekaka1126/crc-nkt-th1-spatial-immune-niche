# Supplementary Table S22d–g: saved-output environment sensitivity (R1 candidate)

This is a post hoc comparison of two **already completed** U2 runs. It does not regenerate the 9,000 formal or 3,600 calibration cohorts. The archived run remains the Figure 5 and S17 primary analysis; the newer-library run is a software-environment sensitivity, not a replacement result.

Inputs are paired by `scenario_id`, `replicate_id` and `stage`. Both summaries contain 18 scenarios. The formal and calibration attempt-ledger row counts are 9,000 and 3,600 in each environment. The full paired comparison excludes only `runtime_seconds` and `file_sha256` from the scientific-field audit. The reusable comparison script is `03_QA/audit_u2_environment_full_fields.py` in this local candidate workspace. It accepts explicit `--archived-summary`, `--newer-summary` and `--out` arguments, writes only to `--out`, and checks selected scenario means and MCSEs by independently reaggregating attempt CSVs.

| Saved input | Archived SHA-256 | Newer-library SHA-256 |
| --- | --- | --- |
| `U2_formal_all_attempts.csv` | `24f7ecd93cb251cb7bfbbef9b21f52e55a9d481779d15058478948f5b14b6390` | `ea14e630679d5e8eb5405337e6710e7b21658dab1a69cef957555c534f90da2e` |
| `U2_independent_calibration_all_attempts.csv` | `1d6f08d8707233a3c50677e05c0748996b0928f741658185b9ac10ceb5afb400` | `b9677de56e451ba62526a15b8445274fd4da7ec76e66bb7a53b0e6246752234d` |
| `U2_scenario_summary.csv` | `31ca2fb469ea539c7c5f20426261dcb03a8b60c44cdc6bf9a94bb59ff576b1c9` | `cd0c803d3b927ddf30d75a17dc98459f5a5de137d544754ce4a417eedf081d2e` |

The archived manifests recorded Python 3.14.0, NumPy 2.5.1, pandas 2.3.3 and SciPy 1.18.0. The newer manifests recorded Python 3.13.14, NumPy 2.5.4, pandas 3.0.6 and SciPy 1.18.1. Because several versions changed together, this comparison cannot attribute the difference to one package.

Files:

- `Table_S22d_environment_full_summary_R1.csv`: side-by-side archived and newer values, and newer-minus-archived differences, for selected key metrics in all 18 scenarios. All denominators are retained; non-estimable attempts are never filled with zero.
- `Table_S22e_scenario_all_field_diffs_R1.csv`: every scenario-summary field whose serialized value differs between the two files. Some differences are last-digit floating-point changes; inspect the numeric delta, not only whether a field appears.
- `Table_S22f_seed_flip_full_fields_R1.csv`: the 14 status-changing fixed-seed attempts and their changed scientific-field names. This is a summary of paired CSV fields, not a spot-level trace. The original S22b/S22c files retain the deeper fixed-seed trace.
- `Table_S22g_environment_audit_R1.json`: input hashes, row counts, field-change counts and PASS assertions. Selected `Q−F_selected_sections`, `H` and calibration `H` means/MCSEs reaggregated from attempt CSVs matched saved summaries to at most 1.11×10⁻¹⁶ percentage points in the archived run and 8.33×10⁻¹⁷ in the newer run.

Interpretation: 11 formal and three calibration cohort statuses changed. Across the 18 scenarios, ten `Q−F_selected_sections` means changed, but all retained a negative sign; the largest absolute mean change was 0.00881 percentage points. These differences are between distinct computational targets in one synthetic model family, not CRC effect bias or a new significance test. This audit does not independently implement the U2 generator, establish biological realism, or make the currently local U2 code and ledgers publicly accessible.
