# Supplementary Table S17e. Targeted atomic-edge U2 oracle audit

This post hoc code check was prompted by review of the completed U2 results. It did not change the fixed spatial rule, simulation scenarios, seeds, formal outputs or Figure 5 values. Selection was by the first replicate ID satisfying the specified *status*, never by the direction or magnitude of an effect. The two selected non-estimable attempts remain in the audit.

| Scenario | Formal replicate ID | Seed | Archived and independently reconstructed cohort status | Contributing patients | Independently reconstructed Q − F_selected_sections (percentage points) |
| --- | ---: | ---: | --- | ---: | ---: |
| G2_D1_S2 | 0 | 2800042 | Estimable | 6 | −0.335816 |
| G3_D2_S0 | 0 | 3500042 | Estimable | 3 | −0.623613 |
| G3_D2_S0 | 5 | 3500047 | Not estimable | 0 | NA |
| G3_D2_S0 | 8 | 3500050 | Not estimable | 0 | NA |

The [audit script](../../../../scripts/audit_crc_U2_atomic_edge_oracle_v11_12_2.py) imported only the frozen synthetic generator to recreate the same spot-level inputs and latent parameters. It separately enumerated the short directed graph using all-pairs distances rather than the original nearest-neighbor graph routine, recreated all 96 fixed translations, recoded the generating probability equation, and recomputed original and selected support, the 30/30 pair gate, H, Q and full-edge F. The independently recoded q(s) matched generated original-coordinate probabilities to a maximum absolute error of 1.67 × 10⁻¹⁶. Among 36 regenerated sections, 12 passed the E4 section rule. The largest absolute saved-versus-independent section differences were 4.44 × 10⁻¹⁶ percentage points for H, 5.77 × 10⁻¹⁵ for Q and 4.93 × 10⁻¹⁴ for full-edge F. All 36 section rows and four cohort rows matched their archived comparison fields within 1e-10 percentage points or exactly for categorical/integer fields.

The [machine-readable section comparison](../../../../reports/CRC_v11_12_2_atomic_oracle/atomic_edge_section_comparison.csv), [cohort comparison](../../../../reports/CRC_v11_12_2_atomic_oracle/atomic_edge_cohort_comparison.csv) and [run report](../../../../reports/CRC_v11_12_2_atomic_oracle/atomic_edge_audit_report.json) preserve every checked case. No failed or non-estimable case was replaced with zero. The check covers four preselected quality-control replicates, not all 9,000 formal attempts. Reusing the generator does not independently verify its data-generating distribution, nor is this a third-party replication or evidence that the same target contrast occurs in CRC patients. These local paths are provenance references, not public archive identifiers.
