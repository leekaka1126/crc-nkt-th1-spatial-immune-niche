# Supplementary Table S18. Repaired bulk recurrence-family associations

These unlinked bulk analyses provide clinical context only. They neither
validate the spatial IS/SS contrast nor establish a transportable patient
score or treatment decision rule. This table was moved from the v11.11 main
text without re-estimating its values.

The accompanying [machine-readable CSV](Table_S18_bulk_recurrence_context.csv)
contains the same four rows with numeric HR, CI, P-value and I² fields. Blank
Holm-adjusted cells mean the correction was not reported for those
sensitivity analyses; they are not zero.

| Analysis set | Patients/events | SS HR per cohort-specific SD (95% CI) | SS P value | IS HR per cohort-specific SD (95% CI) | IS P value | SS I² |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Principal three cohorts, all stages/full follow-up | 834/213 | 1.48 (0.79–2.77) | .116; Holm .231 | 0.90 (0.65–1.23) | .273 | 65.5% |
| Four-cohort sensitivity, all stages/full follow-up | 979/249 | 1.54 (1.05–2.26) | .037 | 0.90 (0.73–1.12) | .218 | 63.1% |
| Principal three cohorts, stage I–III/3 years | 800/174 | 1.42 (0.69–2.91) | .170 | 0.90 (0.64–1.27) | .330 | 68.2% |
| Four-cohort sensitivity, stage I–III/3 years | 935/201 | 1.45 (0.96–2.20) | .065 | 0.91 (0.72–1.15) | .275 | 60.5% |

Cohort-specific log-HRs came from univariable Cox models. DerSimonian–Laird
estimated between-cohort variance; modified Hartung–Knapp t intervals and
tests were used for pooled estimates. Holm adjusted the two principal IS/SS
tests only. The full-follow-up GSE14333 SS model had a proportional-hazards
diagnostic P = .0498. Recurrence endpoint and stage definitions vary by
cohort. CI, confidence interval; HR, hazard ratio; IS, immune-related spot
program; SD, standard deviation; SS, stromal-related spot program.
