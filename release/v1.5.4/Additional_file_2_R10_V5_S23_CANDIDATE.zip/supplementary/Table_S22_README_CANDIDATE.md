# Supplementary Table S22: numerical-environment status sensitivity (candidate)

This post hoc table is derived from the archived U2 scenario summary (S17a) and the fixed-seed status-flip ledger. It is **not** a replacement for the locked U2 analysis and does not recompute effects, Monte Carlo standard errors (MCSEs), edge gates, or latent oracles.

## Inputs and identity

- `Table_S17a_U2_scenario_summary.csv`: SHA-256 `31ca2fb469ea539c7c5f20426261dcb03a8b60c44cdc6bf9a94bb59ff576b1c9`.
- `Table_S22b_fixed_seed_status_flips_CANDIDATE.csv` is an unchanged local copy of `U2_fixed_seed_status_flips.csv`: SHA-256 `9ca19cbef8d08325274b31dfcc07b3797faaa9e5b518ac10a23b58b3e3f1280a`; 14 unique stage/scenario/replicate rows, 11 formal and 3 calibration. It provides IDs, seeds, old/new cohort status and limited label-change diagnostics, **not** a complete pair/offset or effect-impact ledger.
- `Table_S22c_paired_attempt_diagnostics_CANDIDATE.csv` is a new, selected-attempt diagnostic made from the 14 pinned/newer JSON trace pairs. The generator and the SHA-256 of every trace are in `01_AUDIT/audit_numeric_env_attempt_pairs.py` and `01_AUDIT/S22c_INPUT_MANIFEST.json` in the local review package. All 14 trace identities, statuses, 18 sections with label flips, 58 IS and one SS spot-label changes reconciled to S22b. The table also records each selected attempt's passing sections, estimable patients and sums of accepted offsets and original SS-low edges. Its sums are **not** a scenario-level sensitivity estimate.
- Generator: `01_AUDIT/audit_numeric_env_status_delta.py` in this candidate review package. It makes no random draws and reads the two input files by explicit command-line paths.

## Calculation

For each scenario and stage, `rerun_ne_status_only = archived_ne - ne_to_estimable + estimable_to_ne`. Formal archived counts and denominators come from `ne_replicates` and `attempted_replicates` in S17a. Calibration archived NE is `calibration_replicates - calibration_H_eligible`. The denominator is 500 per formal scenario and 200 per calibration scenario. All 18 scenarios and both stages are retained, including rows with no recorded status change.

The 11 formal changes are confined to G3_D2: two NE-to-estimable in S0, one in S1, and six NE-to-estimable plus two estimable-to-NE in S2. Three calibration NE-to-estimable changes occur in G3_D2_S0. The table reports the resulting counts and percentage-point changes. Its output SHA-256 is `19dc2aec4af0bbffea5ca4fb25f8a700bdc818ec2942e029aaba8076b58773d3`.

## Scope limit

This audit assumes that the supplied fixed-seed ledger contains every cohort-status change between the archived and newer-library runs. S22c reads only the 14 selected paired traces; it does not independently inspect all 12,600 attempt pairs or attribute the numerical difference to a single package. The traces do not contain a complete pair-specific 30/30 gate ledger. This audit cannot establish whether newly eligible or excluded attempts change scenario effect means, MCSEs, oracle contrasts, full patient-contribution distributions, or the qualitative direction of any result. Those comparisons require a separate full-ledger old-versus-new reaggregation before a submission-level numerical-stability claim.
