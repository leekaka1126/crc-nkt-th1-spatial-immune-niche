# NE versus zero reconciliation (R7 candidate)

This audit is generated from the frozen S14b and S23a derived tables. It documents how the stored zero counts on failed 30/30 pairs are separated from genuine zero outcome counts on qualified pairs. It does not re-read raw count matrices, recompute an effect, or change the E4 estimand.

Rows audited: 7680 source-IS-low rows from S14b; failed-pair rows: 4235; failed-pair rows with blank S23 30/30 effects: 4235.

## Assertions

- `s14b_rows_all_source_group`: PASS
- `failed_pair_effect_blank`: PASS
- `failed_pair_zeroes_are_flagged`: PASS
- `qualified_rows_preserved`: PASS
- `no_effect_imputed_from_count_zero`: PASS
- `s23_30_counts_match_s19`: PASS
- `s23_30_counts_match_s20`: PASS
- `accepted_denominators_match_s19`: PASS

## Interpretation

`pair_passed_minimum=False` defines a non-estimable pair under the frozen operational gate. Its stored zero outcome fields are sentinels from the archived ledger and must not be treated as observed zero events or converted into an effect of zero. A qualified pair may have an actual observed or shifted success count of zero; that is a different state and is retained as an observation.

The CSV is a reconciliation aid for readers of the machine-readable supplement. The primary manuscript conclusions remain unchanged. A raw-input independent reimplementation would still require the original public input manifest and executable environment.

## Pair-level summary

| dataset | pathology_pair | rows | gate-failure rows | qualified rows | failed rows with stored zeros | qualified rows with observed zero | qualified rows with shifted zero |
|---|---|---:|---:|---:|---:|---:|---:|
| GSE294385 | stroma->stroma | 768 | 152 | 616 | 152 | 9 | 7 |
| GSE294385 | stroma->tumor | 768 | 97 | 671 | 97 | 124 | 88 |
| GSE294385 | tumor->stroma | 768 | 195 | 573 | 195 | 8 | 6 |
| GSE294385 | tumor->tumor | 768 | 118 | 650 | 118 | 1 | 0 |
| Valdeolivas_2024 | stroma->stroma | 1152 | 635 | 517 | 635 | 0 | 0 |
| Valdeolivas_2024 | stroma->tumor | 1152 | 1152 | 0 | 1152 | 0 | 0 |
| Valdeolivas_2024 | tumor->stroma | 1152 | 1152 | 0 | 1152 | 0 | 0 |
| Valdeolivas_2024 | tumor->tumor | 1152 | 734 | 418 | 734 | 13 | 13 |
