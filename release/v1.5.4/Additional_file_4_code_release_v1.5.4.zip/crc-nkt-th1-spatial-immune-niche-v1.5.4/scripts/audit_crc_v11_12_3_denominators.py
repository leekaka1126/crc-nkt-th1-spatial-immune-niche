#!/usr/bin/env python
"""Read-only independent denominator audit from frozen U2 attempt rows.

This script never runs the simulator or modifies its saved outputs. It rebuilds
scenario counts from the 9,000 all-attempt records and compares them with the
manuscript-facing S17a/S17d summaries. Its output is an audit, not new U2 data.
"""
from __future__ import annotations

import csv
import hashlib
import json
import math
import statistics
from collections import defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ATTEMPTS = ROOT / "results/CRC_U2_summary_v1_2026-10-13/U2_formal_all_attempts.csv"
S17A = ROOT / "manuscript/CRC_NKT_v11_1/supplementary/Table_S17a_U2_scenario_summary.csv"
S17D = ROOT / "manuscript/CRC_NKT_v11_1/supplementary/Table_S17d_U2_contributing_patients.csv"
OUT = ROOT / "reports/CRC_v11_12_3_denominator_audit"


def read_rows(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def file_sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def near(actual: float, expected: float, label: str, tolerance: float = 1e-12) -> None:
    if not math.isclose(actual, expected, rel_tol=0.0, abs_tol=tolerance):
        raise AssertionError(f"{label}: {actual!r} != {expected!r}")


def main() -> None:
    attempts = read_rows(ATTEMPTS)
    summary = {row["scenario_id"]: row for row in read_rows(S17A)}
    distribution = {row["scenario_id"]: row for row in read_rows(S17D)}
    by_scenario: dict[str, list[dict[str, str]]] = defaultdict(list)
    for row in attempts:
        if row["stage"] != "formal" or row["run_status"] != "PASS":
            raise AssertionError("Unexpected stage or implementation error in formal ledger")
        by_scenario[row["scenario_id"]].append(row)
    if len(attempts) != 9000 or len(by_scenario) != 18:
        raise AssertionError(f"Formal ledger has {len(attempts)} rows in {len(by_scenario)} cells")
    if set(by_scenario) != set(summary) or set(by_scenario) != set(distribution):
        raise AssertionError("Scenario keys differ among frozen ledgers")

    out_rows: list[dict[str, object]] = []
    for scenario_id in sorted(by_scenario):
        rows = by_scenario[scenario_id]
        s = summary[scenario_id]
        d = distribution[scenario_id]
        if len(rows) != 500 or sorted(int(r["replicate_id"]) for r in rows) != list(range(500)):
            raise AssertionError(f"Attempt IDs incomplete or duplicated: {scenario_id}")
        statuses = {r["status"] for r in rows}
        if not statuses <= {"ESTIMABLE", "NE_COHORT"}:
            raise AssertionError(f"Unexpected status: {scenario_id}: {statuses}")
        n_eligible = sum(r["status"] == "ESTIMABLE" for r in rows)
        n_ne = len(rows) - n_eligible
        counts = {i: sum(int(r["estimable_patients"]) == i for r in rows) for i in range(7)}
        if counts[0] != n_ne:
            raise AssertionError(f"NE differs from zero contributors: {scenario_id}")
        n_interval = sum(r["bootstrap_available"] == "True" for r in rows)
        if n_interval > n_eligible:
            raise AssertionError(f"Interval count exceeds estimable: {scenario_id}")
        n_strict_pair_patients = sum(int(r["same_patient_both_strict"]) for r in rows)
        for field, value in {
            "attempted_replicates": len(rows),
            "eligible_replicates": n_eligible,
            "ne_replicates": n_ne,
            "reference_inclusion_H_given_A_n": n_interval,
            "Q_minus_Fselected_pp_n": n_eligible,
            "same_patient_both_strict_count": n_strict_pair_patients,
        }.items():
            if int(s[field]) != value:
                raise AssertionError(f"S17a {scenario_id} {field}: {s[field]} != {value}")
        if int(d["attempted_cohorts"]) != 500 or int(d["interval_available"]) != n_interval:
            raise AssertionError(f"S17d denominator mismatch: {scenario_id}")
        for i, value in counts.items():
            field = "n0_nonestimable" if i == 0 else f"n{i}_contributor" if i == 1 else f"n{i}_contributors"
            if int(d[field]) != value:
                raise AssertionError(f"S17d {scenario_id} {field}: {d[field]} != {value}")
        values = [float(r["Q_minus_Fselected_pp"]) for r in rows if r["status"] == "ESTIMABLE"]
        q_mean = statistics.mean(values)
        q_mcse = statistics.stdev(values) / math.sqrt(len(values)) if len(values) > 1 else math.nan
        near(q_mean, float(s["Q_minus_Fselected_pp_mean"]), f"{scenario_id} Q-Fselected mean")
        near(q_mcse, float(s["Q_minus_Fselected_pp_mcse"]), f"{scenario_id} Q-Fselected MCSE")
        out_rows.append({
            "scenario_id": scenario_id,
            "n_attempted": 500,
            "n_estimable": n_eligible,
            "n_nonestimable": n_ne,
            "n_interval_available": n_interval,
            "n_one_contributor": counts[1],
            "n_strict_pair_patients": n_strict_pair_patients,
            "Q_minus_Fselected_pp_mean": q_mean,
            "Q_minus_Fselected_pp_mcse": q_mcse,
            **{f"n{i}_contributors": counts[i] for i in range(7)},
        })

    g3 = [r for r in out_rows if str(r["scenario_id"]).startswith("G3_")]
    totals = {
        "n_attempted": sum(int(r["n_attempted"]) for r in g3),
        "n_estimable": sum(int(r["n_estimable"]) for r in g3),
        "n_nonestimable": sum(int(r["n_nonestimable"]) for r in g3),
        "n_one_contributor": sum(int(r["n_one_contributor"]) for r in g3),
    }
    if totals != {"n_attempted": 3000, "n_estimable": 2637,
                  "n_nonestimable": 363, "n_one_contributor": 947}:
        raise AssertionError(f"G3 headline count mismatch: {totals}")

    OUT.mkdir(parents=True, exist_ok=True)
    csv_path = OUT / "scenario_denominators.csv"
    with csv_path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(out_rows[0]))
        writer.writeheader()
        writer.writerows(out_rows)
    report = {
        "status": "PASS",
        "scope": "all 9000 saved formal attempt rows; no simulator rerun or edge-level recomputation",
        "scenario_cells": len(out_rows),
        "formal_attempts": len(attempts),
        "G3": totals,
        "G3_one_contributor_of_attempted": totals["n_one_contributor"] / totals["n_attempted"],
        "G3_one_contributor_of_estimable": totals["n_one_contributor"] / totals["n_estimable"],
        "input_sha256": {str(path.relative_to(ROOT)): file_sha(path) for path in (ATTEMPTS, S17A, S17D)},
        "output_csv": str(csv_path.relative_to(ROOT)),
    }
    (OUT / "assertions.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False))


if __name__ == "__main__":
    main()
