#!/usr/bin/env python
"""Paired, preselected U2 sample-size sensitivity for estimability only."""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path

import pandas as pd


SCENARIOS = ("G2_D1_S2", "G3_D2_S0")
SIZES = (6, 12, 20)
SCENARIO_INDEX = {f"{g}_{d}_{s}": i for i, (g, d, s) in enumerate(
    (g, d, s) for g in ("G1", "G2", "G3")
    for d in ("D1", "D2") for s in ("S0", "S1", "S2"))}


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def load_200(directory: Path, scenario: str, n_patients: int,
             expected_sha: str) -> dict[int, dict]:
    manifest = json.loads((directory / "RUN_MANIFEST.json").read_text(encoding="utf-8"))
    if (manifest["stage"] != "formal" or manifest["reps_per_cell"] != 200 or
            manifest["patients_per_replicate"] != n_patients or
            manifest["code_sha256"] != expected_sha):
        raise AssertionError(f"Secondary stream identity mismatch: {directory}")
    result = {}
    for replicate in range(200):
        path = directory / f"{scenario}_r{replicate:05d}.json"
        item = json.loads(path.read_text(encoding="utf-8"))
        seed = 2_000_042 + SCENARIO_INDEX[scenario] * 100_000 + replicate
        if (item.get("seed") != seed or item.get("run_status") != "PASS" or
                item.get("attempted_patients") != n_patients):
            raise AssertionError(f"Secondary replicate mismatch: {path}")
        result[replicate] = item
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--primary", type=Path, required=True)
    parser.add_argument("--secondary-root", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    main_manifest = json.loads((args.primary / "RUN_MANIFEST.json").read_text(encoding="utf-8"))
    if main_manifest["stage"] != "formal" or main_manifest["reps_per_cell"] != 500:
        raise AssertionError("Primary formal manifest is not the locked 500-replicate run")
    rows = []
    for scenario in SCENARIOS:
        by_size: dict[int, dict[int, dict]] = {6: {}}
        for replicate in range(200):
            path = args.primary / f"{scenario}_r{replicate:05d}.json"
            item = json.loads(path.read_text(encoding="utf-8"))
            if item.get("run_status") != "PASS":
                raise AssertionError(f"Primary error: {path}")
            by_size[6][replicate] = item
        for size in (12, 20):
            directory = args.secondary_root / f"{scenario}_n{size}"
            by_size[size] = load_200(directory, scenario, size,
                                     main_manifest["code_sha256"])
        for replicate in range(200):
            for size in SIZES:
                item = by_size[size][replicate]
                if item.get("attempted_patients") != size:
                    raise AssertionError("Patient count differs from requested size")
                rows.append({
                    "scenario_id": scenario, "replicate_id": replicate,
                    "patients": size, "cohort_estimable": item["status"] == "ESTIMABLE",
                    "estimable_patients": item["estimable_patients"],
                    "attempted_sections": item["attempted_sections"],
                    "passing_sections": item["passing_sections"],
                    "same_patient_both_minimal": item["same_patient_both_minimal"],
                    "same_patient_both_strict": item["same_patient_both_strict"],
                })
        for replicate in range(200):
            six = by_size[6][replicate]["patients"]
            for size in (12, 20):
                larger_prefix = by_size[size][replicate]["patients"][:6]
                for a, b in zip(six, larger_prefix):
                    for field in ("patient_id", "n_sections", "native_effect_pp",
                                  "oracle_full_pp", "oracle_selected_pp"):
                        av, bv = a[field], b[field]
                        if av is None or bv is None:
                            if av != bv:
                                raise AssertionError("Nested patient seed prefix differs")
                        elif isinstance(av, (float, int)):
                            if not math.isclose(float(av), float(bv), abs_tol=1e-12):
                                raise AssertionError("Nested patient seed prefix differs")
                        elif av != bv:
                            raise AssertionError("Nested patient seed prefix differs")
    frame = pd.DataFrame(rows).sort_values(["scenario_id", "replicate_id", "patients"])
    summaries = []
    for (scenario, size), group in frame.groupby(["scenario_id", "patients"], sort=True):
        ne = (~group.cohort_estimable).to_numpy(float)
        both_min = (group.same_patient_both_minimal / size).to_numpy(float)
        both_strict = (group.same_patient_both_strict / size).to_numpy(float)
        summaries.append({
            "scenario_id": scenario, "patients": size, "replicates": len(group),
            "nonestimable_cohorts": int(ne.sum()), "p_ne": float(ne.mean()),
            "p_ne_mcse": float(ne.std(ddof=1) / math.sqrt(len(ne))),
            "both_minimal_patient_rate": float(both_min.mean()),
            "both_minimal_cluster_mcse": float(both_min.std(ddof=1) / math.sqrt(len(both_min))),
            "both_strict_patient_rate": float(both_strict.mean()),
            "both_strict_cluster_mcse": float(both_strict.std(ddof=1) / math.sqrt(len(both_strict))),
        })
    args.out.mkdir(parents=True, exist_ok=True)
    frame.to_csv(args.out / "U2_sample_size_all_attempts.csv", index=False)
    pd.DataFrame(summaries).to_csv(args.out / "U2_sample_size_summary.csv", index=False)
    provenance = {
        "locked_code_sha256": main_manifest["code_sha256"],
        "frozen_e4_sha256": main_manifest["e4_sha256"],
        "paired_replicate_seeds": "formal-stage first 200 seeds, identical prefix patients",
        "scenario_ids": list(SCENARIOS), "patient_sizes": list(SIZES),
        "attempts": len(frame), "secondary_attempts": 800,
        "all_attempts_sha256": digest(args.out / "U2_sample_size_all_attempts.csv"),
        "summary_sha256": digest(args.out / "U2_sample_size_summary.csv"),
        "summarizer_sha256": digest(Path(__file__)),
    }
    (args.out / "U2_sample_size_manifest.json").write_text(
        json.dumps(provenance, indent=2) + "\n", encoding="utf-8")
    print(pd.DataFrame(summaries).to_string(index=False))


if __name__ == "__main__":
    main()
