#!/usr/bin/env python
"""Data-driven U2 figure: estimability, retained support, selected target shift.

Key message: the fixed spatial estimator's estimability and target support
depend on tissue geometry, not simply the planted co-location mechanism.
Audience: methods-paper specialists; reading budget approximately one minute.
Date: 2026-10-13. Target journal: unspecified, 7-inch neutral format at 600 dpi.
"""
from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


SCENARIOS = [f"{g}_{d}_{s}" for g in ("G1", "G2", "G3")
             for d in ("D1", "D2") for s in ("S0", "S1", "S2")]
ROWS = [f"{g} · {d}" for g in ("G1", "G2", "G3") for d in ("D1", "D2")]
COLS = ("S0", "S1", "S2")


def matrix(table: pd.DataFrame, field: str) -> np.ndarray:
    indexed = table.set_index("scenario_id")
    return np.array([indexed.loc[scenario, field] for scenario in SCENARIOS], float).reshape(6, 3)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--summary", type=Path, required=True)
    parser.add_argument("--out-prefix", type=Path, required=True)
    args = parser.parse_args()
    table = pd.read_csv(args.summary)
    if len(table) != 18 or set(table.scenario_id) != set(SCENARIOS):
        raise AssertionError("Figure needs the full 18-scenario summary")
    args.out_prefix.parent.mkdir(parents=True, exist_ok=True)
    plt.rcParams.update({
        "font.family": "sans-serif", "font.sans-serif": ["Arial", "DejaVu Sans"],
        "font.size": 8, "axes.labelsize": 9, "xtick.labelsize": 8,
        "ytick.labelsize": 8, "pdf.fonttype": 42,
    })
    panels = [
        ("p_ne", "Cohort non-estimability", "Blues", 0.0, 0.20, "percent"),
        ("retained_ss_low_fraction_mean", "SS-low edges retained in accepted offsets",
         "Blues", 0.0, 0.40, "percent"),
        ("Q_minus_Fselected_pp_mean", "Selected-support oracle − full-section oracle",
         "PuOr", None, None, "pp"),
    ]
    drift = matrix(table, "Q_minus_Fselected_pp_mean")
    bound = float(np.nanmax(np.abs(drift))) if np.isfinite(drift).any() else 1.0
    bound = max(bound, 0.01)
    fig, axes = plt.subplots(3, 1, figsize=(7.0, 9.2), layout="constrained")
    for index, (field, label, cmap_name, lo, hi, unit) in enumerate(panels):
        ax = axes[index]
        values = matrix(table, field)
        cmap = plt.get_cmap(cmap_name).copy()
        cmap.set_bad("#E8E8E8")
        vmin, vmax = (-bound, bound) if unit == "pp" else (lo, hi)
        heat = ax.imshow(np.ma.masked_invalid(values), cmap=cmap,
                         vmin=vmin, vmax=vmax, aspect="auto")
        ax.set_xticks(range(3), COLS)
        ax.set_yticks(range(6), ROWS)
        ax.set_xlabel("Spatial mechanism")
        ax.set_ylabel("Geometry · detection")
        ax.set_title(f"{'ABC'[index]}   {label}", loc="left", fontsize=10, fontweight="bold")
        ax.set_xticks(np.arange(-0.5, 3, 1), minor=True)
        ax.set_yticks(np.arange(-0.5, 6, 1), minor=True)
        ax.grid(which="minor", color="white", linewidth=1.2)
        ax.tick_params(which="minor", bottom=False, left=False)
        ax.tick_params(which="major", length=0)
        for row in range(6):
            for col in range(3):
                value = values[row, col]
                if not np.isfinite(value):
                    display = "NE"
                elif unit == "percent":
                    display = f"{100 * value:.1f}%"
                else:
                    display = f"{value:+.2f} pp"
                rgba = cmap((value - vmin) / (vmax - vmin)) if np.isfinite(value) else (0.9, 0.9, 0.9, 1)
                luminance = 0.2126 * rgba[0] + 0.7152 * rgba[1] + 0.0722 * rgba[2]
                ax.text(col, row, display, ha="center", va="center",
                        color="white" if luminance < 0.48 else "#111111",
                        fontsize=8)
        bar = fig.colorbar(heat, ax=ax, shrink=0.80, pad=0.02)
        bar.set_label("Percentage points" if unit == "pp" else "Proportion", fontsize=8)
        bar.ax.tick_params(labelsize=7)
    fig.savefig(args.out_prefix.with_suffix(".pdf"), bbox_inches="tight")
    fig.savefig(args.out_prefix.with_suffix(".png"), dpi=620, bbox_inches="tight")
    plt.close(fig)


if __name__ == "__main__":
    main()
