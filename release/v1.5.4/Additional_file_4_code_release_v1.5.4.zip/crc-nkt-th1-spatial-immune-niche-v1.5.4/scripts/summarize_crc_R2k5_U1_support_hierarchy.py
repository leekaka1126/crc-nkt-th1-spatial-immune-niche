"""Post hoc U1 support hierarchy; 2026-10-12; no randomness.

Reads locked S16 and S14i CSVs. Does not recalculate or change E4 or U1 effects.
The output distinguishes same patient, same section and same section/offset.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
from collections import defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_SUPP = ROOT / "manuscript/CRC_NKT_v11_1/supplementary"
FILES = {
    "sections": "Table_S16a_U1_section_pair_support.csv",
    "patients": "Table_S16b_U1_patient_pair_effects.csv",
    "mixtures": "Table_S16c_U1_same_patient_equal_pair_mix.csv",
    "joint": "Table_S16d_U1_joint_offset_support_only.csv",
    "prior_pairs": "Table_S14i_multilevel_pair_estimability.csv",
}
PAIRS = {"TT": "tumor->tumor", "StSt": "stroma->stroma"}
TIERS = {"min": ("at_least_one", 1), "strict": ("at_least_24_per_section", 24)}


def read_rows(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def unique_index(rows: list[dict[str, str]], fields: tuple[str, ...]) -> dict[tuple[str, ...], dict[str, str]]:
    result = {}
    for row in rows:
        key = tuple(row[field] for field in fields)
        if key in result:
            raise ValueError(f"Duplicate key {fields}: {key}")
        result[key] = row
    return result


def as_bool(value: str) -> bool:
    if value not in ("True", "False"):
        raise ValueError(f"Expected True/False, got {value!r}")
    return value == "True"


def effect_close(actual: str, expected: str, label: str) -> None:
    if bool(actual) != bool(expected):
        raise ValueError(f"Effect/NA mismatch: {label}: {actual!r} vs {expected!r}")
    if actual and abs(float(actual) - float(expected)) > 1e-9:
        raise ValueError(f"Effect mismatch: {label}: {actual} vs {expected}")


def write_rows(path: Path, rows: list[dict[str, object]]) -> None:
    if not rows:
        raise ValueError("No output rows")
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--supplementary-dir", type=Path, default=DEFAULT_SUPP)
    parser.add_argument("--out", type=Path, required=True, help="New, non-existing output directory")
    args = parser.parse_args()
    supp = args.supplementary_dir.resolve()
    out = args.out.resolve()
    if out.exists():
        raise FileExistsError(f"Refusing to overwrite {out}")

    paths = {name: supp / filename for name, filename in FILES.items()}
    data = {name: read_rows(path) for name, path in paths.items()}
    a = unique_index(data["sections"], ("dataset", "patient_id", "sample", "pair"))
    b = unique_index(data["patients"], ("dataset", "patient_id", "support_tier", "pair"))
    c = unique_index(data["mixtures"], ("dataset", "patient_id", "support_tier"))
    d = unique_index(data["joint"], ("dataset", "patient_id", "sample"))
    prior = unique_index(
        [row for row in data["prior_pairs"] if row["scope"] == "patient"],
        ("dataset", "patient_id", "pathology_pair"),
    )

    samples: dict[tuple[str, str], set[str]] = defaultdict(set)
    for dataset, patient, sample, _pair in a:
        samples[(dataset, patient)].add(sample)
    if len(samples) != 11 or len(a) != 40 or len(b) != 44 or len(c) != 22 or len(d) != 20:
        raise ValueError("Unexpected patient, section or U1 ledger cardinality")

    master: list[dict[str, object]] = []
    for dataset, patient in sorted(samples):
        section_ids = sorted(samples[(dataset, patient)])
        for tier_name, (tier_code, min_count) in TIERS.items():
            row: dict[str, object] = {
                "dataset": dataset,
                "patient_id": patient,
                "support_tier": tier_code,
                "candidate_section_n": len(section_ids),
                "original_passing_section_n": sum(
                    a[(dataset, patient, sample, PAIRS["TT"])]["section_status"] == "PASS"
                    for sample in section_ids
                ),
            }
            qualifying_sections: dict[str, set[str]] = {}
            for short, pair in PAIRS.items():
                eligible_sections = {
                    sample for sample in section_ids
                    if a[(dataset, patient, sample, pair)]["section_status"] == "PASS"
                    and int(a[(dataset, patient, sample, pair)]["pair_qualified_offset_n"]) >= min_count
                }
                qualifying_sections[short] = eligible_sections
                n_offsets = sum(int(a[(dataset, patient, sample, pair)]["pair_qualified_offset_n"])
                                for sample in eligible_sections)
                b_row = b[(dataset, patient, tier_code, pair)]
                prior_row = prior[(dataset, patient, pair)]
                if (b_row["effect_status"] == "ESTIMABLE") != bool(eligible_sections):
                    raise ValueError(f"Effect status mismatch: {dataset}/{patient}/{pair}/{tier_code}")
                if int(b_row["pair_available_section_n"]) != len(eligible_sections):
                    raise ValueError(f"Section count mismatch: {dataset}/{patient}/{pair}/{tier_code}")
                if int(b_row["pair_qualified_offset_n_in_available_sections"]) != n_offsets:
                    raise ValueError(f"Offset count mismatch: {dataset}/{patient}/{pair}/{tier_code}")
                if tier_name == "min":
                    effect_close(b_row["pair_effect_pp"], prior_row["pair_specific_effect_pp_given_qualified"],
                                 f"S14i {dataset}/{patient}/{pair}")
                row.update({
                    f"{short}_available": bool(eligible_sections),
                    f"{short}_qualifying_section_n": len(eligible_sections),
                    f"{short}_qualifying_section_ids": "|".join(sorted(eligible_sections)),
                    f"{short}_qualified_offset_n": n_offsets,
                    f"{short}_patient_effect_pp": b_row["pair_effect_pp"],
                    f"{short}_mean_min_group_edge_weight_min_tier":
                        prior_row["mean_effective_pair_weight_given_qualified"] if tier_name == "min" else "",
                })
            both_sections = qualifying_sections["TT"] & qualifying_sections["StSt"]
            joint_n = 0
            for sample in section_ids:
                d_row = d[(dataset, patient, sample)]
                joint = int(d_row["joint_TT_SS_qualified_offset_n"])
                tt = int(a[(dataset, patient, sample, PAIRS["TT"])]["pair_qualified_offset_n"])
                stst = int(a[(dataset, patient, sample, PAIRS["StSt"])]["pair_qualified_offset_n"])
                if joint > min(tt, stst):
                    raise ValueError(f"Joint offset exceeds pair support: {dataset}/{patient}/{sample}")
                if sample in both_sections:
                    joint_n += joint
            c_row = c[(dataset, patient, tier_code)]
            both_patient = bool(qualifying_sections["TT"] and qualifying_sections["StSt"])
            if as_bool(c_row["both_pairs_available"]) != both_patient:
                raise ValueError(f"Same-patient availability mismatch: {dataset}/{patient}/{tier_code}")
            if both_patient:
                mean = (float(row["TT_patient_effect_pp"]) + float(row["StSt_patient_effect_pp"])) / 2
                if abs(mean - float(c_row["same_patient_equal_pair_mix_pp"])) > 1e-9:
                    raise ValueError(f"Same-patient mean mismatch: {dataset}/{patient}/{tier_code}")
            elif c_row["same_patient_equal_pair_mix_pp"]:
                raise ValueError(f"Unexpected mix for non-eligible patient: {dataset}/{patient}/{tier_code}")
            row.update({
                "same_patient_both_available": both_patient,
                "same_section_both_n": len(both_sections),
                "same_section_both_ids": "|".join(sorted(both_sections)),
                "same_section_offset_both_n_technical": joint_n,
                "same_patient_equal_pair_mix_pp": c_row["same_patient_equal_pair_mix_pp"],
                "mix_status": "AVAILABLE_DESCRIPTIVE" if both_patient else "NE",
            })
            master.append(row)

    cohort_rows: list[dict[str, object]] = []
    for dataset in ("GSE294385", "Valdeolivas_2024"):
        for tier_name, (tier_code, _min_count) in TIERS.items():
            members = [row for row in master if row["dataset"] == dataset and row["support_tier"] == tier_code]
            cohort_rows.append({
                "dataset": dataset,
                "support_tier": tier_code,
                "candidate_patient_n": len(members),
                "TT_available_patient_n": sum(row["TT_available"] for row in members),
                "StSt_available_patient_n": sum(row["StSt_available"] for row in members),
                "same_patient_both_n": sum(row["same_patient_both_available"] for row in members),
                "same_section_both_patient_n": sum(row["same_section_both_n"] > 0 for row in members),
                "same_section_offset_both_patient_n": sum(row["same_section_offset_both_n_technical"] > 0 for row in members),
                "same_section_both_n_technical": sum(row["same_section_both_n"] for row in members),
                "same_section_offset_both_n_technical": sum(row["same_section_offset_both_n_technical"] for row in members),
                "same_patient_both_ids": "|".join(row["patient_id"] for row in members if row["same_patient_both_available"]),
                "note": "Technical section/offset counts are nested, not independent patients; no shared-edge effect",
            })

    expected = {
        ("GSE294385", "at_least_one"): (5, 5, 5),
        ("GSE294385", "at_least_24_per_section"): (5, 5, 5),
        ("Valdeolivas_2024", "at_least_one"): (5, 5, 4),
        ("Valdeolivas_2024", "at_least_24_per_section"): (3, 4, 1),
    }
    for row in cohort_rows:
        key = row["dataset"], row["support_tier"]
        actual = row["TT_available_patient_n"], row["StSt_available_patient_n"], row["same_patient_both_n"]
        if actual != expected[key]:
            raise ValueError(f"Patient support mismatch for {key}: {actual} != {expected[key]}")

    out.mkdir(parents=True)
    master_path = out / "S16g_patient_support_hierarchy.csv"
    cohort_path = out / "S16h_support_hierarchy_summary.csv"
    write_rows(master_path, master)
    write_rows(cohort_path, cohort_rows)
    report = {
        "status": "PASS",
        "analysis_role": "support_only_post_hoc; no E4 effect change; no common-edge inference",
        "input_sha256": {name: sha256(path) for name, path in paths.items()},
        "output_sha256": {path.name: sha256(path) for path in (master_path, cohort_path)},
        "counts": {"patient_tier_rows": len(master), "cohort_tier_rows": len(cohort_rows)},
        "external_strict_joint_support": [row for row in master if row["dataset"] == "Valdeolivas_2024"
                                          and row["support_tier"] == "at_least_24_per_section"
                                          and row["same_patient_both_available"]],
    }
    (out / "S16i_run_report.json").write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    for row in cohort_rows:
        print(row["dataset"], row["support_tier"], "TT/StSt/both=",
              row["TT_available_patient_n"], row["StSt_available_patient_n"], row["same_patient_both_n"],
              "same_section_patients=", row["same_section_both_patient_n"],
              "co-offset_patients=", row["same_section_offset_both_patient_n"])
    print(out)


if __name__ == "__main__":
    main()
