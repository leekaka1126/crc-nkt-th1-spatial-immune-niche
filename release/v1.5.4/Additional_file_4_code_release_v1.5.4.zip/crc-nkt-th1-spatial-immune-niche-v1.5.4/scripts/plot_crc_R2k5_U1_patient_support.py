"""Figure S11: patient-level U1 support and effects; 2026-10-12; no randomness.

Message: the independent dual-pair patient set shrinks under the strict rule,
and positive minimal-tier estimates must not be read as replication.
"""
from __future__ import annotations

import csv
import json
import os
from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib.patches import Patch, Rectangle
from matplotlib.lines import Line2D


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "manuscript/CRC_NKT_v11_1"
INPUT = BASE / "supplementary/Table_S16g_patient_support_hierarchy.csv"
OUT_BASE = BASE / "figures_v11_10/FigS11_v11_10_U1_patient_support"
WONG_BLUE = "#0072B2"
WONG_ORANGE = "#E69F00"
NE_GRAY = "#DDDDDD"


def read_rows() -> list[dict[str, str]]:
    with INPUT.open("r", encoding="utf-8-sig", newline="") as stream:
        rows = list(csv.DictReader(stream))
    if len(rows) != 22:
        raise ValueError("Expected 11 patients by two fixed tiers")
    return rows


def parse_bool(value: str) -> bool:
    if value not in ("True", "False"):
        raise ValueError(f"Bad boolean: {value!r}")
    return value == "True"


def main() -> None:
    style_dir = os.environ.get("CLAUDE_SKILL_DIR")
    if style_dir:
        style = Path(style_dir).parent / "analyze-stats/references/style/figure_style.mplstyle"
        if style.exists():
            plt.style.use(style)
    plt.rcParams.update({
        "font.family": "Arial", "font.size": 8, "axes.labelsize": 9,
        "xtick.labelsize": 8, "ytick.labelsize": 8, "pdf.fonttype": 42,
        "axes.spines.top": False, "axes.spines.right": False,
    })
    rows = read_rows()
    minimum = {(r["dataset"], r["patient_id"]): r for r in rows if r["support_tier"] == "at_least_one"}
    strict = {(r["dataset"], r["patient_id"]): r for r in rows if r["support_tier"] == "at_least_24_per_section"}
    keys = sorted(minimum, key=lambda key: (key[0] != "GSE294385", key[1]))
    if set(keys) != set(strict):
        raise ValueError("Minimum and strict patient keys differ")
    positions = [float(i if i < 5 else i + 0.65) for i in range(len(keys))]

    fig = plt.figure(figsize=(7.0, 5.15))
    grid = fig.add_gridspec(1, 2, width_ratios=[1.05, 1.7], left=0.16, right=0.98,
                            bottom=0.16, top=0.91, wspace=0.28)
    ax_support = fig.add_subplot(grid[0, 0])
    ax_effect = fig.add_subplot(grid[0, 1], sharey=ax_support)

    for y, key in zip(positions, keys):
        row_min, row_strict = minimum[key], strict[key]
        for x, pair in enumerate(("TT", "StSt")):
            n = int(row_min[f"{pair}_qualified_offset_n"])
            min_ok = parse_bool(row_min[f"{pair}_available"])
            strict_ok = parse_bool(row_strict[f"{pair}_available"])
            if min_ok != (n > 0):
                raise ValueError(f"Minimum support mismatch: {key}/{pair}")
            color = WONG_BLUE if strict_ok else (WONG_ORANGE if min_ok else NE_GRAY)
            ax_support.add_patch(Rectangle((x - .46, y - .36), .92, .72, facecolor=color,
                                           edgecolor="white", linewidth=1.0))
            ax_support.text(x, y, str(n), ha="center", va="center", fontsize=8,
                            color="white" if strict_ok else "black", fontweight="bold")
        for pair, dy, marker, color in (("TT", -.18, "o", WONG_BLUE),
                                        ("StSt", .18, "s", WONG_ORANGE)):
            value = row_min[f"{pair}_patient_effect_pp"]
            if value:
                ax_effect.scatter(float(value), y + dy, s=24, marker=marker, color=color,
                                  edgecolors="black", linewidths=.25, zorder=3)
        mix = row_min["same_patient_equal_pair_mix_pp"]
        if mix:
            ax_effect.scatter(float(mix), y, s=25, marker="D", facecolor="white",
                              edgecolor="black", linewidth=.8, zorder=4)

    for ax in (ax_support, ax_effect):
        ax.axhline(4.83, color="#777777", linestyle="--", linewidth=.8, zorder=1)
        ax.set_ylim(11.95, -.55)
        ax.tick_params(axis="y", length=0)
    ax_support.set_xlim(-.53, 1.53)
    ax_support.set_xticks([0, 1], ["T→T", "St→St"])
    ax_support.xaxis.set_ticks_position("top")
    ax_support.set_yticks(positions, [key[1] for key in keys])
    ax_support.spines["left"].set_visible(False)
    ax_support.spines["bottom"].set_visible(False)
    ax_support.set_xlabel("Pair-qualified offsets (technical)", labelpad=8)
    ax_effect.axvline(0, color="#555555", linestyle=":", linewidth=.9, zorder=1)
    ax_effect.set_xlim(-4.7, 10.2)
    ax_effect.set_xticks([-4, 0, 4, 8])
    ax_effect.set_xlabel("Pair-specific contrast (percentage points)")
    ax_effect.tick_params(axis="y", labelleft=False)
    ax_effect.spines["left"].set_visible(False)

    fig.text(.145, .948, "A", fontsize=12, fontweight="bold")
    fig.text(.49, .948, "B", fontsize=12, fontweight="bold")
    support_legend = [Patch(facecolor=WONG_BLUE, label="Strict ≥24"),
                      Patch(facecolor=WONG_ORANGE, label="Minimal only"),
                      Patch(facecolor=NE_GRAY, label="No qualified offset (NE)")]
    effect_legend = [Line2D([], [], marker="o", linestyle="None", color=WONG_BLUE,
                            markeredgecolor="black", markeredgewidth=.25, markersize=5, label="T→T"),
                     Line2D([], [], marker="s", linestyle="None", color=WONG_ORANGE,
                            markeredgecolor="black", markeredgewidth=.25, markersize=5, label="St→St"),
                     Line2D([], [], marker="D", linestyle="None", markerfacecolor="white",
                            markeredgecolor="black", markersize=5, label="Same-patient mean")]
    fig.legend(handles=support_legend, loc="lower left", bbox_to_anchor=(.16, .04),
               ncol=3, frameon=False, fontsize=7.5)
    ax_effect.legend(handles=effect_legend, loc="upper right", bbox_to_anchor=(1.0, 1.04),
                     ncol=3, frameon=False, fontsize=7.0, handletextpad=.3, columnspacing=.7)

    OUT_BASE.parent.mkdir(parents=True, exist_ok=True)
    pdf = OUT_BASE.with_suffix(".pdf")
    png = OUT_BASE.with_suffix(".png")
    fig.savefig(pdf)
    fig.savefig(png, dpi=301)
    plt.close(fig)
    metadata = {"input": str(INPUT), "output_pdf": str(pdf), "output_png": str(png),
                "patients": len(keys), "figure_role": "post_hoc_support_and_minimal_effects; no cohort CI"}
    OUT_BASE.with_suffix(".json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    print(pdf)
    print(png)


if __name__ == "__main__":
    main()
