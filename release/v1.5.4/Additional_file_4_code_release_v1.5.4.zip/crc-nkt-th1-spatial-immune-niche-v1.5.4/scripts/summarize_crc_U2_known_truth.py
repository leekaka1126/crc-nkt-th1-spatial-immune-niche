#!/usr/bin/env python
"""Audit and summarize all attempted U2 cohorts without dropping NE rows.

Analysis: independent-replicate Monte Carlo summaries of the locked U2 DGM.
Date: 2026-10-13. No randomness is used in this script.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd


PAIRS = ("TT", "TSt", "StT", "StSt")
EXPECTED_SCENARIOS = [f"{g}_{d}_{s}" for g in ("G1", "G2", "G3")
                      for d in ("D1", "D2") for s in ("S0", "S1", "S2")]
STAGE_BASE = {"formal": 2_000_042, "calibration": 3_000_042}
LOCKED_CODE_SHA = "e8308bd8b983afc1c72a14be7cc90641bc084b28dfccd3f934c63a79b2a0f8be"
LOCKED_E4_SHA = "c1b23ec51b16f74dca4399ac6fde9ccad516192b9cce9e13cfd0fe9a945f5232"
LOCKED_PANEL_SHA = "0cbdebffb6bd63b12e962e1863a91807b73eccf7e9373bfa33dc25587d200a65"


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def number(value) -> float:
    return float(value) if value is not None and math.isfinite(float(value)) else math.nan


def mean_se(values) -> tuple[float, float, int]:
    x = np.asarray([number(v) for v in values], float)
    x = x[np.isfinite(x)]
    if not len(x):
        return math.nan, math.nan, 0
    return (float(x.mean()), float(x.std(ddof=1) / math.sqrt(len(x)))
            if len(x) > 1 else math.nan, len(x))


def wilson(success: int, total: int) -> tuple[float, float]:
    if total == 0:
        return math.nan, math.nan
    z = 1.959963984540054
    p = success / total
    den = 1 + z * z / total
    center = (p + z * z / (2 * total)) / den
    half = z * math.sqrt(p * (1 - p) / total + z * z / (4 * total * total)) / den
    return center - half, center + half


def load_stage(directory: Path, expected_stage: str,
               expected_reps: int) -> tuple[dict, list[dict], list[dict], list[dict]]:
    manifest_path = directory / "RUN_MANIFEST.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if manifest["stage"] != expected_stage or manifest["reps_per_cell"] != expected_reps:
        raise AssertionError(f"Wrong stage or replicate count: {manifest_path}")
    if manifest["scenarios"] != EXPECTED_SCENARIOS or manifest["patients_per_replicate"] != 6:
        raise AssertionError(f"Unexpected scenario/patient grid: {manifest_path}")
    files = sorted(directory.glob("G*_r*.json"))
    if len(files) != len(EXPECTED_SCENARIOS) * expected_reps:
        raise AssertionError(f"Expected {len(EXPECTED_SCENARIOS)*expected_reps} files; found {len(files)}")
    replicates: list[dict] = []
    sections: list[dict] = []
    patients: list[dict] = []
    seen: set[tuple[str, int]] = set()
    for path in files:
        item = json.loads(path.read_text(encoding="utf-8"))
        scenario = item.get("scenario_id")
        replicate = item.get("replicate_id")
        if scenario not in EXPECTED_SCENARIOS or not isinstance(replicate, int):
            raise AssertionError(f"Bad scenario/replicate identity: {path}")
        key = (scenario, replicate)
        expected_seed = (STAGE_BASE[expected_stage] +
                         EXPECTED_SCENARIOS.index(scenario) * 100_000 + replicate)
        if (key in seen or replicate < 0 or replicate >= expected_reps or
                item.get("seed") != expected_seed or
                path.name != f"{scenario}_r{replicate:05d}.json"):
            raise AssertionError(f"Duplicate or incorrect seed/file identity: {path}")
        seen.add(key)
        if item.get("run_status") != "PASS":
            raise AssertionError(f"Recorded implementation error (do not drop): {path}: {item.get('error')}")
        if item.get("attempted_patients") != 6 or len(item.get("patients", [])) != 6:
            raise AssertionError(f"Patient denominator mismatch: {path}")
        if item.get("attempted_sections") != len(item.get("sections", [])):
            raise AssertionError(f"Section denominator mismatch: {path}")
        if item["status"] not in ("ESTIMABLE", "NE_COHORT"):
            raise AssertionError(f"Unrecognized status: {path}")
        h, f, fa, fs, q = [number(item.get(col)) for col in
                          ("H_pp", "F_pp", "F_eligible_patients_pp",
                           "F_selected_sections_pp", "Q_pp")]
        if not math.isfinite(f):
            raise AssertionError(f"Full-support oracle absent: {path}")
        if item["status"] == "ESTIMABLE":
            if not all(map(math.isfinite, (h, f, fa, fs, q))):
                raise AssertionError(f"Estimable cohort has missing decomposition: {path}")
            if not math.isclose(h - f, (h - q) + (q - fs) + (fs - fa) + (fa - f),
                                abs_tol=1e-10, rel_tol=0):
                raise AssertionError(f"Decomposition mismatch: {path}")
        elif any(math.isfinite(v) for v in (h, fa, fs, q)):
            raise AssertionError(f"NE cohort improperly received a selected statistic: {path}")
        flat = {k: v for k, v in item.items() if k not in ("sections", "patients")}
        flat["stage"] = expected_stage
        flat["file_sha256"] = digest(path)
        flat["H_minus_Q_pp"] = h - q
        flat["Q_minus_Fselected_pp"] = q - fs
        flat["Fselected_minus_Feligible_pp"] = fs - fa
        flat["Feligible_minus_Fall_pp"] = fa - f
        flat["H_minus_F_pp"] = h - f
        replicates.append(flat)
        for row in item["sections"]:
            sections.append({"stage": expected_stage, "scenario_id": scenario,
                             "replicate_id": replicate, **row})
        for row in item["patients"]:
            patients.append({"stage": expected_stage, "scenario_id": scenario,
                             "replicate_id": replicate, **row})
    return manifest, replicates, sections, patients


def summarize(formal: pd.DataFrame, calibration: pd.DataFrame,
              sections: pd.DataFrame) -> pd.DataFrame:
    results = []
    for scenario in EXPECTED_SCENARIOS:
        f = formal.loc[formal.scenario_id == scenario].copy()
        c = calibration.loc[calibration.scenario_id == scenario].copy()
        sf = sections.loc[sections.scenario_id == scenario].copy()
        n = len(f)
        n_ne = int((f.status == "NE_COHORT").sum())
        ne_low, ne_high = wilson(n_ne, n)
        n_eligible = n - n_ne
        mu_f, se_mu_f, _ = mean_se(c.F_pp)
        mu_h, se_mu_h, n_cal_h = mean_se(c.H_pp)
        out = {
            "scenario_id": scenario, "geometry": scenario[:2],
            "detection": scenario[3:5], "signal": scenario[6:],
            "attempted_replicates": n, "eligible_replicates": n_eligible,
            "ne_replicates": n_ne, "p_ne": n_ne / n,
            "p_ne_mcse": math.sqrt((n_ne / n) * (1 - n_ne / n) / n),
            "p_ne_wilson_low": ne_low, "p_ne_wilson_high": ne_high,
            "attempted_patients": int(f.attempted_patients.sum()),
            "attempted_sections": len(sf),
            "passing_sections": int((sf.native_status == "PASS").sum()),
            "p_section_pass": float((sf.native_status == "PASS").mean()),
            "is_detection_mean": float(f.is_detection_mean.mean()),
            "ss_detection_mean": float(f.ss_detection_mean.mean()),
            "calibration_replicates": len(c),
            "calibration_H_eligible": n_cal_h,
            "mu_F_pp": mu_f, "mu_F_mcse_pp": se_mu_f,
            "mu_H_given_A_pp": mu_h, "mu_H_given_A_mcse_pp": se_mu_h,
        }
        section_pass_by_rep = sf.assign(passed=sf.native_status == "PASS").groupby(
            "replicate_id").passed.mean().to_numpy(float)
        out["p_section_pass_cluster_mcse"] = float(
            section_pass_by_rep.std(ddof=1) / math.sqrt(len(section_pass_by_rep)))
        for pair in PAIRS:
            for rule in ("minimal", "strict"):
                col = f"{pair}_{rule}_patients"
                count = int(f[col].sum())
                by_rep = f[col].to_numpy(float) / 6.0
                out[f"{pair}_{rule}_patients"] = count
                out[f"{pair}_{rule}_rate"] = count / (6 * n)
                out[f"{pair}_{rule}_cluster_mcse"] = float(by_rep.std(ddof=1) / math.sqrt(n))
        for rule in ("minimal", "strict"):
            col = f"same_patient_both_{rule}"
            count = int(f[col].sum())
            out[f"{col}_count"] = count
            out[f"{col}_rate"] = count / (6 * n)
        accepted = sf.loc[sf.native_status == "PASS"]
        support_by_rep = accepted.groupby("replicate_id").retained_ss_low_fraction_accepted.mean()
        support_mean, support_se, support_n = mean_se(support_by_rep)
        out["retained_ss_low_fraction_mean"] = support_mean
        out["retained_ss_low_fraction_mcse"] = support_se
        out["retained_ss_low_fraction_replicates"] = support_n
        for metric in ("H_minus_Q_pp", "Q_minus_Fselected_pp",
                       "Fselected_minus_Feligible_pp", "Feligible_minus_Fall_pp",
                       "H_minus_F_pp", "H_pp", "F_pp", "Q_pp"):
            mean, se, count = mean_se(f[metric])
            out[f"{metric}_mean"] = mean
            out[f"{metric}_mcse"] = se
            out[f"{metric}_n"] = count
        eligible = f.loc[f.status == "ESTIMABLE"]
        ci = eligible.loc[eligible.bootstrap_available == True].copy()
        for target, reference in (("H_given_A", mu_h), ("F", mu_f)):
            if math.isfinite(reference) and len(ci):
                covered = int(((ci.bootstrap_low_pp <= reference) &
                               (reference <= ci.bootstrap_high_pp)).sum())
                lo, hi = wilson(covered, len(ci))
                out[f"reference_inclusion_{target}_n"] = len(ci)
                out[f"reference_inclusion_{target}_count"] = covered
                out[f"reference_inclusion_{target}_rate"] = covered / len(ci)
                out[f"reference_inclusion_{target}_wilson_low"] = lo
                out[f"reference_inclusion_{target}_wilson_high"] = hi
            else:
                out[f"reference_inclusion_{target}_n"] = len(ci)
                out[f"reference_inclusion_{target}_count"] = math.nan
                out[f"reference_inclusion_{target}_rate"] = math.nan
                out[f"reference_inclusion_{target}_wilson_low"] = math.nan
                out[f"reference_inclusion_{target}_wilson_high"] = math.nan
        results.append(out)
    return pd.DataFrame(results)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--formal", type=Path, required=True)
    parser.add_argument("--calibration", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--formal-reps", type=int, default=500)
    parser.add_argument("--calibration-reps", type=int, default=200)
    args = parser.parse_args()
    mf, rf, sf, pf = load_stage(args.formal, "formal", args.formal_reps)
    mc, rc, sc, pc = load_stage(args.calibration, "calibration", args.calibration_reps)
    if (mf["code_sha256"] != LOCKED_CODE_SHA or mf["e4_sha256"] != LOCKED_E4_SHA or
            mf["panel_sha256"] != LOCKED_PANEL_SHA):
        raise AssertionError("Formal run does not match the pre-run locked code and scorer")
    if mf["code_sha256"] != mc["code_sha256"] or mf["e4_sha256"] != mc["e4_sha256"]:
        raise AssertionError("Formal and calibration implementations differ")
    if mf["panel_sha256"] != mc["panel_sha256"]:
        raise AssertionError("Formal and calibration scorers differ")
    args.out.mkdir(parents=True, exist_ok=True)
    formal = pd.DataFrame(rf).sort_values(["scenario_id", "replicate_id"])
    calibration = pd.DataFrame(rc).sort_values(["scenario_id", "replicate_id"])
    section_df = pd.DataFrame(sf).sort_values(["scenario_id", "replicate_id", "patient_id", "section_id"])
    patient_df = pd.DataFrame(pf).sort_values(["scenario_id", "replicate_id", "patient_id"])
    formal.to_csv(args.out / "U2_formal_all_attempts.csv", index=False)
    calibration.to_csv(args.out / "U2_independent_calibration_all_attempts.csv", index=False)
    section_df.to_csv(args.out / "U2_formal_all_sections.csv", index=False)
    patient_df.to_csv(args.out / "U2_formal_all_patients.csv", index=False)
    table = summarize(formal, calibration, section_df)
    table.to_csv(args.out / "U2_scenario_summary.csv", index=False)
    output_hashes = {name: digest(args.out / name) for name in (
        "U2_formal_all_attempts.csv", "U2_independent_calibration_all_attempts.csv",
        "U2_formal_all_sections.csv", "U2_formal_all_patients.csv",
        "U2_scenario_summary.csv")}
    manifest = {
        "formal_manifest": mf, "calibration_manifest": mc,
        "formal_attempts": len(formal), "calibration_attempts": len(calibration),
        "formal_sections": len(section_df), "formal_patients": len(patient_df),
        "summarizer_sha256": digest(Path(__file__)),
        "output_sha256": output_hashes,
        "interpretation": "Synthetic; NE retained; conditional contrasts not biological effects or causal bias",
    }
    (args.out / "U2_summary_manifest.json").write_text(
        json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    print(table[["scenario_id", "attempted_replicates", "ne_replicates",
                 "eligible_replicates", "H_minus_F_pp_mean"]].to_string(index=False))


if __name__ == "__main__":
    main()
