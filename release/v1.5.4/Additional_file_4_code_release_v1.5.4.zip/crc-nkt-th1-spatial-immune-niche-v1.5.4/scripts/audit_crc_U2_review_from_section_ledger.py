#!/usr/bin/env python
"""Independently audit U2 aggregation from saved section and attempt ledgers.

This does not rebuild spot graphs, latent q(s), or edge-level oracles. It checks
the distinct patient/section selection targets and scenario denominators from
the lowest-level *saved* oracle records. No frozen U2 result is overwritten.
"""
from __future__ import annotations

import csv
import hashlib
import json
import math
from collections import Counter, defaultdict
from pathlib import Path
from statistics import mean, stdev


ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "results/CRC_U2_summary_v1_2026-10-13"
OUTPUT = ROOT / "reports/CRC_U2_review_ledger_audit_2026-10-13.json"
CONTRIBUTORS = ROOT / "manuscript/CRC_NKT_v11_1/supplementary/Table_S17d_U2_contributing_patients.csv"
FILES = {
    "sections": DATA / "U2_formal_all_sections.csv",
    "attempts": DATA / "U2_formal_all_attempts.csv",
    "calibration": DATA / "U2_independent_calibration_all_attempts.csv",
    "summary": DATA / "U2_scenario_summary.csv",
    "manifest": DATA / "U2_summary_manifest.json",
}
TOL = 1e-10


def rows(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def number(value: str | None) -> float:
    if value is None or value == "":
        return math.nan
    return float(value)


def finite_mean(values: list[float]) -> float:
    usable = [x for x in values if math.isfinite(x)]
    return mean(usable) if usable else math.nan


def assert_close(actual: float, expected: float, label: str) -> float:
    if math.isnan(actual) and math.isnan(expected):
        return 0.0
    delta = abs(actual - expected)
    if not math.isfinite(delta) or delta > TOL:
        raise AssertionError(f"{label}: derived={actual}, saved={expected}, delta={delta}")
    return delta


def wilson(events: int, attempts: int) -> tuple[float, float]:
    z = 1.959963984540054
    p = events / attempts
    denominator = 1 + z * z / attempts
    center = (p + z * z / (2 * attempts)) / denominator
    radius = z * math.sqrt(p * (1 - p) / attempts + z * z / (4 * attempts * attempts)) / denominator
    return center - radius, center + radius


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> None:
    manifest = json.loads(FILES["manifest"].read_text(encoding="utf-8"))
    for name in ("sections", "attempts", "calibration", "summary"):
        filename = FILES[name].name
        expected = manifest["output_sha256"].get(filename)
        if expected and sha256(FILES[name]) != expected:
            raise AssertionError(f"Frozen-file hash mismatch: {filename}")

    sections_by_replicate: dict[tuple[str, int], list[dict[str, str]]] = defaultdict(list)
    section_count = 0
    for row in rows(FILES["sections"]):
        if row["stage"] != "formal":
            raise AssertionError("Non-formal section in formal ledger")
        key = (row["scenario_id"], int(row["replicate_id"]))
        sections_by_replicate[key].append(row)
        section_count += 1
    attempts = rows(FILES["attempts"])
    calibration = rows(FILES["calibration"])
    summaries = {r["scenario_id"]: r for r in rows(FILES["summary"])}
    scenario_order = manifest["formal_manifest"]["scenarios"]
    if len(attempts) != 9000 or len(calibration) != 3600 or section_count != 72861:
        raise AssertionError("Unexpected formal/calibration/section denominator")
    if set(summaries) != set(scenario_order) or len(summaries) != 18:
        raise AssertionError("Scenario registry mismatch")

    formal_keys: set[tuple[str, int]] = set()
    formal_seeds: set[int] = set()
    max_abs_delta = 0.0
    max_identity_delta = 0.0
    by_scenario: dict[str, list[dict[str, str]]] = defaultdict(list)
    patient_histogram: dict[str, Counter[int]] = defaultdict(Counter)
    for row in attempts:
        scenario = row["scenario_id"]
        rep = int(row["replicate_id"])
        key = (scenario, rep)
        if key in formal_keys or scenario not in summaries or rep not in range(500):
            raise AssertionError(f"Duplicate/invalid formal key {key}")
        formal_keys.add(key)
        seed = int(row["seed"])
        if seed in formal_seeds or seed != 2000042 + scenario_order.index(scenario) * 100000 + rep:
            raise AssertionError(f"Formal seed mismatch/collision {key}")
        formal_seeds.add(seed)
        if row["stage"] != "formal" or row["run_status"] != "PASS":
            raise AssertionError(f"Implementation failure or wrong stage {key}")
        group = sections_by_replicate.get(key, [])
        if len(group) != int(row["attempted_sections"]):
            raise AssertionError(f"Section count mismatch {key}")
        by_patient: dict[str, list[dict[str, str]]] = defaultdict(list)
        for section in group:
            by_patient[section["patient_id"]].append(section)
        if set(by_patient) != {f"P{i:02d}" for i in range(1, 7)}:
            raise AssertionError(f"Patient inventory mismatch {key}")
        patient_values = []
        for patient_sections in by_patient.values():
            passing = [s for s in patient_sections if s["native_status"] == "PASS"]
            patient_values.append({
                "H": finite_mean([number(s["native_effect_pp"]) for s in passing]),
                "Q": finite_mean([number(s["oracle_selected_pp"]) for s in passing]),
                "F": finite_mean([number(s["oracle_full_pp"]) for s in patient_sections]),
                "F_selected": finite_mean([number(s["oracle_full_pp"]) for s in passing]),
            })
        eligible = [p for p in patient_values if math.isfinite(p["H"])]
        calculated = {
            "H_pp": finite_mean([p["H"] for p in eligible]),
            "Q_pp": finite_mean([p["Q"] for p in eligible]),
            "F_pp": finite_mean([p["F"] for p in patient_values]),
            "F_eligible_patients_pp": finite_mean([p["F"] for p in eligible]),
            "F_selected_sections_pp": finite_mean([p["F_selected"] for p in eligible]),
        }
        if int(row["estimable_patients"]) != len(eligible):
            raise AssertionError(f"Eligible patient count mismatch {key}")
        if int(row["full_oracle_patients"]) != sum(math.isfinite(p["F"]) for p in patient_values):
            raise AssertionError(f"Full-oracle patient count mismatch {key}")
        for field, derived in calculated.items():
            max_abs_delta = max(max_abs_delta, assert_close(derived, number(row[field]), f"{key} {field}"))
        h, q, f, fe, fs = (calculated[field] for field in
                           ("H_pp", "Q_pp", "F_pp", "F_eligible_patients_pp", "F_selected_sections_pp"))
        if math.isfinite(h):
            parts = [(h - q), (q - fs), (fs - fe), (fe - f)]
            for field, derived in zip(("H_minus_Q_pp", "Q_minus_Fselected_pp",
                                       "Fselected_minus_Feligible_pp", "Feligible_minus_Fall_pp"), parts):
                max_abs_delta = max(max_abs_delta, assert_close(derived, number(row[field]), f"{key} {field}"))
            max_identity_delta = max(max_identity_delta, abs((h - f) - sum(parts)))
            max_abs_delta = max(max_abs_delta, assert_close(h - f, number(row["H_minus_F_pp"]), f"{key} H-F"))
        elif row["status"] != "NE_COHORT":
            raise AssertionError(f"NE status mismatch {key}")
        patient_histogram[scenario][len(eligible)] += 1
        by_scenario[scenario].append(row)
    if set(formal_keys) != set(sections_by_replicate):
        raise AssertionError("Orphaned sections or missing attempt")

    calibration_by_scenario: dict[str, list[dict[str, str]]] = defaultdict(list)
    calibration_seeds: set[int] = set()
    formal_seed_scenario = {int(r["seed"]): r["scenario_id"] for r in attempts}
    cross_stage_seed_reuse: Counter[str] = Counter()
    for row in calibration:
        scenario = row["scenario_id"]
        rep = int(row["replicate_id"])
        seed = int(row["seed"])
        if scenario not in summaries or rep not in range(200) or seed in calibration_seeds:
            raise AssertionError("Invalid calibration replicate/seed")
        if seed != 3000042 + scenario_order.index(scenario) * 100000 + rep:
            raise AssertionError("Calibration seed schedule mismatch")
        if seed in formal_seed_scenario:
            other_scenario = formal_seed_scenario[seed]
            if other_scenario == scenario:
                raise AssertionError("Formal and calibration seeds overlap within a scenario")
            cross_stage_seed_reuse[f"{other_scenario} -> {scenario}"] += 1
        calibration_seeds.add(seed)
        calibration_by_scenario[scenario].append(row)

    scenario_audit = []
    for scenario in scenario_order:
        group = by_scenario[scenario]
        calibration_group = calibration_by_scenario[scenario]
        saved = summaries[scenario]
        if len(group) != 500 or len(calibration_group) != 200 or sum(patient_histogram[scenario].values()) != 500:
            raise AssertionError(f"Scenario denominator mismatch {scenario}")
        ne = patient_histogram[scenario][0]
        ci_available = [r for r in group if r["bootstrap_available"] == "True"]
        h_calibration = [number(r["H_pp"]) for r in calibration_group if math.isfinite(number(r["H_pp"]))]
        f_calibration = [number(r["F_pp"]) for r in calibration_group if math.isfinite(number(r["F_pp"]))]
        mu_h = mean(h_calibration)
        mu_f = mean(f_calibration)
        h_mcse = stdev(h_calibration) / math.sqrt(len(h_calibration))
        f_mcse = stdev(f_calibration) / math.sqrt(len(f_calibration))
        shifts = [number(r["Q_minus_Fselected_pp"]) for r in group
                  if math.isfinite(number(r["Q_minus_Fselected_pp"]))]
        strict_patients = sum(int(r["same_patient_both_strict"]) for r in group)
        inclusion = sum(number(r["bootstrap_low_pp"]) <= mu_h <= number(r["bootstrap_high_pp"])
                        for r in ci_available)
        low, high = wilson(ne, 500)
        comparisons = {
            "attempted_replicates": 500,
            "eligible_replicates": 500 - ne,
            "ne_replicates": ne,
            "p_ne": ne / 500,
            "p_ne_wilson_low": low,
            "p_ne_wilson_high": high,
            "calibration_replicates": 200,
            "calibration_H_eligible": len(h_calibration),
            "mu_H_given_A_pp": mu_h,
            "mu_H_given_A_mcse_pp": h_mcse,
            "mu_F_pp": mu_f,
            "mu_F_mcse_pp": f_mcse,
            "Q_minus_Fselected_pp_n": len(shifts),
            "Q_minus_Fselected_pp_mean": mean(shifts),
            "Q_minus_Fselected_pp_mcse": stdev(shifts) / math.sqrt(len(shifts)),
            "same_patient_both_strict_count": strict_patients,
            "same_patient_both_strict_rate": strict_patients / 3000,
            "reference_inclusion_H_given_A_n": len(ci_available),
            "reference_inclusion_H_given_A_count": inclusion,
        }
        for field, derived in comparisons.items():
            max_abs_delta = max(max_abs_delta, assert_close(float(derived), number(saved[field]), f"{scenario} {field}"))
        scenario_audit.append({
            "scenario_id": scenario,
            "attempts": 500,
            "nonestimable": ne,
            "contributing_patients_0_to_6": [patient_histogram[scenario][i] for i in range(7)],
            "nominal_interval_available": len(ci_available),
            "reference_included": inclusion,
            "calibration_H_eligible": len(h_calibration),
            "same_patient_both_strict": strict_patients,
        })
    g3 = [r for r in scenario_audit if r["scenario_id"].startswith("G3_")]
    if sum(r["nonestimable"] for r in g3) != 363:
        raise AssertionError("G3 non-estimability check failed")
    if sum(r["contributing_patients_0_to_6"][1] for r in g3) != 947:
        raise AssertionError("G3 one-patient support check failed")
    if sum(r["contributing_patients_0_to_6"][6] for r in g3) != 7:
        raise AssertionError("G3 six-patient support check failed")

    output = {
        "audit_scope": "Independent aggregation from saved section-level H/Q/F oracles; not an independent graph, q(s), or edge-level oracle implementation",
        "audit_script_sha256": sha256(Path(__file__)),
        "source_sha256": {key: sha256(path) for key, path in FILES.items()},
        "formal_attempts": len(attempts),
        "formal_sections": section_count,
        "calibration_attempts": len(calibration),
        "cross_stage_seed_reuse_different_scenarios": dict(cross_stage_seed_reuse),
        "max_saved_vs_recomputed_absolute_pp": max_abs_delta,
        "max_four_part_identity_absolute_pp": max_identity_delta,
        "g3_nonestimable_all_attempts": 363,
        "g3_one_contributor_all_attempts": 947,
        "g3_six_contributors_all_attempts": 7,
        "scenario_audit": scenario_audit,
    }
    OUTPUT.write_text(json.dumps(output, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    with CONTRIBUTORS.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["scenario_id", "attempted_cohorts", "n0_nonestimable", "n1_contributor",
                         "n2_contributors", "n3_contributors", "n4_contributors",
                         "n5_contributors", "n6_contributors", "interval_available"])
        for item in scenario_audit:
            writer.writerow([item["scenario_id"], item["attempts"],
                             *item["contributing_patients_0_to_6"], item["nominal_interval_available"]])
    print(f"PASS: 9000 attempts, {section_count} sections, 3600 calibration attempts; "
          f"max delta {max_abs_delta:.3g} pp; audit {OUTPUT}; contributors {CONTRIBUTORS}")


if __name__ == "__main__":
    main()
