#!/usr/bin/env python
"""U2 synthetic CRC spot simulation against the frozen E4 implementation.

Analysis: known-truth estimability and support-target simulation (not patient data)
Date: 2026-10-13
Random seed: 42, deterministic stage/scenario/replicate substreams
Python: 3.14; key packages: numpy, pandas, scipy (versions in run manifest)

The pilot is a technical gate. Formal results require a separately frozen protocol.
Every attempted replicate is checkpointed, including NE and errors. No real CRC
outcome or the observed E4/U1 effect is used to generate synthetic signals.
"""
from __future__ import annotations

import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import platform
import sys
import time

import numpy as np
import pandas as pd
import scipy
from scipy.spatial import cKDTree


np.random.seed(42)
ROOT = Path(__file__).resolve().parents[1]
RC7 = ROOT / "manuscript/CRC_NKT_v11_1/code_release_v11_10_0_rc7"
E4_FILE = RC7 / "scripts/run_valdeolivas_pathology_matched_replication.py"
PANEL_FILE = RC7 / "manuscript/CRC_NKT_v11_1/code_release/scripts/05_spatial_neighborhood_analysis.py"
SCHEMA_VERSION = "U2-locked-1.0"
GEOMETRIES = ("G1", "G2", "G3")
DETECTIONS = ("D1", "D2")
SIGNALS = ("S0", "S1", "S2")
PAIRS = ("TT", "TSt", "StT", "StSt")
SEED_BASE = {"pilot": 1_000_042, "formal": 2_000_042, "calibration": 3_000_042}


def import_file(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot import {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


e4 = import_file("u2_frozen_e4", E4_FILE)
panel = import_file("u2_frozen_panel", PANEL_FILE)
OFFSETS = e4.shift_mod.select_offsets()
assert len(OFFSETS) == 96
assert len(panel.IMMUNE_GENES) == 18 and len(panel.MATRIX_GENES) == 13


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def json_safe(value):
    if isinstance(value, dict):
        return {key: json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_safe(item) for item in value]
    if isinstance(value, (float, np.floating)):
        return float(value) if math.isfinite(float(value)) else None
    if isinstance(value, np.integer):
        return int(value)
    if isinstance(value, np.bool_):
        return bool(value)
    return value


def sigmoid(x: np.ndarray) -> np.ndarray:
    return 1.0 / (1.0 + np.exp(-np.clip(x, -30.0, 30.0)))


def physical(ar: np.ndarray, ac: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    # Visium parity: (array_row + array_col) mod 2 = 0.
    x = (ac.astype(float) - 29.0) / 25.0
    y = (ar.astype(float) - 12.5) * math.sqrt(3.0) / 25.0
    return x, y


def tissue_geometry(geometry: str, x: np.ndarray, y: np.ndarray,
                    tumor_shift: float) -> tuple[np.ndarray, np.ndarray]:
    radius = np.sqrt((x / 1.0) ** 2 + (y / 0.86) ** 2)
    in_tissue = radius < (0.93 if geometry == "G3" else 1.0)
    if geometry == "G1":
        tumor = radius < 0.58 + tumor_shift
    elif geometry == "G2":
        # Interdigitated tumor islands yield a high-boundary geometry that can
        # support cross-compartment pairs under the unchanged 30/30 gate.
        tumor = np.sin(9.0 * x + 0.4 * np.sin(3.0 * y)) * np.sin(9.0 * y) > tumor_shift
    elif geometry == "G3":
        holes = (((x + 0.32) ** 2 + (y - 0.22) ** 2) < 0.08) | (
            ((x - 0.31) ** 2 + (y + 0.30) ** 2) < 0.07)
        in_tissue &= ~holes & ~((x > 0.65) & (y > -0.10))
        tumor = (np.sin(4.7 * x) * np.cos(5.4 * y) + 0.45 * np.sin(3.0 * y)) > 0.22 + tumor_shift
    else:
        raise ValueError(geometry)
    return in_tissue, tumor


def immune_field(x: np.ndarray, y: np.ndarray, tumor: np.ndarray,
                 phase_i: float, patient_i: float) -> np.ndarray:
    return (-1.20 + 0.58 * np.sin(2.7 * x + phase_i) * np.cos(2.4 * y - phase_i)
            + 0.40 * tumor.astype(float) + patient_i)


def pathology_boundary_distance(geometry: str, x: np.ndarray, y: np.ndarray,
                                tumor_shift: float) -> np.ndarray:
    """Analytic distance proxy to the *true generated compartment* boundary."""
    if geometry == "G1":
        radius = np.sqrt((x / 1.0) ** 2 + (y / 0.86) ** 2)
        return np.abs(radius - (0.58 + tumor_shift))
    if geometry == "G2":
        field = np.sin(9.0 * x + 0.4 * np.sin(3.0 * y)) * np.sin(9.0 * y)
        return np.abs(field - tumor_shift) / 3.0
    if geometry == "G3":
        field = np.sin(4.7 * x) * np.cos(5.4 * y) + 0.45 * np.sin(3.0 * y)
        return np.abs(field - (0.22 + tumor_shift)) / 2.0
    raise ValueError(geometry)


def stromal_probability(x: np.ndarray, y: np.ndarray, tumor: np.ndarray,
                        phase_i: float, phase_s: float, patient_i: float,
                        patient_s: float, signal: str, geometry: str,
                        tumor_shift: float) -> np.ndarray:
    base = (-1.28 + 0.62 * np.cos(2.4 * x + phase_s) * np.sin(2.8 * y - phase_s)
            + 0.52 * (~tumor).astype(float) + patient_s)
    immune_smooth = immune_field(x, y, tumor, phase_i, patient_i) + 1.20
    distance_to_boundary = pathology_boundary_distance(geometry, x, y, tumor_shift)
    if signal == "S1":
        base += 0.72 * immune_smooth * (distance_to_boundary >= 0.16)
    elif signal == "S2":
        # Synthetic interface-localized dependence, not a causal cell-contact model.
        base += 0.85 * immune_smooth * (distance_to_boundary < 0.16)
    elif signal != "S0":
        raise ValueError(signal)
    return sigmoid(base)


def make_section(rng: np.random.Generator, geometry: str, detection: str,
                 signal: str, patient_params: dict[str, float], section_id: int
                 ) -> tuple[pd.DataFrame, dict[str, float], np.ndarray, dict[str, object]]:
    rr, cc = np.meshgrid(np.arange(26), np.arange(30), indexing="ij")
    ar_all = rr.ravel().astype(int)
    ac_all = (2 * cc + (rr % 2)).ravel().astype(int)
    x_all, y_all = physical(ar_all, ac_all)
    inside, tumor_all = tissue_geometry(geometry, x_all, y_all, patient_params["tumor_shift"])
    ar, ac = ar_all[inside], ac_all[inside]
    x, y = x_all[inside], y_all[inside]
    tumor = tumor_all[inside]
    phase_i = patient_params["phase_i"] + rng.normal(0.0, 0.08)
    phase_s = patient_params["phase_s"] + rng.normal(0.0, 0.08)
    patient_i = patient_params["patient_i"]
    patient_s = patient_params["patient_s"]
    pi = sigmoid(immune_field(x, y, tumor, phase_i, patient_i))
    q = stromal_probability(x, y, tumor, phase_i, phase_s, patient_i,
                            patient_s, signal, geometry, patient_params["tumor_shift"])
    immune_truth = rng.binomial(1, pi, size=len(ar)).astype(bool)
    stroma_truth = rng.binomial(1, q, size=len(ar)).astype(bool)
    # Poisson counts are deliberately sparse. Rates are calibrated only to
    # detection, not to an observed E4/U1 effect or its direction.
    immune_rate = 0.105 if detection == "D1" else 0.034
    stroma_rate = 0.23 if detection == "D1" else 0.075
    patient_depth = math.exp(patient_params["depth_re"] + rng.normal(0.0, 0.06))
    library = rng.lognormal(mean=0.0, sigma=0.32, size=len(ar)) * patient_depth
    i_gene = np.exp(np.linspace(-0.60, 0.60, 18))
    s_gene = np.exp(np.linspace(-0.55, 0.55, 13))
    i_lam = (immune_rate * library[:, None] * i_gene[None, :]
             * np.exp(1.18 * immune_truth[:, None] + 0.18 * tumor[:, None]))
    s_lam = (stroma_rate * library[:, None] * s_gene[None, :]
             * np.exp(1.10 * stroma_truth[:, None] + 0.25 * (~tumor)[:, None]))
    i_counts = rng.poisson(i_lam)
    s_counts = rng.poisson(s_lam)
    expression = pd.DataFrame(np.column_stack((i_counts, s_counts)),
                              columns=panel.IMMUNE_GENES + panel.MATRIX_GENES)
    is_score = panel.zmean(expression, panel.IMMUNE_GENES)
    ss_score = panel.zmean(expression, panel.MATRIX_GENES)
    if is_score.isna().all() or ss_score.isna().all():
        raise ValueError("Entire simulated panel score is missing")
    # E4 uses inclusive section-specific quartiles, including any ties.
    data = pd.DataFrame({
        "array_row": ar, "array_col": ac,
        "row": y * 100.0, "col": x * 100.0,
        "compartment": np.where(tumor, "tumor", "stroma"),
        "IS_high_q75": (is_score >= is_score.quantile(0.75)).to_numpy(bool),
        "SS_high_q75": (ss_score >= ss_score.quantile(0.75)).to_numpy(bool),
    })
    truth = {
        "phase_i": float(phase_i), "phase_s": float(phase_s),
        "patient_i": float(patient_i), "patient_s": float(patient_s),
        "signal": signal, "geometry": geometry,
        "tumor_shift": patient_params["tumor_shift"], "q": q,
    }
    qc = {
        "section_id": section_id, "spots": len(ar),
        "tumor_spots": int(tumor.sum()), "stroma_spots": int((~tumor).sum()),
        "is_detection": float((i_counts > 0).mean()),
        "ss_detection": float((s_counts > 0).mean()),
        "is_high_fraction": float(data.IS_high_q75.mean()),
        "ss_high_fraction": float(data.SS_high_q75.mean()),
        "is_variable_genes": int((expression[panel.IMMUNE_GENES].std(ddof=1) > 0).sum()),
        "ss_variable_genes": int((expression[panel.MATRIX_GENES].std(ddof=1) > 0).sum()),
    }
    if ((ar + ac) % 2).any() or data[["array_row", "array_col"]].duplicated().any():
        raise AssertionError("Synthetic lattice is not a unique Visium-parity grid")
    if (expression.to_numpy() < 0).any() or not np.issubdtype(expression.to_numpy().dtype, np.integer):
        raise AssertionError("Synthetic counts must be nonnegative integers")
    return data, truth, q, qc


def pair_arithmetic(source: np.ndarray, target: np.ndarray, mapped: np.ndarray,
                    eligible: np.ndarray, immune: np.ndarray, layer_binary: np.ndarray,
                    observed_outcome: np.ndarray, shifted_outcome: np.ndarray,
                    minimum: int) -> tuple[float, np.ndarray, np.ndarray]:
    """Independent vectorized E4 arithmetic; four directed pairs × two IS groups."""
    src = source[eligible]
    tgt = target[eligible]
    mpp = mapped[eligible]
    if len(src) == 0:
        return math.nan, np.zeros(4, bool), np.zeros(4, int)
    pair = layer_binary[src] * 2 + layer_binary[tgt]
    group = pair * 2 + immune[src].astype(int)
    counts = np.bincount(group, minlength=8).reshape(4, 2)
    obs = np.bincount(group, weights=observed_outcome[tgt], minlength=8).reshape(4, 2)
    sh = np.bincount(group, weights=shifted_outcome[mpp], minlength=8).reshape(4, 2)
    passed = (counts[:, 0] >= minimum) & (counts[:, 1] >= minimum)
    weights = np.minimum(counts[:, 0], counts[:, 1])
    if not passed.any():
        return math.nan, passed, weights
    d = (obs[passed, 1] - sh[passed, 1]) / counts[passed, 1] - (
        obs[passed, 0] - sh[passed, 0]) / counts[passed, 0]
    return float(np.average(d, weights=weights[passed])), passed, weights


def fast_matched_effect(data: pd.DataFrame) -> tuple[dict, list[dict]]:
    """Vectorized equivalent of frozen E4, subject to native identity tests."""
    xy = data[["row", "col"]].to_numpy(float)
    distance, neighbor = cKDTree(xy).query(xy, k=7)
    pitch = float(np.median(distance[:, 1]))
    valid = (distance[:, 1:] <= 1.6 * pitch).reshape(-1)
    all_source = np.repeat(np.arange(len(data)), 6)[valid]
    all_target = neighbor[:, 1:].reshape(-1)[valid]
    # All generated spots have strict tumor/stroma labels.
    source, target = all_source, all_target
    immune = data.IS_high_q75.to_numpy(bool)
    ss_high = data.SS_high_q75.to_numpy(bool)
    layer = data.compartment.eq("stroma").to_numpy(np.int8)
    selected = immune[source]
    base = {"status": "FAIL", "n_accepted_shifts": 0}
    if len(source) < 100 or int(selected.sum()) < 100:
        base["reason"] = "fewer than 100 strict local or IS-high strict edges"
        return base, []
    ss_low = ~ss_high[source]
    if min(int((ss_low & selected).sum()), int((ss_low & ~selected).sum())) < 30:
        base["reason"] = "fewer than 30 SS-low strict edges in one IS group"
        return base, []
    ar, ac = data.array_row.to_numpy(int), data.array_col.to_numpy(int)
    lookup = np.full((int(ar.max()) + 1, int(ac.max()) + 1), -1, dtype=np.int32)
    lookup[ar, ac] = np.arange(len(data), dtype=np.int32)
    shift_rows = []
    for dr, dc, _ in OFFSETS:
        rr, cc = ar[target] + dr, ac[target] + dc
        in_grid = (rr >= 0) & (rr < lookup.shape[0]) & (cc >= 0) & (cc < lookup.shape[1])
        mapped = np.full(len(target), -1, dtype=np.int32)
        mapped[in_grid] = lookup[rr[in_grid], cc[in_grid]]
        compatible = mapped >= 0
        compatible[compatible] &= layer[mapped[compatible]] == layer[target[compatible]]
        matched_high = int((compatible & selected).sum())
        effect = math.nan
        if matched_high < 100 or matched_high / int(selected.sum()) < 0.10:
            status = "FAIL_COVERAGE"
        else:
            effect, passed, _ = pair_arithmetic(
                source, target, mapped, compatible & ss_low, immune, layer,
                ss_high.astype(float), ss_high.astype(float), 30)
            status = "PASS" if math.isfinite(effect) and passed.any() else "FAIL_PAIR_MINIMUM"
        shift_rows.append({"shift_array_row": dr, "shift_array_col": dc,
                           "status": status, "observed_minus_shifted_IS_contrast": effect})
    accepted = [row["observed_minus_shifted_IS_contrast"]
                for row in shift_rows if row["status"] == "PASS"]
    base["n_accepted_shifts"] = len(accepted)
    if len(accepted) < 24:
        base["reason"] = f"only {len(accepted)} of 96 translations passed fixed thresholds"
        return base, shift_rows
    base["status"] = "PASS"
    base["reason"] = ""
    base["pathology_matched_shift_effect_fraction"] = float(np.mean(accepted))
    return base, shift_rows


def verify_native_equivalence(data: pd.DataFrame, fast: dict, fast_rows: list[dict]) -> None:
    native, native_rows = e4.matched_effect(data, OFFSETS)
    if fast["status"] != native["status"] or len(fast_rows) != len(native_rows):
        raise AssertionError("Fast/native E4 section status or shift-row count differs")
    if int(fast["n_accepted_shifts"]) != int(native.get("n_accepted_shifts", 0)):
        raise AssertionError("Fast/native accepted-offset count differs")
    for a, b in zip(fast_rows, native_rows):
        if a["status"] != b["status"] or a["shift_array_row"] != b["shift_array_row"] or (
                a["shift_array_col"] != b["shift_array_col"]):
            raise AssertionError("Fast/native offset identity or status differs")
        if a["status"] == "PASS" and abs(a["observed_minus_shifted_IS_contrast"] -
                                         b["observed_minus_shifted_IS_contrast"]) > 1e-12:
            raise AssertionError("Fast/native offset effect differs")
    if fast["status"] == "PASS" and abs(
            fast["pathology_matched_shift_effect_fraction"] -
            native["pathology_matched_shift_effect_fraction"]) > 1e-12:
        raise AssertionError("Fast/native section effect differs")


def section_oracles(data: pd.DataFrame, truth: dict[str, object], q: np.ndarray,
                    native: dict, shift_rows: list[dict]) -> tuple:
    """Full and selected oracle calculations with exact native-shift identity checks."""
    xy = data[["row", "col"]].to_numpy(float)
    distance, neighbor = cKDTree(xy).query(xy, k=7)
    pitch = float(np.median(distance[:, 1]))
    valid = (distance[:, 1:] <= 1.6 * pitch).reshape(-1)
    source = np.repeat(np.arange(len(data)), 6)[valid]
    target = neighbor[:, 1:].reshape(-1)[valid]
    immune = data.IS_high_q75.to_numpy(bool)
    ss_high = data.SS_high_q75.to_numpy(bool)
    layer = data.compartment.eq("stroma").to_numpy(np.int8)
    ar, ac = data.array_row.to_numpy(int), data.array_col.to_numpy(int)
    keep = ~ss_high[source]
    original_pair = layer[source] * 2 + layer[target]
    original_counts = np.bincount(original_pair[keep], minlength=4)
    original_high_counts = np.bincount(original_pair[keep & immune[source]], minlength=4)
    lookup = {(int(r), int(c)): i for i, (r, c) in enumerate(zip(ar, ac))}
    full_values: list[float] = []
    selected_values: list[float] = []
    retained_fractions: list[float] = []
    pair_offset_counts = np.zeros(4, int)
    native_shift = {(int(r["shift_array_row"]), int(r["shift_array_col"])): r for r in shift_rows}
    if shift_rows and len(native_shift) != len(OFFSETS):
        raise AssertionError("Native shift ledger does not contain 96 unique offsets")
    q = np.asarray(q, float)
    for dr, dc, _ in OFFSETS:
        # Hypothetical full-lattice translation: original target class is held
        # fixed even outside the sampled footprint. This defines F, not E4.
        tx, ty = physical(ar[target] + dr, ac[target] + dc)
        q_translated = stromal_probability(
            tx, ty, layer[target] == 0,
            float(truth["phase_i"]), float(truth["phase_s"]),
            float(truth["patient_i"]), float(truth["patient_s"]),
            str(truth["signal"]), str(truth["geometry"]),
            float(truth["tumor_shift"]),
        )
        pair = original_pair[keep]
        group = pair * 2 + immune[source[keep]].astype(int)
        counts = np.bincount(group, minlength=8).reshape(4, 2)
        obs = np.bincount(group, weights=q[target[keep]], minlength=8).reshape(4, 2)
        sh = np.bincount(group, weights=q_translated[keep], minlength=8).reshape(4, 2)
        passed = (counts[:, 0] >= 1) & (counts[:, 1] >= 1)
        if passed.any():
            weights = np.minimum(counts[passed, 0], counts[passed, 1])
            d = (obs[passed, 1] - sh[passed, 1]) / counts[passed, 1] - (
                obs[passed, 0] - sh[passed, 0]) / counts[passed, 0]
            full_values.append(float(np.average(d, weights=weights)))
        if native.get("status") != "PASS":
            continue
        native_row = native_shift[(dr, dc)]
        if native_row["status"] != "PASS":
            continue
        mapped = np.array([lookup.get((int(r + dr), int(c + dc)), -1)
                           for r, c in zip(ar[target], ac[target])], dtype=int)
        compatible = mapped >= 0
        compatible[compatible] &= layer[mapped[compatible]] == layer[target[compatible]]
        eligible = compatible & keep
        retained_fractions.append(float(eligible.sum() / max(1, keep.sum())))
        oracle_value, pair_pass, _ = pair_arithmetic(
            source, target, mapped, eligible, immune, layer, q, q, 30)
        observed_value, observed_pass, _ = pair_arithmetic(
            source, target, mapped, eligible, immune, layer,
            ss_high.astype(float), ss_high.astype(float), 30)
        native_value = float(native_row["observed_minus_shifted_IS_contrast"])
        if not math.isfinite(observed_value) or abs(observed_value - native_value) > 1e-12:
            raise AssertionError(f"Independent arithmetic mismatch: {observed_value} vs {native_value}")
        if not np.array_equal(pair_pass, observed_pass) or not math.isfinite(oracle_value):
            raise AssertionError("Oracle and native pair-support masks disagree")
        pair_offset_counts += pair_pass.astype(int)
        selected_values.append(oracle_value)
    full = float(np.mean(full_values)) if full_values else math.nan
    selected = float(np.mean(selected_values)) if selected_values else math.nan
    if native.get("status") == "PASS" and len(selected_values) != int(native["n_accepted_shifts"]):
        raise AssertionError("Selected oracle did not inherit native accepted offsets")
    retained_mean = float(np.mean(retained_fractions)) if retained_fractions else math.nan
    return (full, selected, retained_mean, dict(zip(PAIRS, pair_offset_counts.tolist())),
            dict(zip(PAIRS, original_counts.tolist())),
            dict(zip(PAIRS, original_high_counts.tolist())))


def patient_params(rng: np.random.Generator) -> dict[str, float]:
    return {
        "tumor_shift": float(rng.normal(0.0, 0.035)),
        "phase_i": float(rng.uniform(-math.pi, math.pi)),
        "phase_s": float(rng.uniform(-math.pi, math.pi)),
        "patient_i": float(rng.normal(0.0, 0.18)),
        "patient_s": float(rng.normal(0.0, 0.18)),
        "depth_re": float(rng.normal(0.0, 0.12)),
    }


def patient_mean(section_rows: list[dict], field: str) -> float:
    values = [float(row[field]) for row in section_rows if math.isfinite(float(row[field]))]
    return float(np.mean(values)) if values else math.nan


def cohort_mean(patient_rows: list[dict], field: str) -> tuple[float, int]:
    values = [float(row[field]) for row in patient_rows if math.isfinite(float(row[field]))]
    return (float(np.mean(values)), len(values)) if values else (math.nan, 0)


def run_replicate(geometry: str, detection: str, signal: str,
                  seed: int, n_patients: int = 6, verify_native: bool = False) -> dict:
    started = time.perf_counter()
    rng = np.random.default_rng(seed)
    all_sections: list[dict] = []
    patients: list[dict] = []
    for patient in range(n_patients):
        params = patient_params(rng)
        n_sections = 1 + int(rng.random() < 0.35)
        section_rows: list[dict] = []
        for section in range(n_sections):
            data, truth, q, qc = make_section(rng, geometry, detection, signal, params, section)
            native, shifts = fast_matched_effect(data)
            if verify_native:
                verify_native_equivalence(data, native, shifts)
            full, selected, retained_mean, pair_counts, original_counts, original_high = section_oracles(
                data, truth, q, native, shifts)
            row = {
                **qc, "patient_id": f"P{patient+1:02d}", "native_status": native["status"],
                "native_reason": native.get("reason", ""),
                "accepted_offsets": int(native.get("n_accepted_shifts", 0)),
                "native_effect_pp": (100.0 * float(native["pathology_matched_shift_effect_fraction"])
                                     if native["status"] == "PASS" else math.nan),
                "oracle_full_pp": 100.0 * full if math.isfinite(full) else math.nan,
                "oracle_selected_pp": 100.0 * selected if math.isfinite(selected) else math.nan,
                "retained_ss_low_fraction_accepted": retained_mean,
                "original_ss_low_edges": sum(original_counts.values()),
            }
            for pair in PAIRS:
                row[f"{pair}_qualified_offsets"] = pair_counts[pair]
                row[f"{pair}_original_ss_low_edges"] = original_counts[pair]
                row[f"{pair}_original_ss_low_is_high_edges"] = original_high[pair]
            section_rows.append(row)
            all_sections.append(row)
        patient_row = {
            "patient_id": f"P{patient+1:02d}", "n_sections": n_sections,
            "native_effect_pp": patient_mean(section_rows, "native_effect_pp"),
            "oracle_full_pp": patient_mean(section_rows, "oracle_full_pp"),
            "oracle_full_selected_sections_pp": patient_mean(
                [row for row in section_rows if row["native_status"] == "PASS"],
                "oracle_full_pp"),
            "oracle_selected_pp": patient_mean(section_rows, "oracle_selected_pp"),
        }
        for pair in PAIRS:
            counts = [int(row[f"{pair}_qualified_offsets"]) for row in section_rows]
            patient_row[f"{pair}_minimal"] = any(c >= 1 for c in counts)
            patient_row[f"{pair}_strict"] = any(c >= 24 for c in counts)
        patients.append(patient_row)
    h, n_h = cohort_mean(patients, "native_effect_pp")
    f, n_f = cohort_mean(patients, "oracle_full_pp")
    eligible_patients = [p for p in patients if math.isfinite(float(p["native_effect_pp"]))]
    f_eligible, _ = cohort_mean(eligible_patients, "oracle_full_pp")
    f_selected_sections, _ = cohort_mean(eligible_patients, "oracle_full_selected_sections_pp")
    q, n_q = cohort_mean(patients, "oracle_selected_pp")
    if n_h != n_q:
        raise AssertionError("H/Q patient availability mismatch")
    if n_h and all(math.isfinite(v) for v in (h, f, f_eligible, f_selected_sections, q)):
        parts = ((h - q) + (q - f_selected_sections)
                 + (f_selected_sections - f_eligible) + (f_eligible - f))
        if not math.isclose(h - f, parts, rel_tol=0.0, abs_tol=1e-10):
            raise AssertionError("U2 target decomposition identity failed")
    if n_h >= 2:
        values = np.array([p["native_effect_pp"] for p in patients
                           if math.isfinite(float(p["native_effect_pp"]))], float)
        bootstrap_rng = np.random.default_rng(seed + 500_000_000)
        bootstrap = bootstrap_rng.choice(values, size=(10_000, len(values)), replace=True).mean(axis=1)
        ci_low, ci_high = np.quantile(bootstrap, [0.025, 0.975]).tolist()
    else:
        ci_low = ci_high = math.nan
    result = {
        "status": "ESTIMABLE" if n_h else "NE_COHORT",
        "seed": seed, "geometry": geometry, "detection": detection, "signal": signal,
        "attempted_patients": n_patients, "attempted_sections": len(all_sections),
        "attempted_spots": sum(row["spots"] for row in all_sections),
        "passing_sections": sum(row["native_status"] == "PASS" for row in all_sections),
        "estimable_patients": n_h, "full_oracle_patients": n_f,
        "selected_oracle_patients": n_q,
        "H_pp": h, "F_pp": f, "F_eligible_patients_pp": f_eligible,
        "F_selected_sections_pp": f_selected_sections, "Q_pp": q,
        "bootstrap_low_pp": ci_low, "bootstrap_high_pp": ci_high,
        "bootstrap_available": n_h >= 2,
        "is_detection_mean": float(np.mean([row["is_detection"] for row in all_sections])),
        "ss_detection_mean": float(np.mean([row["ss_detection"] for row in all_sections])),
        "original_ss_low_edges": sum(row["original_ss_low_edges"] for row in all_sections),
        "accepted_offsets": sum(row["accepted_offsets"] for row in all_sections),
        "same_patient_both_minimal": sum(p["TT_minimal"] and p["StSt_minimal"] for p in patients),
        "same_patient_both_strict": sum(p["TT_strict"] and p["StSt_strict"] for p in patients),
        "runtime_seconds": time.perf_counter() - started,
        "sections": all_sections, "patients": patients,
    }
    for pair in PAIRS:
        result[f"{pair}_qualified_offsets"] = sum(
            row[f"{pair}_qualified_offsets"] for row in all_sections)
        result[f"{pair}_original_ss_low_edges"] = sum(
            row[f"{pair}_original_ss_low_edges"] for row in all_sections)
        result[f"{pair}_original_ss_low_is_high_edges"] = sum(
            row[f"{pair}_original_ss_low_is_high_edges"] for row in all_sections)
        result[f"{pair}_minimal_patients"] = sum(p[f"{pair}_minimal"] for p in patients)
        result[f"{pair}_strict_patients"] = sum(p[f"{pair}_strict"] for p in patients)
    return result


def scenarios() -> list[tuple[str, str, str]]:
    return [(g, d, s) for g in GEOMETRIES for d in DETECTIONS for s in SIGNALS]


def run_task(task: tuple) -> tuple[str, int, str, str]:
    (index, geometry, detection, signal, replicate_index, stage,
     n_patients, verify_native, output_dir) = task
    scenario_id = f"{geometry}_{detection}_{signal}"
    seed = SEED_BASE[stage] + index * 100_000 + replicate_index
    path = Path(output_dir) / f"{scenario_id}_r{replicate_index:05d}.json"
    if path.exists():
        recorded = json.loads(path.read_text(encoding="utf-8"))
        if recorded.get("seed") != seed or recorded.get("scenario_id") != scenario_id:
            raise RuntimeError(f"Existing replicate has wrong identity: {path}")
        return scenario_id, replicate_index, "SKIP", str(recorded.get("status", ""))
    try:
        record = run_replicate(geometry, detection, signal, seed, n_patients,
                               verify_native=verify_native)
        record["run_status"] = "PASS"
    except Exception as exc:
        record = {"run_status": "ERROR", "error_type": type(exc).__name__,
                  "error": str(exc), "seed": seed}
    record["scenario_id"] = scenario_id
    record["replicate_id"] = replicate_index
    temp = path.with_suffix(".json.tmp")
    temp.write_text(json.dumps(json_safe(record), indent=2, allow_nan=False)
                    + "\n", encoding="utf-8")
    os.replace(temp, path)
    return scenario_id, replicate_index, record["run_status"], str(record.get("status", ""))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stage", choices=tuple(SEED_BASE), default="pilot")
    parser.add_argument("--reps", type=int, default=1)
    parser.add_argument("--patients", type=int, default=6)
    parser.add_argument("--scenario", help="One ID such as G1_D1_S0; omit for all 18")
    parser.add_argument("--workers", type=int, default=1,
                        help="Independent process workers; does not alter seeds or results")
    parser.add_argument("--verify-native", action="store_true",
                        help="Check every synthetic section/offset against frozen E4; slower")
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    if args.reps < 1 or args.patients < 2 or args.workers < 1:
        raise ValueError("Positive replicates and at least two independent patients are required")
    args.out.mkdir(parents=True, exist_ok=True)
    config = {
        "schema": SCHEMA_VERSION, "stage": args.stage, "reps_per_cell": args.reps,
        "patients_per_replicate": args.patients, "code_sha256": sha256(Path(__file__)),
        "e4_sha256": sha256(E4_FILE), "panel_sha256": sha256(PANEL_FILE),
        "python": sys.version, "platform": platform.platform(),
        "numpy": np.__version__, "pandas": pd.__version__, "scipy": scipy.__version__,
        "seed_rule": f"{SEED_BASE[args.stage]} + scenario_index*100000 + replicate_index",
        "verify_native": bool(args.verify_native),
        "scenarios": ["_".join(row) for row in scenarios()],
    }
    manifest = args.out / "RUN_MANIFEST.json"
    if manifest.exists():
        saved = json.loads(manifest.read_text(encoding="utf-8"))
        if saved != config:
            raise RuntimeError("Output directory has a different run manifest; use a new directory")
    else:
        manifest.write_text(json.dumps(config, indent=2) + "\n", encoding="utf-8")
    tasks = []
    for index, (geometry, detection, signal) in enumerate(scenarios()):
        if args.scenario and f"{geometry}_{detection}_{signal}" != args.scenario:
            continue
        for replicate_index in range(args.reps):
            tasks.append((index, geometry, detection, signal, replicate_index,
                          args.stage, args.patients, args.verify_native, str(args.out)))
    completed = errors = 0
    if args.workers == 1:
        outputs = (run_task(task) for task in tasks)
        for scenario_id, replicate_index, status, result in outputs:
            completed += 1
            errors += status == "ERROR"
            if completed % 10 == 0 or errors or completed == len(tasks):
                print(f"progress {completed}/{len(tasks)} errors={errors} "
                      f"last={scenario_id}/r{replicate_index}:{status}/{result}", flush=True)
    else:
        with ProcessPoolExecutor(max_workers=args.workers) as pool:
            futures = [pool.submit(run_task, task) for task in tasks]
            for future in as_completed(futures):
                scenario_id, replicate_index, status, result = future.result()
                completed += 1
                errors += status == "ERROR"
                if completed % 10 == 0 or status == "ERROR" or completed == len(tasks):
                    print(f"progress {completed}/{len(tasks)} errors={errors} "
                          f"last={scenario_id}/r{replicate_index}:{status}/{result}", flush=True)
    if errors:
        raise RuntimeError(f"{errors} replicate(s) failed; inspect their immutable JSON rows")


if __name__ == "__main__":
    main()
