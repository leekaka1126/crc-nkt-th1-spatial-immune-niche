#!/usr/bin/env python
"""Read-only S20 ledger reconciliation; does not reconstruct raw spot graphs."""
from __future__ import annotations

import csv
import hashlib
import json
from collections import defaultdict
from pathlib import Path
from statistics import median


ROOT = Path(__file__).resolve().parents[1]
SUPPLEMENT = ROOT / "manuscript/CRC_NKT_v11_1/supplementary"
LOCK = ROOT / "analysis/posthoc_extension_20261015/S20_DATA_LOCK.json"
KEY = ("dataset", "sample", "patient_id", "shift_array_row", "shift_array_col",
       "hex_radius", "status", "pathology_pair", "IS_high_source")
COUNT_FIELDS = ("n_original_SS_low_edges", "n_compatible", "n_pair_retained")
SPOT_FIELDS = (
    ("n_original_unique_source_spots", "n_original_SS_low_edges"),
    ("n_original_unique_target_spots", "n_original_SS_low_edges"),
    ("n_compatible_unique_source_spots", "n_compatible"),
    ("n_compatible_unique_original_target_spots", "n_compatible"),
    ("n_compatible_unique_translated_target_spots", "n_compatible"),
    ("n_retained_unique_source_spots", "n_pair_retained"),
    ("n_retained_unique_original_target_spots", "n_pair_retained"),
    ("n_retained_unique_translated_target_spots", "n_pair_retained"),
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def check(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def row_key(row: dict[str, str]) -> tuple[str, ...]:
    return tuple(row[field] for field in KEY)


def main() -> None:
    lock = json.loads(LOCK.read_text(encoding="utf-8"))
    check(lock["schema_version"] == 1 and lock["seed"] is None, "S20 lock metadata")
    check(len(lock["files"]) == 4, "S20 lock must cover S14a, S14b, S20a and S20b")
    for relative, record in lock["files"].items():
        path = ROOT / relative
        check(path.is_file() and sha256(path) == record["sha256"], f"S20 lock drift: {relative}")

    source_manifest = json.loads((ROOT / "analysis/posthoc_extension_20261015/S20_SOURCE_PROVENANCE.json").read_text(encoding="utf-8"))
    a_path = SUPPLEMENT / "Table_S20a_unique_spot_support_by_offset_pair_group.csv"
    b_path = SUPPLEMENT / "Table_S20b_unique_spot_support_by_patient.csv"
    check(source_manifest["outputs_sha256"][a_path.name] == sha256(a_path), "S20a source hash")
    check(source_manifest["outputs_sha256"][b_path.name] == sha256(b_path), "S20b source hash")
    check(source_manifest["n_pair_group_rows"] == 15360, "S20 source manifest dimensions")

    shifts = read_csv(SUPPLEMENT / "Table_S14a_shift_edge_selection.csv")
    s14b = read_csv(SUPPLEMENT / "Table_S14b_pair_and_edge_hops.csv")
    s20a = read_csv(a_path)
    s20b = read_csv(b_path)
    check((len(shifts), len(s14b), len(s20a)) == (1920, 15360, 15360), "S14/S20 dimensions")
    shift_key = ("dataset", "sample", "patient_id", "shift_array_row", "shift_array_col", "hex_radius")
    shift_index = {tuple(row[k] for k in shift_key): row for row in shifts}
    b_index = {row_key(row): row for row in s14b}
    check(len(shift_index) == 1920 and len(b_index) == 15360, "Duplicate S14 keys")
    seen: set[tuple[str, ...]] = set()
    accepted: set[tuple[str, ...]] = set()
    qualified = []
    by_patient: dict[tuple[str, str, str, str], list[dict[str, str]]] = defaultdict(list)
    for row in s20a:
        k = row_key(row)
        check(k not in seen and k in b_index, f"S20 key mismatch: {k}")
        seen.add(k)
        reference = b_index[k]
        sk = tuple(row[field] for field in shift_key)
        check(sk in shift_index and row["status"] == shift_index[sk]["status"], f"S14a status mismatch: {sk}")
        for field in COUNT_FIELDS + ("pair_passed_minimum",):
            check(row[field] == reference[field], f"S14b field mismatch: {field}, {k}")
        original, compatible, retained = (int(row[field]) for field in COUNT_FIELDS)
        check(0 <= retained <= compatible <= original, f"Edge order mismatch: {k}")
        for spot_field, edge_field in SPOT_FIELDS:
            n_spots = int(row[spot_field])
            n_edges = int(row[edge_field])
            check(0 <= n_spots <= n_edges and (n_spots > 0) == (n_edges > 0),
                  f"Distinct-spot bound mismatch: {spot_field}, {k}")
        if row["accepted_in_passing_section"] == "True":
            check(row["section_status"] == "PASS" and row["status"] == "PASS",
                  f"Accepted flag mismatch: {k}")
            accepted.add(sk)
            if row["pair_passed_minimum"] == "True":
                check(retained >= 30, f"Qualified row has fewer than 30 edges: {k}")
                qualified.append(row)
                by_patient[(row["dataset"], row["patient_id"], row["pathology_pair"],
                            row["IS_high_source"])].append(row)
        else:
            check(row["status"] != "PASS" or row["section_status"] != "PASS",
                  f"Missing accepted flag: {k}")
    check(len(seen) == len(b_index), "S20 does not cover all S14b keys")
    check(len(accepted) == 1395, "Accepted offset count")
    check(len(qualified) == 6842, "Qualified technical row count")
    low_spot = [r for r in qualified if int(r["n_retained_unique_source_spots"]) < 30]
    check(len(low_spot) == 650, "Fewer-than-30-source count")
    check(min(int(r["n_retained_unique_source_spots"]) for r in qualified) == 9,
          "Minimum distinct-source count")
    check(len(by_patient) == len(s20b), "Patient summary key count")
    patient_seen = set()
    for row in s20b:
        pk = (row["dataset"], row["patient_id"], row["pathology_pair"], row["IS_high_source"])
        check(pk in by_patient and pk not in patient_seen, f"S20b patient key mismatch: {pk}")
        patient_seen.add(pk)
        items = by_patient[pk]
        check(int(row["qualified_section_n"]) == len({x["sample"] for x in items}), f"Section count: {pk}")
        check(int(row["qualified_section_offset_n"]) == len(items), f"Offset count: {pk}")
        fields = {
            "retained_edge_min": min(int(x["n_pair_retained"]) for x in items),
            "retained_edge_median": median(int(x["n_pair_retained"]) for x in items),
            "retained_unique_source_min": min(int(x["n_retained_unique_source_spots"]) for x in items),
            "retained_unique_source_median": median(int(x["n_retained_unique_source_spots"]) for x in items),
            "retained_unique_original_target_median": median(int(x["n_retained_unique_original_target_spots"]) for x in items),
            "retained_unique_translated_target_median": median(int(x["n_retained_unique_translated_target_spots"]) for x in items),
            "retained_edges_per_unique_source_median": median(
                int(x["n_pair_retained"]) / int(x["n_retained_unique_source_spots"]) for x in items),
            "offsets_with_fewer_than_30_unique_sources": sum(
                int(x["n_retained_unique_source_spots"]) < 30 for x in items),
        }
        for field, expected in fields.items():
            check(abs(float(row[field]) - expected) < 1e-8, f"Patient aggregate mismatch: {field}, {pk}")
    print("S20 PASS: 15,360 keys/counts match S14b; 1,920 offset statuses match S14a")
    print("S20 PASS: 1,395 accepted offsets; 6,842 qualified technical rows; 650 <30 distinct sources")
    print(f"S20 PASS: {len(s20b)} patient-pair-group summaries reaggregated; no effect recomputation")


if __name__ == "__main__":
    main()
