#!/usr/bin/env python
"""Independent U2 edge/oracle arithmetic on fixed quality-control seeds.

Only the frozen synthetic *generator* is imported to recover spot inputs and
latent parameters. Graphs, 96 translations, gates, q(s), H, Q and F are
reimplemented here. This is not independent data generation or third-party
replication. Seed selection is status-based (first eligible G2/G3 and first
two G3 failures), never effect-based.
"""
from __future__ import annotations

import argparse
import importlib.util
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
LEDGER = ROOT / "results/CRC_U2_summary_v1_2026-10-13"
OUT = ROOT / "reports/CRC_v11_12_2_atomic_oracle"
CASES = (("G2_D1_S2", 0), ("G3_D2_S0", 0),
         ("G3_D2_S0", 5), ("G3_D2_S0", 8))
TOL = 1e-10  # percentage points; tighter than saved CSV rounding


def generator():
    path = ROOT / "scripts/run_crc_U2_known_truth_simulation.py"
    spec = importlib.util.spec_from_file_location("frozen_u2_generator", path)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


def fixed_offsets():
    rng = np.random.default_rng(42)
    result = []
    for radius in range(5, 11):
        choices = []
        for dr in range(-radius, radius + 1):
            for dc in range(-2 * radius, 2 * radius + 1):
                if (dr + dc) % 2 == 0 and max(
                    abs(dr), abs((dc + dr) // 2), abs((dc - dr) // 2)
                ) == radius:
                    choices.append((dr, dc))
        result.extend(choices[int(i)] for i in rng.choice(len(choices), 16, replace=False))
    assert len(result) == len(set(result)) == 96
    return result


def q_surface(x, y, tumor, truth):
    """Direct transcription of the locked probability equation, not a call to U2."""
    t = np.asarray(tumor, bool)
    gi, gs = truth["phase_i"], truth["phase_s"]
    pi, ps = truth["patient_i"], truth["patient_s"]
    base = -1.28 + 0.62 * np.cos(2.4 * x + gs) * np.sin(2.8 * y - gs) + 0.52 * (~t) + ps
    immune = 0.58 * np.sin(2.7 * x + gi) * np.cos(2.4 * y - gi) + 0.40 * t + pi
    geometry = truth["geometry"]
    shift = truth["tumor_shift"]
    if geometry == "G1":
        distance = np.abs(np.sqrt((x / 1.0) ** 2 + (y / 0.86) ** 2) - (0.58 + shift))
    elif geometry == "G2":
        field = np.sin(9.0 * x + 0.4 * np.sin(3.0 * y)) * np.sin(9.0 * y)
        distance = np.abs(field - shift) / 3.0
    elif geometry == "G3":
        field = np.sin(4.7 * x) * np.cos(5.4 * y) + 0.45 * np.sin(3.0 * y)
        distance = np.abs(field - (0.22 + shift)) / 2.0
    else:
        raise ValueError(geometry)
    if truth["signal"] == "S1":
        base += 0.72 * immune * (distance >= 0.16)
    elif truth["signal"] == "S2":
        base += 0.85 * immune * (distance < 0.16)
    elif truth["signal"] != "S0":
        raise ValueError(truth["signal"])
    return 1.0 / (1.0 + np.exp(-np.clip(base, -30.0, 30.0)))


def graph(data):
    """Enumerate short directed lattice edges from an all-pairs distance matrix."""
    xy = data[["row", "col"]].to_numpy(float)
    delta = xy[:, None, :] - xy[None, :, :]
    distance = np.sqrt(np.sum(delta * delta, axis=2))
    np.fill_diagonal(distance, np.inf)
    pitch = float(np.median(distance.min(axis=1)))
    src, tgt = np.where(distance <= 1.6 * pitch + 1e-12)
    if len(src) == 0 or np.bincount(src, minlength=len(data)).max() > 6:
        raise AssertionError("All-pairs graph does not respect the six-neighbor lattice")
    return src, tgt


def pair_contrast(src, tgt, outcome_original, outcome_translated,
                  eligible, immune, layer, minimum):
    """Deliberately scalar four-pair/two-group aggregation for audit clarity."""
    values, weights, passing = [], [], [False] * 4
    for pair in range(4):
        p = (2 * layer[src] + layer[tgt]) == pair
        counts, changes = [], []
        for high in (False, True):
            subset = eligible & p & (immune[src] == high)
            counts.append(int(subset.sum()))
            changes.append(float(np.mean(outcome_original[subset] - outcome_translated[subset]))
                           if counts[-1] else math.nan)
        if min(counts) >= minimum:
            passing[pair] = True
            values.append(changes[1] - changes[0])
            weights.append(min(counts))
    return (float(np.average(values, weights=weights)) if values else math.nan,
            passing)


def check_section(data, truth, generated_q, offsets):
    ar = data.array_row.to_numpy(int)
    ac = data.array_col.to_numpy(int)
    tumor = data.compartment.eq("tumor").to_numpy(bool)
    layer = (~tumor).astype(int)
    immune = data.IS_high_q75.to_numpy(bool)
    ss = data.SS_high_q75.to_numpy(bool)
    src, tgt = graph(data)
    x = data.col.to_numpy(float) / 100.0
    y = data.row.to_numpy(float) / 100.0
    q = q_surface(x, y, tumor, truth)
    q_error = float(np.max(np.abs(q - generated_q)))
    if q_error > 1e-12:
        raise AssertionError(f"Original q surface mismatch: {q_error}")
    base = ~ss[src]
    is_high_edges = int(immune[src].sum())
    preflight = (len(src) >= 100 and is_high_edges >= 100 and
                 min(int((base & immune[src]).sum()),
                     int((base & ~immune[src]).sum())) >= 30)
    lookup = {(int(r), int(c)): i for i, (r, c) in enumerate(zip(ar, ac))}
    accepted_h, accepted_q, full_f, retained = [], [], [], []
    pair_counts = np.zeros(4, int)
    for dr, dc in offsets:
        # Full original-edge oracle keeps original target class and extends q
        # mathematically beyond the sampled tissue footprint.
        translated_x = (ac[tgt] + dc - 29.0) / 25.0
        translated_y = (ar[tgt] + dr - 12.5) * math.sqrt(3.0) / 25.0
        q_full = q_surface(translated_x, translated_y, tumor[tgt], truth)
        full, _ = pair_contrast(src, tgt, q[tgt], q_full, base, immune, layer, 1)
        if math.isfinite(full):
            full_f.append(full)
        if not preflight:
            continue
        mapped = np.array([lookup.get((int(r + dr), int(c + dc)), -1)
                           for r, c in zip(ar[tgt], ac[tgt])], dtype=int)
        compatible = mapped >= 0
        compatible[compatible] &= layer[mapped[compatible]] == layer[tgt[compatible]]
        matched_high = int((compatible & immune[src]).sum())
        if matched_high < 100 or matched_high / is_high_edges < 0.10:
            continue
        eligible = compatible & base
        h, passed = pair_contrast(src, tgt, ss[tgt].astype(float),
                                  ss[np.maximum(mapped, 0)].astype(float),
                                  eligible, immune, layer, 30)
        if not math.isfinite(h):
            continue
        q_value, q_passed = pair_contrast(src, tgt, q[tgt],
                                         q[np.maximum(mapped, 0)], eligible,
                                         immune, layer, 30)
        if passed != q_passed or not math.isfinite(q_value):
            raise AssertionError("Selected H/Q pair masks differ")
        accepted_h.append(h)
        accepted_q.append(q_value)
        retained.append(float(eligible.sum() / base.sum()))
        pair_counts += passed
    passed_section = preflight and len(accepted_h) >= 24
    return {
        "native_status": "PASS" if passed_section else "FAIL",
        "accepted_offsets": len(accepted_h),
        "native_effect_pp": 100.0 * float(np.mean(accepted_h)) if passed_section else math.nan,
        "oracle_selected_pp": 100.0 * float(np.mean(accepted_q)) if passed_section else math.nan,
        "oracle_full_pp": 100.0 * float(np.mean(full_f)) if full_f else math.nan,
        "original_ss_low_edges": int(base.sum()),
        "retained_ss_low_fraction_accepted": float(np.mean(retained)) if passed_section else math.nan,
        "q_surface_max_abs_error": q_error,
        **{f"{pair}_qualified_offsets": int(pair_counts[i]) if passed_section else 0
           for i, pair in enumerate(("TT", "TSt", "StT", "StSt"))},
    }


def close(a, b):
    if pd.isna(a) and pd.isna(b):
        return True
    if pd.isna(a) or pd.isna(b):
        return False
    return abs(float(a) - float(b)) <= TOL


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--outdir", type=Path, default=OUT,
                        help="Output directory; use a new path for a read-only archive check")
    args = parser.parse_args()
    out = args.outdir.resolve()
    gen = generator()
    attempts = pd.read_csv(LEDGER / "U2_formal_all_attempts.csv")
    sections = pd.read_csv(LEDGER / "U2_formal_all_sections.csv")
    offsets = fixed_offsets()
    assert offsets == [(a, b) for a, b, _ in gen.OFFSETS]
    # Freeze selection rule independently of effect size and assert it agrees
    # with the documented first-by-replicate-ID cases.
    g2 = attempts[attempts.scenario_id.eq("G2_D1_S2")]
    g3 = attempts[attempts.scenario_id.eq("G3_D2_S0")]
    assert int(g2[g2.status.eq("ESTIMABLE")].replicate_id.min()) == 0
    assert int(g3[g3.status.eq("ESTIMABLE")].replicate_id.min()) == 0
    assert g3[g3.status.eq("NE_COHORT")].replicate_id.nsmallest(2).tolist() == [5, 8]
    out.mkdir(parents=True, exist_ok=True)
    details, cohort_checks = [], []
    for scenario, rep in CASES:
        record = attempts[(attempts.scenario_id == scenario) & (attempts.replicate_id == rep)].iloc[0]
        geometry, detection, signal = scenario.split("_")
        rng = np.random.default_rng(int(record.seed))
        patient_rows = []
        for patient in range(6):
            params = gen.patient_params(rng)
            n_sections = 1 + int(rng.random() < 0.35)
            patient_sections = []
            for section in range(n_sections):
                data, truth, q, _ = gen.make_section(rng, geometry, detection,
                                                     signal, params, section)
                observed = check_section(data, truth, q, offsets)
                saved = sections[(sections.scenario_id == scenario) &
                                 (sections.replicate_id == rep) &
                                 (sections.patient_id == f"P{patient+1:02d}") &
                                 (sections.section_id == section)].iloc[0]
                fields = ("native_status", "accepted_offsets", "native_effect_pp",
                          "oracle_selected_pp", "oracle_full_pp", "original_ss_low_edges",
                          "retained_ss_low_fraction_accepted", "TT_qualified_offsets",
                          "TSt_qualified_offsets", "StT_qualified_offsets",
                          "StSt_qualified_offsets")
                mismatches = [field for field in fields if
                              (observed[field] != saved[field] if field == "native_status"
                               else not close(observed[field], saved[field]))]
                details.append({"scenario_id": scenario, "replicate_id": rep,
                                "patient_id": f"P{patient+1:02d}", "section_id": section,
                                "saved_status": saved.native_status,
                                "independent_status": observed["native_status"],
                                "saved_H_pp": saved.native_effect_pp,
                                "independent_H_pp": observed["native_effect_pp"],
                                "saved_Q_pp": saved.oracle_selected_pp,
                                "independent_Q_pp": observed["oracle_selected_pp"],
                                "saved_F_pp": saved.oracle_full_pp,
                                "independent_F_pp": observed["oracle_full_pp"],
                                "q_surface_max_abs_error": observed["q_surface_max_abs_error"],
                                "mismatched_fields": ";".join(mismatches)})
                patient_sections.append(observed)
            patient_rows.append(patient_sections)
        # Aggregate each target at the same patient and section levels as the
        # frozen rule. A failed section still contributes to full-edge F.
        h_patient, q_patient, f_patient, fs_patient = [], [], [], []
        for group in patient_rows:
            def mean(field, selected_only=False):
                values = [r[field] for r in group if
                          (not selected_only or r["native_status"] == "PASS") and
                          math.isfinite(r[field])]
                return float(np.mean(values)) if values else math.nan
            h_patient.append(mean("native_effect_pp"))
            q_patient.append(mean("oracle_selected_pp"))
            f_patient.append(mean("oracle_full_pp"))
            fs_patient.append(mean("oracle_full_pp", True))
        contributors = [i for i, v in enumerate(h_patient) if math.isfinite(v)]
        values = {
            "H_pp": float(np.mean([h_patient[i] for i in contributors])) if contributors else math.nan,
            "Q_pp": float(np.mean([q_patient[i] for i in contributors])) if contributors else math.nan,
            "F_pp": float(np.mean(f_patient)),
            "F_eligible_patients_pp": float(np.mean([f_patient[i] for i in contributors])) if contributors else math.nan,
            "F_selected_sections_pp": float(np.mean([fs_patient[i] for i in contributors])) if contributors else math.nan,
            "estimable_patients": len(contributors),
            "passing_sections": sum(r["native_status"] == "PASS" for group in patient_rows for r in group),
        }
        mismatches = [field for field in values if not close(values[field], record[field])]
        cohort_checks.append({"scenario_id": scenario, "replicate_id": rep,
                              "seed": int(record.seed), "archived_status": record.status,
                              "independent_status": "ESTIMABLE" if contributors else "NE_COHORT",
                              "estimable_patients": len(contributors),
                              "Q_minus_Fselected_pp":
                                  values["Q_pp"] - values["F_selected_sections_pp"]
                                  if contributors else math.nan,
                              "mismatched_fields": ";".join(mismatches)})
    detail_path = out / "atomic_edge_section_comparison.csv"
    cohort_path = out / "atomic_edge_cohort_comparison.csv"
    pd.DataFrame(details).to_csv(detail_path, index=False)
    pd.DataFrame(cohort_checks).to_csv(cohort_path, index=False)
    failures = sum(bool(row["mismatched_fields"]) for row in details + cohort_checks)
    report = {"status": "PASS" if failures == 0 else "FAIL",
              "scope": "Independent oracle arithmetic on fixed regenerated synthetic inputs; not independent generation or third-party replication",
              "case_selection": "first estimable G2_D1_S2 and G3_D2_S0; first two NE G3_D2_S0, ascending replicate ID",
              "cases": cohort_checks, "sections_checked": len(details),
              "mismatched_rows": failures, "tolerance_pp": TOL,
              "source_ledger": str(LEDGER), "detail_csv": str(detail_path)}
    (out / "atomic_edge_audit_report.json").write_text(
        json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps({"status": report["status"], "cases": len(cohort_checks),
                      "sections": len(details), "mismatched_rows": failures}))
    if failures:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
