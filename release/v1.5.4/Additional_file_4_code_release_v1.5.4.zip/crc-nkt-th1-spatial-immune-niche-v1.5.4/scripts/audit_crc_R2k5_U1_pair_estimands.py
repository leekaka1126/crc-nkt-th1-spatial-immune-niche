#!/usr/bin/env python
"""Post hoc TT/SS patient-level estimability audit from the locked E4 edge ledger.

Analysis: Pair-specific and same-patient equal-pair descriptive contrasts.
Date: 2026-10-12
Random seed: 42 (PCG64 patient bootstrap, 10,000 draws)
Python: 3.14; key package: numpy (version recorded at runtime)

The frozen E4 effect is reconstructed as a guard but never overwritten. This
script reads saved pair/group counts, not raw expression or edge coordinates.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import platform
from collections import defaultdict
from pathlib import Path

import numpy as np


ALL_PAIRS = ("tumor->tumor", "tumor->stroma", "stroma->tumor", "stroma->stroma")
PAIRS = ("tumor->tumor", "stroma->stroma")
TIERS = ("at_least_one", "at_least_24_per_section")
BOOTSTRAP_DRAWS = 10_000
SEED = 42
TOL = 1e-12


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_csv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def cell_effect(groups: dict[bool, dict[str, str]], label: str) -> tuple[float, int] | None:
    if set(groups) != {False, True}:
        raise ValueError(f"{label}: missing or duplicate IS group")
    low, high = groups[False], groups[True]
    gates = {low["pair_passed_minimum"], high["pair_passed_minimum"]}
    if len(gates) != 1 or not gates <= {"True", "False"}:
        raise ValueError(f"{label}: inconsistent pair gate")
    if gates == {"False"}:
        if int(low["n_pair_retained"]) or int(high["n_pair_retained"]):
            raise ValueError(f"{label}: failed pair has retained edges")
        return None
    low_n, high_n = int(low["n_pair_retained"]), int(high["n_pair_retained"])
    if min(low_n, high_n) < 30:
        raise ValueError(f"{label}: passing pair violates original 30/30 gate")
    rates: dict[str, tuple[float, float]] = {}
    for status in ("observed", "shifted"):
        field = f"n_{status}_SS_high_on_retained"
        low_y, high_y = int(low[field]), int(high[field])
        if not (0 <= low_y <= low_n and 0 <= high_y <= high_n):
            raise ValueError(f"{label}: numerator outside retained denominator")
        rates[status] = (low_y / low_n, high_y / high_n)
    low_observed, high_observed = rates["observed"]
    low_shifted, high_shifted = rates["shifted"]
    delta = (high_observed - low_observed) - (high_shifted - low_shifted)
    return delta, min(low_n, high_n)


def patient_interval(values: list[float]) -> tuple[float | None, float | None]:
    if len(values) < 2:
        return None, None
    rng = np.random.default_rng(SEED)
    array = np.asarray(values, dtype=float)
    draws = rng.choice(array, size=(BOOTSTRAP_DRAWS, len(array)), replace=True).mean(axis=1)
    low, high = np.quantile(draws, [0.025, 0.975])
    return float(low), float(high)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair-ledger", type=Path, required=True)
    parser.add_argument("--shift-ledger", type=Path, required=True)
    parser.add_argument("--external-sections", type=Path, required=True)
    parser.add_argument("--source-sections", type=Path, required=True)
    parser.add_argument("--s14i", type=Path, required=True)
    parser.add_argument("--archived-summary", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    if args.out.exists():
        raise FileExistsError(f"Output directory already exists: {args.out}")

    inputs = {
        "pair_ledger": args.pair_ledger,
        "shift_ledger": args.shift_ledger,
        "external_sections": args.external_sections,
        "source_sections": args.source_sections,
        "s14i": args.s14i,
        "archived_summary": args.archived_summary,
    }
    pair_ledger = read_csv(args.pair_ledger)
    shifts = read_csv(args.shift_ledger)
    sections = read_csv(args.external_sections) + [
        row for row in read_csv(args.source_sections) if row["tissue_context"] == "Primary_CRC"
    ]
    s14i = read_csv(args.s14i)
    archived = read_csv(args.archived_summary)
    if len(pair_ledger) != 15_360 or len(shifts) != 1_920 or len(sections) != 20:
        raise ValueError("Locked input dimensions do not match 15,360 / 1,920 / 20")

    section_lookup: dict[tuple[str, str], dict[str, str]] = {}
    for section in sections:
        key = (section["dataset"], section["sample"])
        if key in section_lookup:
            raise ValueError(f"Duplicate section: {key}")
        section_lookup[key] = section
    candidate_patients = sorted({(row["dataset"], row["patient_id"]) for row in sections})
    if len(candidate_patients) != 11:
        raise ValueError("Expected 11 dataset-local candidate patients")

    shift_lookup: dict[tuple[str, str, str, str], dict[str, str]] = {}
    accepted: set[tuple[str, str, str, str]] = set()
    for row in shifts:
        key = (row["dataset"], row["sample"], row["shift_array_row"], row["shift_array_col"])
        if key in shift_lookup or key[:2] not in section_lookup:
            raise ValueError(f"Duplicate or unexpected shift: {key}")
        shift_lookup[key] = row
        if row["status"] == "PASS" and section_lookup[key[:2]]["status"] == "PASS":
            accepted.add(key)
    if len(accepted) != 1_395:
        raise ValueError(f"Expected 1,395 analysis offsets, found {len(accepted)}")

    cells: dict[tuple[str, str, str, str], dict[str, dict[bool, dict[str, str]]]] = defaultdict(
        lambda: defaultdict(dict)
    )
    for row in pair_ledger:
        key = (row["dataset"], row["sample"], row["shift_array_row"], row["shift_array_col"])
        pair, group = row["pathology_pair"], row["IS_high_source"]
        if key not in shift_lookup or pair not in ALL_PAIRS or group not in ("True", "False"):
            raise ValueError(f"Unexpected pair/group row: {key}/{pair}/{group}")
        bool_group = group == "True"
        if bool_group in cells[key][pair] or row["status"] != shift_lookup[key]["status"]:
            raise ValueError(f"Duplicate pair/group or shift-status mismatch: {key}/{pair}/{group}")
        cells[key][pair][bool_group] = row
    if set(cells) != set(shift_lookup):
        raise ValueError("Pair and shift ledgers have different offset keys")

    pair_values: dict[tuple[str, str, str, str, str], tuple[float, int]] = {}
    broad_effects: dict[tuple[str, str], list[float]] = defaultdict(list)
    for key in sorted(cells):
        if set(cells[key]) != set(ALL_PAIRS):
            raise ValueError(f"{key}: missing directed pair")
        findings: list[tuple[float, int]] = []
        for pair in ALL_PAIRS:
            found = cell_effect(cells[key][pair], f"{key}/{pair}")
            if found is not None:
                if shift_lookup[key]["status"] != "PASS":
                    raise ValueError(f"{key}/{pair}: pair qualified in a failed offset")
                # A few offset-level PASS rows belong to sections that failed
                # the original >=24 accepted-offset section gate. Preserve
                # their diagnostic status but do not enter either estimand.
                if key in accepted:
                    pair_values[(*key, pair)] = found
                    findings.append(found)
        if key in accepted:
            weight = sum(w for _, w in findings)
            if weight <= 0:
                raise ValueError(f"{key}: accepted offset lacks qualifying pair")
            broad = sum(effect * w for effect, w in findings) / weight
            expected = float(shift_lookup[key]["observed_minus_shifted_IS_contrast"])
            if abs(broad - expected) > TOL:
                raise ValueError(f"{key}: frozen broad effect failed arithmetic guard")
            broad_effects[key[:2]].append(broad)

    accepted_by_section: dict[tuple[str, str], int] = defaultdict(int)
    for key in accepted:
        accepted_by_section[key[:2]] += 1
    for key, section in section_lookup.items():
        if section["status"] == "PASS":
            if accepted_by_section[key] < 24 or accepted_by_section[key] != int(float(section["n_accepted_shifts"])):
                raise ValueError(f"{key}: frozen section gate mismatch")
            broad = float(np.mean(broad_effects[key]))
            if abs(broad - float(section["pathology_matched_shift_effect_fraction"])) > TOL:
                raise ValueError(f"{key}: frozen section effect mismatch")
        elif accepted_by_section[key]:
            raise ValueError(f"{key}: failed section entered analysis")

    original_patients: dict[tuple[str, str], list[float]] = defaultdict(list)
    for section in sections:
        key = (section["dataset"], section["sample"])
        if section["status"] == "PASS":
            original_patients[(section["dataset"], section["patient_id"])].append(float(np.mean(broad_effects[key])))
    summary_lookup = {(row["dataset"], row["context"]): row for row in archived}
    for dataset, context in (("Valdeolivas_2024", "all"), ("GSE294385", "Primary_CRC")):
        patient_values = [float(np.mean(values)) for (ds, _), values in original_patients.items() if ds == dataset]
        expected = float(summary_lookup[(dataset, context)]["estimate_fraction"])
        if len(patient_values) != (6 if dataset == "Valdeolivas_2024" else 5) or abs(float(np.mean(patient_values)) - expected) > TOL:
            raise ValueError(f"{dataset}: original E4 patient-equal mean changed")

    section_rows: list[dict[str, object]] = []
    section_effects: dict[tuple[str, str, str], list[float]] = defaultdict(list)
    joint_rows: list[dict[str, object]] = []
    for section in sorted(sections, key=lambda row: (row["dataset"], row["sample"])):
        dataset, sample, patient = section["dataset"], section["sample"], section["patient_id"]
        accepted_keys = sorted(key for key in accepted if key[:2] == (dataset, sample))
        joint_count = sum(all((*key, pair) in pair_values for pair in PAIRS) for key in accepted_keys)
        joint_rows.append({
            "dataset": dataset, "patient_id": patient, "sample": sample,
            "section_status": section["status"], "accepted_original_offset_n": len(accepted_keys),
            "joint_TT_SS_qualified_offset_n": joint_count,
            "joint_support_status": "AVAILABLE" if joint_count else "NE",
        })
        for pair in PAIRS:
            values = [pair_values[(*key, pair)][0] for key in accepted_keys if (*key, pair) in pair_values]
            n_qualified = len(values)
            if n_qualified:
                section_effects[(dataset, sample, pair)] = values
            section_rows.append({
                "dataset": dataset, "patient_id": patient, "sample": sample,
                "pair": pair, "section_status": section["status"],
                "accepted_original_offset_n": len(accepted_keys),
                "pair_qualified_offset_n": n_qualified,
                "at_least_one_available": bool(n_qualified),
                "at_least_24_available": n_qualified >= 24,
                "pair_section_effect_pp_given_qualified": float(np.mean(values) * 100) if values else "",
                "NA_reason": "" if values else ("SECTION_FAILED" if section["status"] != "PASS" else "PAIR_GATE_FAILED"),
            })

    patient_rows: list[dict[str, object]] = []
    patient_values: dict[tuple[str, str, str, str], float] = {}
    for dataset, patient in candidate_patients:
        for tier in TIERS:
            min_n = 1 if tier == "at_least_one" else 24
            for pair in PAIRS:
                eligible_sections = [row for row in section_rows if row["dataset"] == dataset
                                     and row["patient_id"] == patient and row["pair"] == pair
                                     and int(row["pair_qualified_offset_n"]) >= min_n]
                values = [float(row["pair_section_effect_pp_given_qualified"]) for row in eligible_sections]
                effect = float(np.mean(values)) if values else None
                if effect is not None:
                    patient_values[(dataset, patient, tier, pair)] = effect
                patient_rows.append({
                    "dataset": dataset, "patient_id": patient, "support_tier": tier,
                    "pair": pair, "candidate_section_n": sum(row["dataset"] == dataset and row["patient_id"] == patient for row in sections),
                    "pair_available_section_n": len(eligible_sections),
                    "pair_qualified_offset_n_in_available_sections": sum(int(row["pair_qualified_offset_n"]) for row in eligible_sections),
                    "pair_effect_pp": effect if effect is not None else "",
                    "effect_status": "ESTIMABLE" if effect is not None else "NE",
                    "NA_reason": "" if effect is not None else "NO_SECTION_WITH_REQUIRED_PAIR_SUPPORT",
                })

    # Reconcile the minimal-support pair estimates to the existing S14i
    # diagnostics. S14i was not used to calculate the new patient mixtures.
    s14i_patients = {(row["dataset"], row["patient_id"], row["pathology_pair"]): row
                     for row in s14i if row["scope"] == "patient" and row["pathology_pair"] in PAIRS}
    if len(s14i_patients) != 22:
        raise ValueError("S14i patient-pair lookup must contain 22 rows")
    for row in patient_rows:
        if row["support_tier"] != "at_least_one":
            continue
        key = (row["dataset"], row["patient_id"], row["pair"])
        old = s14i_patients[key]
        old_effect = old["pair_specific_effect_pp_given_qualified"]
        if row["effect_status"] == "NE":
            if old_effect:
                raise ValueError(f"{key}: newly missing effect differs from S14i")
        elif not old_effect or abs(float(row["pair_effect_pp"]) - float(old_effect)) > 1e-9:
            raise ValueError(f"{key}: pair effect differs from S14i")

    mixture_rows: list[dict[str, object]] = []
    for dataset, patient in candidate_patients:
        joint = sum(int(row["joint_TT_SS_qualified_offset_n"]) for row in joint_rows
                    if row["dataset"] == dataset and row["patient_id"] == patient)
        for tier in TIERS:
            tt = patient_values.get((dataset, patient, tier, PAIRS[0]))
            ss = patient_values.get((dataset, patient, tier, PAIRS[1]))
            mixture_rows.append({
                "dataset": dataset, "patient_id": patient, "support_tier": tier,
                "theta_TT_pp": tt if tt is not None else "",
                "theta_SS_pp": ss if ss is not None else "",
                "both_pairs_available": tt is not None and ss is not None,
                "same_patient_equal_pair_mix_pp": (tt + ss) / 2 if tt is not None and ss is not None else "",
                "joint_same_section_offset_n_support_only": joint,
                "joint_offset_status": "AVAILABLE" if joint else "NE",
                "NA_reason": "" if tt is not None and ss is not None else "ONE_OR_BOTH_PAIR_EFFECTS_NE",
            })

    cohort_rows: list[dict[str, object]] = []
    for dataset in ("GSE294385", "Valdeolivas_2024"):
        n_candidates = sum(ds == dataset for ds, _ in candidate_patients)
        for tier in TIERS:
            for estimand, pair in (("TT", PAIRS[0]), ("SS", PAIRS[1]), ("SAME_PATIENT_EQUAL_TT_SS", None)):
                if pair is not None:
                    selected = [row for row in patient_rows if row["dataset"] == dataset and row["support_tier"] == tier
                                and row["pair"] == pair and row["effect_status"] == "ESTIMABLE"]
                    values = [float(row["pair_effect_pp"]) for row in selected]
                    patient_ids = [str(row["patient_id"]) for row in selected]
                    n_sections = sum(int(row["pair_available_section_n"]) for row in selected)
                    n_offsets = sum(int(row["pair_qualified_offset_n_in_available_sections"]) for row in selected)
                else:
                    selected = [row for row in mixture_rows if row["dataset"] == dataset and row["support_tier"] == tier
                                and row["both_pairs_available"]]
                    values = [float(row["same_patient_equal_pair_mix_pp"]) for row in selected]
                    patient_ids = [str(row["patient_id"]) for row in selected]
                    n_sections, n_offsets = "SEE_COMPONENT_TABLE", "SEE_COMPONENT_TABLE"
                ci_low, ci_high = patient_interval(values)
                loo = [float(np.mean(values[:i] + values[i + 1:])) for i in range(len(values))] if len(values) > 1 else []
                cohort_rows.append({
                    "dataset": dataset, "support_tier": tier, "estimand": estimand,
                    "candidate_patient_n": n_candidates, "estimable_patient_n": len(values),
                    "estimable_patient_ids": "|".join(sorted(patient_ids)),
                    "estimable_section_n": n_sections, "qualified_offset_n_technical": n_offsets,
                    "mean_pp": float(np.mean(values)) if values else "",
                    "nominal_bootstrap_95_lo_pp": ci_low if ci_low is not None else "",
                    "nominal_bootstrap_95_hi_pp": ci_high if ci_high is not None else "",
                    "positive_patient_n": sum(value > 0 for value in values),
                    "LOO_min_pp": min(loo) if loo else "", "LOO_max_pp": max(loo) if loo else "",
                    "status": "ESTIMABLE_DESCRIPTIVE" if len(values) >= 2 else ("POINT_ONLY_N_LT_2" if values else "NE"),
                    "interpretation": "post_hoc; not common edges, biological equivalence, or validation",
                })

    args.out.mkdir(parents=True)
    outputs = {
        "U1_section_pair_support.csv": section_rows,
        "U1_patient_pair_effects.csv": patient_rows,
        "U1_same_patient_equal_pair_mix.csv": mixture_rows,
        "U1_joint_offset_support_only.csv": joint_rows,
        "U1_cohort_estimands.csv": cohort_rows,
    }
    for filename, rows in outputs.items():
        write_csv(args.out / filename, rows, list(rows[0]))
    report = {
        "status": "PASS",
        "analysis_status": "post_hoc_exploratory",
        "input_sha256": {name: sha256(path) for name, path in inputs.items()},
        "output_sha256": {name: sha256(args.out / name) for name in outputs},
        "software": {"python": platform.python_version(), "numpy": np.__version__},
        "n_pair_group_rows": len(pair_ledger),
        "n_attempted_offsets": len(shifts),
        "n_original_accepted_offsets": len(accepted),
        "n_candidate_sections": len(sections),
        "n_candidate_patients": len(candidate_patients),
        "frozen_E4_guard": "PASS: original offset, section and cohort effects unchanged",
        "S14i_pair_effect_guard": "PASS: all 22 patient-pair effect/NA statuses reconciled",
        "cohort_estimands": cohort_rows,
        "limitations": [
            "Same-patient TT and SS effects can use different sections, offsets and original edges.",
            "Intervals are uncalibrated descriptive patient-bootstrap percentiles at very small n.",
            "S14b is a saved edge-count ledger, not an independent raw-expression/graph reconstruction.",
        ],
    }
    (args.out / "U1_run_report.json").write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    manifest = [
        "# R2k5 U1 analysis outputs", "", "Generated: 2026-10-12",
        "Study type: post hoc patient-level descriptive pathology-pair estimability audit", "",
        "Input: fixed S14b/S14a count and shift ledgers; S11 section status; S14i/S11d cross-checks.", "",
        "## Tables", "",
    ]
    manifest.extend(f"- `{name}`" for name in outputs)
    manifest.extend(["", "## Provenance", "", "- `U1_run_report.json` contains input/output SHA-256 and reconciliation status.",
                     "- Original E4 tables were not overwritten; no P value or clinical prediction analysis was performed.", ""])
    (args.out / "_analysis_outputs.md").write_text("\n".join(manifest), encoding="utf-8")
    for row in cohort_rows:
        print(f"{row['dataset']} | {row['support_tier']} | {row['estimand']} | "
              f"n={row['estimable_patient_n']}/{row['candidate_patient_n']} | "
              f"mean={row['mean_pp']} pp | nominal 95% interval="
              f"{row['nominal_bootstrap_95_lo_pp']} to {row['nominal_bootstrap_95_hi_pp']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
