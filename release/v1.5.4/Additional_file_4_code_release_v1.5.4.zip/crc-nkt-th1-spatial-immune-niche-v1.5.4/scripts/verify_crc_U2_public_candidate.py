#!/usr/bin/env python
"""Read-only checksum and key-denominator verification for the U2 bundle."""
from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
RESULT = ROOT / "results/CRC_U2_summary_v1_2026-10-13"
SUPPLEMENT = ROOT / "manuscript/CRC_NKT_v11_1/supplementary"


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def count_rows(path: Path) -> int:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return sum(1 for _ in csv.DictReader(handle))


def main() -> None:
    manifest = json.loads((ROOT / "SHA256_MANIFEST.json").read_text(encoding="utf-8"))
    assert manifest["status"] == "release_artifact_external_deposit_unverified"
    files = manifest["files"]
    actual = {p.relative_to(ROOT).as_posix() for p in ROOT.rglob("*") if p.is_file()}
    expected = {row["path"] for row in files} | {"SHA256_MANIFEST.json"}
    if expected - actual:
        raise AssertionError(f"Required files missing: {sorted(expected-actual)}")
    for row in files:
        path = ROOT / row["path"]
        if path.stat().st_size != row["bytes"] or sha256(path) != row["sha256"]:
            raise AssertionError(f"Checksum mismatch: {row['path']}")
    if sha256(ROOT / "scripts/run_crc_U2_known_truth_simulation.py") != manifest["frozen_u2_script_sha256"]:
        raise AssertionError("Frozen U2 script mismatch")
    expected_rows = {
        RESULT / "U2_formal_all_attempts.csv": 9000,
        RESULT / "U2_independent_calibration_all_attempts.csv": 3600,
        RESULT / "U2_formal_all_sections.csv": 72861,
        RESULT / "U2_formal_all_patients.csv": 54000,
        RESULT / "U2_scenario_summary.csv": 18,
        RESULT / "U2_sample_size_all_attempts.csv": 1200,
        SUPPLEMENT / "Table_S17a_U2_scenario_summary.csv": 18,
        SUPPLEMENT / "Table_S17d_U2_contributing_patients.csv": 18,
        SUPPLEMENT / "Table_S16a_U1_section_pair_support.csv": 40,
        SUPPLEMENT / "Table_S16b_U1_patient_pair_effects.csv": 44,
        SUPPLEMENT / "Table_S16c_U1_same_patient_equal_pair_mix.csv": 22,
        SUPPLEMENT / "Table_S16d_U1_joint_offset_support_only.csv": 20,
        SUPPLEMENT / "Table_S16e_U1_cohort_estimands.csv": 12,
    }
    for path, expected_count in expected_rows.items():
        found = count_rows(path)
        if found != expected_count:
            raise AssertionError(f"Row-count mismatch for {path.name}: {found} != {expected_count}")
    print(f"Verified {len(files)} file hashes and {len(expected_rows)} table denominators; check external release and DOI separately")


if __name__ == "__main__":
    main()
