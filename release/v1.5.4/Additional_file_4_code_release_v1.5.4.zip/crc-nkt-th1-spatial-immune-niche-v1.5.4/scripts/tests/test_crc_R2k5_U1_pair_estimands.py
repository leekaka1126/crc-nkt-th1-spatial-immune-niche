"""Small arithmetic contracts for the post hoc R2k5 U1 pair audit."""
from __future__ import annotations

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from audit_crc_R2k5_U1_pair_estimands import cell_effect, patient_interval


def group(is_high: bool, observed: int, shifted: int, n: int, passed: bool = True) -> dict[str, str]:
    return {
        "IS_high_source": str(is_high),
        "pair_passed_minimum": str(passed),
        "n_pair_retained": str(n),
        "n_observed_SS_high_on_retained": str(observed),
        "n_shifted_SS_high_on_retained": str(shifted),
    }


class PairAuditTests(unittest.TestCase):
    def test_same_edges_observed_minus_shifted(self) -> None:
        rows = {
            False: group(False, 10, 7, 40),
            True: group(True, 20, 14, 40),
        }
        finding = cell_effect(rows, "synthetic")
        self.assertIsNotNone(finding)
        assert finding is not None
        effect, weight = finding
        self.assertAlmostEqual(effect, (20 / 40 - 10 / 40) - (14 / 40 - 7 / 40))
        self.assertEqual(weight, 40)

    def test_failed_pair_is_missing_not_zero(self) -> None:
        rows = {
            False: group(False, 0, 0, 0, False),
            True: group(True, 0, 0, 0, False),
        }
        self.assertIsNone(cell_effect(rows, "synthetic"))

    def test_passing_pair_must_meet_original_gate(self) -> None:
        rows = {
            False: group(False, 4, 3, 29),
            True: group(True, 10, 8, 40),
        }
        with self.assertRaisesRegex(ValueError, "30/30"):
            cell_effect(rows, "synthetic")

    def test_one_patient_interval_is_not_reported(self) -> None:
        self.assertEqual(patient_interval([2.0]), (None, None))

    def test_bootstrap_reproducible(self) -> None:
        self.assertEqual(patient_interval([0.0, 1.0, 2.0]), patient_interval([0.0, 1.0, 2.0]))


if __name__ == "__main__":
    unittest.main()
