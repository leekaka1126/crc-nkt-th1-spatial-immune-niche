"""Focused identities for the U2 synthetic simulation; no real patient data."""
from __future__ import annotations

import importlib.util
import math
from pathlib import Path

import numpy as np


SCRIPT = Path(__file__).resolve().parents[1] / "run_crc_U2_known_truth_simulation.py"
spec = importlib.util.spec_from_file_location("crc_u2_sim", SCRIPT)
assert spec is not None and spec.loader is not None
u2 = importlib.util.module_from_spec(spec)
spec.loader.exec_module(u2)


def test_pair_arithmetic_hand_calculation_and_ne() -> None:
    source = np.arange(4)
    target = np.arange(4, 8)
    mapped = np.arange(8, 12)
    immune = np.zeros(12, bool)
    immune[2:4] = True
    layer = np.zeros(12, np.int8)
    observed = np.zeros(12, float)
    shifted = np.zeros(12, float)
    observed[4:8] = [0, 1, 1, 1]
    shifted[8:12] = [0, 0, 0, 1]
    value, passed, weights = u2.pair_arithmetic(
        source, target, mapped, np.ones(4, bool), immune, layer,
        observed, shifted, minimum=2)
    assert value == 0.0
    assert passed.tolist() == [True, False, False, False]
    assert weights[0] == 2
    missing, missing_pass, _ = u2.pair_arithmetic(
        source, target, mapped, np.ones(4, bool), immune, layer,
        observed, shifted, minimum=3)
    assert math.isnan(missing) and not missing_pass.any()


def test_seed_and_decomposition_identity() -> None:
    first = u2.run_replicate("G1", "D1", "S0", seed=9_143_111, n_patients=3)
    second = u2.run_replicate("G1", "D1", "S0", seed=9_143_111, n_patients=3)
    first.pop("runtime_seconds")
    second.pop("runtime_seconds")
    assert first == second
    assert first["status"] == "ESTIMABLE"
    h, f = first["H_pp"], first["F_pp"]
    fa = first["F_eligible_patients_pp"]
    fs = first["F_selected_sections_pp"]
    q = first["Q_pp"]
    assert math.isclose(h - f, (h - q) + (q - fs) + (fs - fa) + (fa - f), abs_tol=1e-12)
    for row in first["sections"]:
        assert 0.0 <= row["is_detection"] <= 1.0
        assert 0.0 <= row["ss_detection"] <= 1.0
        assert row["original_ss_low_edges"] >= 0


def test_synthetic_lattice_and_intensities() -> None:
    rng = np.random.default_rng(908)
    params = u2.patient_params(rng)
    data, truth, q, qc = u2.make_section(rng, "G3", "D2", "S2", params, 0)
    assert not data[["array_row", "array_col"]].duplicated().any()
    assert ((data.array_row + data.array_col) % 2 == 0).all()
    assert set(data.compartment) == {"tumor", "stroma"}
    assert np.all((q > 0.0) & (q < 1.0))
    assert len(q) == qc["spots"]
    assert truth["geometry"] == "G3"
