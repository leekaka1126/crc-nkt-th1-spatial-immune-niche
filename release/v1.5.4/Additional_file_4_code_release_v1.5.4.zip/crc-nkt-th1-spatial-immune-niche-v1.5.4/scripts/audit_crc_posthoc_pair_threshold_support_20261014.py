"""Post hoc, support-only threshold grid for the frozen CRC E4 pair ledger.

Date: 2026-10-14. Deterministic; no random seed or effect estimation.
Python: standard library (tested with Python 3.14).
Input: archived S14a/S14b/S14f CSVs. Never modifies source inputs.
"""

from __future__ import annotations

import csv
import hashlib
import json
from collections import defaultdict
from pathlib import Path
import sys


ROOT = Path(__file__).resolve().parents[1]
SUPP = ROOT / "manuscript/CRC_NKT_v11_1/supplementary"
OUT = ROOT / "analysis/posthoc_extension_20261014"
S14A = SUPP / "Table_S14a_shift_edge_selection.csv"
S14B = SUPP / "Table_S14b_pair_and_edge_hops.csv"
S14F = SUPP / "Table_S14f_pathology_pair_support.csv"
THRESHOLDS = (10, 15, 20, 25, 30, 40)
PAIRS = ("tumor->tumor", "tumor->stroma", "stroma->tumor", "stroma->stroma")


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_csv(path: Path, columns: list[str], rows: list[dict[str, object]]) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns, extrasaction="raise")
        writer.writeheader()
        writer.writerows(rows)


def offset_key(row: dict[str, str]) -> tuple[str, str, int, int]:
    return (row["dataset"], row["sample"], int(row["shift_array_row"]), int(row["shift_array_col"]))


def main() -> None:
    a_rows, b_rows, f_rows = read_csv(S14A), read_csv(S14B), read_csv(S14F)
    assert len(a_rows) == 1920 and len(b_rows) == 15360 and len(f_rows) == 8
    offsets = {offset_key(row): row for row in a_rows}
    assert len(offsets) == len(a_rows)

    section_offsets: dict[tuple[str, str, str], set[tuple[str, str, int, int]]] = defaultdict(set)
    accepted: dict[tuple[str, str, str], set[tuple[str, str, int, int]]] = defaultdict(set)
    for key, row in offsets.items():
        section = (row["dataset"], row["sample"], row["patient_id"])
        section_offsets[section].add(key)
        if row["status"] == "PASS":
            accepted[section].add(key)
    assert len(section_offsets) == 20
    assert all(len(keys) == 96 for keys in section_offsets.values())
    section_pass = {section: len(accepted[section]) >= 24 for section in section_offsets}
    assert sum(section_pass.values()) == 16

    cells: dict[tuple[str, str, int, int, str], dict[bool, dict[str, str]]] = defaultdict(dict)
    for row in b_rows:
        key4 = offset_key(row)
        assert key4 in offsets
        assert row["status"] == offsets[key4]["status"]
        pair = row["pathology_pair"]
        assert pair in PAIRS
        group = row["IS_high_source"] == "True"
        key5 = (*key4, pair)
        assert group not in cells[key5]
        cells[key5][group] = row
    assert len(cells) == 20 * 96 * 4
    assert all(set(groups) == {False, True} for groups in cells.values())

    # The original 30/30 gate must be reproduced at every originally accepted offset.
    for key, groups in cells.items():
        if offsets[key[:4]]["status"] != "PASS":
            continue
        compatible = min(int(groups[False]["n_compatible"]), int(groups[True]["n_compatible"]))
        original = groups[False]["pair_passed_minimum"] == "True"
        assert groups[True]["pair_passed_minimum"] == groups[False]["pair_passed_minimum"]
        assert (compatible >= 30) == original, f"Frozen gate mismatch: {key}"

    section_rows: list[dict[str, object]] = []
    summary_rows: list[dict[str, object]] = []
    both_cross_rows: list[dict[str, object]] = []
    expected = {(row["dataset"], row["pathology_pair"]): row for row in f_rows}
    datasets = sorted({section[0] for section in section_offsets})

    for threshold in THRESHOLDS:
        for section in sorted(section_offsets):
            dataset, sample, patient = section
            for pair in PAIRS:
                potential = 0
                frozen = 0
                for key4 in section_offsets[section]:
                    groups = cells[(*key4, pair)]
                    qualified = min(int(groups[False]["n_compatible"]), int(groups[True]["n_compatible"])) >= threshold
                    potential += int(qualified)
                    frozen += int(qualified and section_pass[section] and key4 in accepted[section])
                section_rows.append({
                    "threshold_each_IS_group": threshold,
                    "dataset": dataset,
                    "sample": sample,
                    "patient_id": patient,
                    "pathology_pair": pair,
                    "original_section_pass": str(section_pass[section]).lower(),
                    "attempted_offset_n": 96,
                    "original_accepted_offset_n": len(accepted[section]),
                    "potential_pair_offset_n_all_attempts": potential,
                    "frozen_frame_accepted_offset_n": len(accepted[section]) if section_pass[section] else "",
                    "frozen_frame_pair_qualified_offset_n": frozen if section_pass[section] else "",
                    "frozen_frame_pair_status": (
                        "SECTION_FAILED" if not section_pass[section] else
                        "SUPPORTED" if frozen else "NOT_ESTIMABLE_AT_THRESHOLD"
                    ),
                })

        for dataset in datasets:
            ds_rows = [row for row in section_rows if row["threshold_each_IS_group"] == threshold and row["dataset"] == dataset]
            passing_patients = {row["patient_id"] for row in ds_rows if row["original_section_pass"] == "true"}
            for pair in PAIRS:
                rows = [row for row in ds_rows if row["pathology_pair"] == pair]
                positive_patients = {
                    row["patient_id"] for row in rows
                    if row["original_section_pass"] == "true" and int(row["frozen_frame_pair_qualified_offset_n"]) > 0
                }
                summary = {
                    "threshold_each_IS_group": threshold,
                    "dataset": dataset,
                    "pathology_pair": pair,
                    "candidate_section_n": len(rows),
                    "candidate_patient_n": len({row["patient_id"] for row in rows}),
                    "attempted_pair_offset_n": sum(int(row["attempted_offset_n"]) for row in rows),
                    "potential_pair_offset_n_all_attempts": sum(int(row["potential_pair_offset_n_all_attempts"]) for row in rows),
                    "potential_candidate_section_n": sum(int(row["potential_pair_offset_n_all_attempts"]) > 0 for row in rows),
                    "potential_candidate_patient_n": len({row["patient_id"] for row in rows if int(row["potential_pair_offset_n_all_attempts"]) > 0}),
                    "frozen_passing_section_n": sum(row["original_section_pass"] == "true" for row in rows),
                    "frozen_contributing_patient_n": len(passing_patients),
                    "frozen_accepted_pair_offset_n": sum(int(row["frozen_frame_accepted_offset_n"]) for row in rows if row["original_section_pass"] == "true"),
                    "frozen_qualified_pair_offset_n": sum(int(row["frozen_frame_pair_qualified_offset_n"]) for row in rows if row["original_section_pass"] == "true"),
                    "frozen_supported_section_n": sum(row["original_section_pass"] == "true" and int(row["frozen_frame_pair_qualified_offset_n"]) > 0 for row in rows),
                    "frozen_supported_patient_n": len(positive_patients),
                }
                summary_rows.append(summary)
                if threshold == 30:
                    ref = expected[(dataset, pair)]
                    assert summary["frozen_accepted_pair_offset_n"] == int(ref["accepted_shift_section_n"])
                    assert summary["frozen_qualified_pair_offset_n"] == int(ref["qualified_shift_section_n"])
                    assert summary["frozen_supported_patient_n"] == int(ref["qualified_patient_n"])
            cross_sets = []
            for pair in ("tumor->stroma", "stroma->tumor"):
                cross_sets.append({
                    row["patient_id"] for row in ds_rows
                    if row["pathology_pair"] == pair and row["original_section_pass"] == "true"
                    and int(row["frozen_frame_pair_qualified_offset_n"]) > 0
                })
            both_cross_rows.append({
                "threshold_each_IS_group": threshold,
                "dataset": dataset,
                "frozen_contributing_patient_n": len(passing_patients),
                "both_cross_pairs_supported_same_patient_n": len(cross_sets[0] & cross_sets[1]),
                "note": "Pairs may qualify in different sections and offsets; no effects re-estimated",
            })

    OUT.mkdir(parents=True, exist_ok=True)
    section_path = OUT / "Table_S19a_pair_threshold_support_by_section.csv"
    summary_path = OUT / "Table_S19b_pair_threshold_support_by_cohort.csv"
    cross_path = OUT / "Table_S19c_both_cross_pairs_by_patient.csv"
    write_csv(section_path, list(section_rows[0]), section_rows)
    write_csv(summary_path, list(summary_rows[0]), summary_rows)
    write_csv(cross_path, list(both_cross_rows[0]), both_cross_rows)
    manifest_path = OUT / "manifest.json"
    manifest = {
        "date": "2026-10-14",
        "analysis": "post hoc support-only threshold grid; no effects, intervals or P values",
        "thresholds": list(THRESHOLDS),
        "input_sha256": {str(path.relative_to(ROOT)).replace("\\", "/"): sha256(path) for path in (S14A, S14B, S14F)},
        "output_sha256": {path.name: sha256(path) for path in (section_path, summary_path, cross_path)},
        "rows": {section_path.name: len(section_rows), summary_path.name: len(summary_rows), cross_path.name: len(both_cross_rows)},
        "frozen_30_gate_reconciled": True,
        "python": sys.version.split()[0],
    }
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print("PASS: frozen 30/30 gate matches all accepted-offset cells and all eight S14f rows")
    print(f"Rows: section={len(section_rows)}, summary={len(summary_rows)}, both-cross={len(both_cross_rows)}")
    for row in summary_rows:
        if row["dataset"] == "Valdeolivas_2024" and row["pathology_pair"] in ("tumor->stroma", "stroma->tumor"):
            print(row["threshold_each_IS_group"], row["pathology_pair"],
                  row["frozen_qualified_pair_offset_n"], "/", row["frozen_accepted_pair_offset_n"],
                  "patients", row["frozen_supported_patient_n"])


if __name__ == "__main__":
    main()
