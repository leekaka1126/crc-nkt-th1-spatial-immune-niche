#!/usr/bin/env python
"""Post hoc unique-source/target-spot audit of frozen E4 edge support.

No contrast, threshold, interval, or patient effect is estimated here.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
from pathlib import Path
import platform

import numpy as np
import pandas as pd
from scipy.spatial import cKDTree

ROOT = Path(__file__).resolve().parents[1]
SOURCE_SCRIPT = ROOT / "scripts/run_valdeolivas_pathology_matched_replication.py"
PLAN = ROOT / "protocol/CRC_v11_12_10_unique_spot_support_plan_2026-10-15.md"
S14A = ROOT / "manuscript/CRC_NKT_v11_1/supplementary/Table_S14a_shift_edge_selection.csv"
S14B = ROOT / "manuscript/CRC_NKT_v11_1/supplementary/Table_S14b_pair_and_edge_hops.csv"
SECTIONS = ROOT / "results/CRC_v11_8_full_edge_selection_2026-10-09/Table_section_selection_summary.csv"
EXTERNAL_DIR = ROOT / "results/CRC_Valdeolivas_pathology_matched_v1_2026-10-08/external_spot_scores"
OUT = ROOT / "manuscript/CRC_NKT_v11_1/supplementary"
PAIRS = ("tumor->tumor", "tumor->stroma", "stroma->tumor", "stroma->stroma")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def frozen_module():
    spec = importlib.util.spec_from_file_location("frozen_unique_spot_loader", SOURCE_SCRIPT)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def unique_count(indices: np.ndarray) -> int:
    return int(np.unique(indices).size)


def audit_section(data: pd.DataFrame, offsets: pd.DataFrame, identity: tuple[str, str, str], module) -> list[dict]:
    if data.barcode.duplicated().any() or len(offsets) != 96:
        raise AssertionError(f"Bad spot or offset identity: {identity}")
    layer = data.compartment.astype(str).to_numpy()
    immune = module.true_flags(data.IS_high_q75, "IS_high_q75")
    stroma = module.true_flags(data.SS_high_q75, "SS_high_q75")
    ar, ac = data.array_row.to_numpy(int), data.array_col.to_numpy(int)
    if ((ar + ac) % 2).any() or data[["array_row", "array_col"]].duplicated().any():
        raise AssertionError(f"Bad Visium lattice: {identity}")
    distances, neighbors = cKDTree(data[["row", "col"]].to_numpy(float)).query(
        data[["row", "col"]].to_numpy(float), k=7)
    pitch = float(np.median(distances[:, 1]))
    short = (distances[:, 1:] <= 1.6 * pitch).reshape(-1)
    all_source = np.repeat(np.arange(len(data)), 6)[short]
    all_target = neighbors[:, 1:].reshape(-1)[short]
    strict = np.isin(layer[all_source], ["tumor", "stroma"]) & np.isin(
        layer[all_target], ["tumor", "stroma"])
    source, target = all_source[strict], all_target[strict]
    source_high = immune[source]
    base_eligible = ~stroma[source]
    pair = (layer[source] == "stroma").astype(np.int8) * 2 + (
        layer[target] == "stroma").astype(np.int8)
    code = pair * 2 + source_high.astype(np.int8)
    lookup = np.full((int(ar.max()) + 1, int(ac.max()) + 1), -1, dtype=np.int32)
    lookup[ar, ac] = np.arange(len(data), dtype=np.int32)
    records = []
    for offset in offsets.itertuples(index=False):
        dr, dc = int(offset.shift_array_row), int(offset.shift_array_col)
        rr, cc = ar[target] + dr, ac[target] + dc
        in_grid = (rr >= 0) & (rr < lookup.shape[0]) & (cc >= 0) & (cc < lookup.shape[1])
        mapped = np.full(len(target), -1, dtype=np.int32)
        mapped[in_grid] = lookup[rr[in_grid], cc[in_grid]]
        exists = mapped >= 0
        compatible = exists.copy()
        compatible[exists] &= layer[mapped[exists]] == layer[target[exists]]
        compatible_eligible = compatible & base_eligible
        n_matched_high = int((compatible & source_high).sum())
        pre_gate = n_matched_high >= 100 and n_matched_high / int(source_high.sum()) >= 0.10
        grouped = np.bincount(code[compatible_eligible], minlength=8).reshape(4, 2)
        pair_pass = grouped.min(axis=1) >= 30
        if not pre_gate or int(compatible_eligible.sum()) < 100:
            pair_pass[:] = False
        retained = compatible_eligible & pair_pass[pair]
        if not pre_gate:
            status = "FAIL_COVERAGE"
        elif not int(pair_pass.sum()):
            status = "FAIL_PAIR_MINIMUM"
        else:
            status = "PASS"
        if status != offset.status or int(retained.sum()) != int(offset.n_pair_retained_SS_low_source_edges):
            raise AssertionError(f"S14a offset mismatch: {identity}, {dr}, {dc}")
        for pair_index, pair_name in enumerate(PAIRS):
            for high in (0, 1):
                cell = pair_index * 2 + high
                original_cell = base_eligible & (code == cell)
                compatible_cell = compatible_eligible & (code == cell)
                retained_cell = retained & (code == cell)
                records.append({
                    "dataset": identity[0], "sample": identity[1], "patient_id": identity[2],
                    "shift_array_row": dr, "shift_array_col": dc,
                    "hex_radius": int(offset.hex_radius), "status": status,
                    "pathology_pair": pair_name, "IS_high_source": bool(high),
                    "n_original_SS_low_edges": int(original_cell.sum()),
                    "n_original_unique_source_spots": unique_count(source[original_cell]),
                    "n_original_unique_target_spots": unique_count(target[original_cell]),
                    "n_compatible": int(compatible_cell.sum()),
                    "n_compatible_unique_source_spots": unique_count(source[compatible_cell]),
                    "n_compatible_unique_original_target_spots": unique_count(target[compatible_cell]),
                    "n_compatible_unique_translated_target_spots": unique_count(mapped[compatible_cell]),
                    "pair_passed_minimum": bool(pair_pass[pair_index]),
                    "n_pair_retained": int(retained_cell.sum()),
                    "n_retained_unique_source_spots": unique_count(source[retained_cell]),
                    "n_retained_unique_original_target_spots": unique_count(target[retained_cell]),
                    "n_retained_unique_translated_target_spots": unique_count(mapped[retained_cell]),
                })
    return records


def main() -> None:
    module = frozen_module()
    sections = pd.read_csv(SECTIONS, dtype={"sample": str, "patient_id": str})
    shifts = pd.read_csv(S14A, dtype={"sample": str, "patient_id": str})
    ledger = pd.read_csv(S14B, dtype={"sample": str, "patient_id": str})
    source_run = pd.read_csv(module.SOURCE_RUN, dtype={"sample": str, "patient_id": str})
    if (len(sections), len(shifts), len(ledger)) != (20, 1920, 15360):
        raise AssertionError("Frozen section, offset or pair/group dimensions changed")
    input_hashes = {str(path.relative_to(ROOT)): sha256(path) for path in
                    (PLAN, SOURCE_SCRIPT, S14A, S14B, SECTIONS, module.SOURCE_RUN,
                     module.PANEL_SCRIPT, module.SHIFT_SCRIPT, module.JOIN_SCRIPT)}
    all_records: list[dict] = []
    for section in sections.itertuples(index=False):
        identity = (str(section.dataset), str(section.sample), str(section.patient_id))
        attempts = shifts.loc[shifts.dataset.eq(identity[0]) & shifts["sample"].eq(identity[1])]
        if len(attempts) != 96 or not attempts.patient_id.eq(identity[2]).all():
            raise AssertionError(f"Offset identity mismatch: {identity}")
        if identity[0] == "GSE294385":
            source_record = source_run.loc[source_run["sample"].eq(identity[1])]
            if len(source_record) != 1:
                raise AssertionError(f"Missing source input: {identity}")
            source_record = source_record.iloc[0]
            data = module.source_data(source_record)
            archive = Path(source_record["archive"])
            input_hashes[str(archive)] = sha256(archive)
            score_file = module.SOURCE_SPOTS / f"Table_{identity[1]}_spot_scores_and_boundaries.csv"
            label_file = module.SOURCE_ANNOTATIONS / f"Table_{identity[1]}_author_pathology_spot_compartments.csv"
            input_hashes[str(score_file.relative_to(ROOT))] = sha256(score_file)
            input_hashes[str(label_file.relative_to(ROOT))] = sha256(label_file)
        else:
            score_file = EXTERNAL_DIR / f"Table_{identity[1]}_spot_scores.csv"
            data = pd.read_csv(score_file)
            input_hashes[str(score_file.relative_to(ROOT))] = sha256(score_file)
        print(f"Unique-spot support: {identity}", flush=True)
        all_records.extend(audit_section(data, attempts, identity, module))
    table = pd.DataFrame(all_records)
    keys = ["dataset", "sample", "patient_id", "shift_array_row", "shift_array_col",
            "hex_radius", "status", "pathology_pair", "IS_high_source"]
    if len(table) != 15360 or table.duplicated(keys).any() or ledger.duplicated(keys).any():
        raise AssertionError("Unexpected pair/group keys")
    check = table.merge(ledger[keys + ["n_original_SS_low_edges", "n_compatible",
                                       "pair_passed_minimum", "n_pair_retained"]],
                        on=keys, validate="one_to_one", suffixes=("_new", "_S14b"), indicator=True)
    if len(check) != 15360 or not check._merge.eq("both").all():
        raise AssertionError("S14b key mismatch")
    for name in ("n_original_SS_low_edges", "n_compatible", "pair_passed_minimum", "n_pair_retained"):
        if not check[f"{name}_new"].eq(check[f"{name}_S14b"]).all():
            raise AssertionError(f"S14b value mismatch: {name}")
    table["section_status"] = table.set_index(["dataset", "sample"]).index.map(
        sections.set_index(["dataset", "sample"]).section_status)
    table["accepted_in_passing_section"] = table.status.eq("PASS") & table.section_status.eq("PASS")
    output = OUT / "Table_S20a_unique_spot_support_by_offset_pair_group.csv"
    table.to_csv(output, index=False)
    eligible = table.loc[table.accepted_in_passing_section & table.pair_passed_minimum].copy()
    if len(eligible) == 0 or not eligible.n_pair_retained.ge(30).all():
        raise AssertionError("No qualified accepted pair/group rows")
    eligible["retained_edges_per_unique_source"] = (
        eligible.n_pair_retained / eligible.n_retained_unique_source_spots)
    summary = eligible.groupby(["dataset", "patient_id", "pathology_pair", "IS_high_source"],
                               as_index=False).agg(
        qualified_section_n=("sample", "nunique"),
        qualified_section_offset_n=("sample", "size"),
        retained_edge_min=("n_pair_retained", "min"),
        retained_edge_median=("n_pair_retained", "median"),
        retained_unique_source_min=("n_retained_unique_source_spots", "min"),
        retained_unique_source_median=("n_retained_unique_source_spots", "median"),
        retained_unique_original_target_median=("n_retained_unique_original_target_spots", "median"),
        retained_unique_translated_target_median=("n_retained_unique_translated_target_spots", "median"),
        retained_edges_per_unique_source_median=("retained_edges_per_unique_source", "median"),
        offsets_with_fewer_than_30_unique_sources=("n_retained_unique_source_spots",
                                                    lambda x: int((x < 30).sum())),
    )
    patient_output = OUT / "Table_S20b_unique_spot_support_by_patient.csv"
    summary.to_csv(patient_output, index=False)
    manifest = {
        "role": "post_hoc_unique_spot_support_only_no_new_effect",
        "approved_plan": str(PLAN.relative_to(ROOT)),
        "n_candidate_sections": 20, "n_attempted_section_offsets": 1920,
        "n_pair_group_rows": len(table), "n_accepted_section_offsets": int(
            table.loc[table.accepted_in_passing_section,
                      ["dataset", "sample", "shift_array_row", "shift_array_col"]].drop_duplicates().shape[0]),
        "all_pair_group_counts_equal_S14b": True,
        "unit_of_independence": "patient; spots, edges, sections and offsets are nested technical units",
        "definitions": {
            "unique_source": "distinct source barcode among directed edges in the specified cell",
            "unique_original_target": "distinct original target barcode among directed edges in the specified cell",
            "unique_translated_target": "distinct mapped target barcode after the frozen lattice translation",
            "patient_summary": "descriptive median/minimum across qualified accepted section-offsets, not a pooled spot count",
        },
        "software": {"python": platform.python_version(), "numpy": np.__version__, "pandas": pd.__version__},
        "input_sha256": input_hashes,
        "script_sha256": sha256(Path(__file__)),
        "outputs_sha256": {output.name: sha256(output), patient_output.name: sha256(patient_output)},
    }
    if manifest["n_accepted_section_offsets"] != 1395:
        raise AssertionError("Accepted section-offset denominator changed")
    manifest_output = OUT / "Table_S20_unique_spot_support_manifest.json"
    manifest_output.write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")
    print(summary.to_string(index=False), flush=True)
    print(f"S14b reconciliation PASS: {len(table)} cells, {manifest['n_accepted_section_offsets']} accepted offsets", flush=True)


if __name__ == "__main__":
    main()
