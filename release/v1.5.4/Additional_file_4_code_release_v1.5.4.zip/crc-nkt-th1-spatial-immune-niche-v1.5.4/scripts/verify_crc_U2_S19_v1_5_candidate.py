#!/usr/bin/env python
"""Read-only checksum and E4/U1/U2/S19 verification for the v1.5 bundle."""
from __future__ import annotations

import csv
import hashlib
import json
from collections import defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
RESULT = ROOT / "results/CRC_U2_summary_v1_2026-10-13"
SUPPLEMENT = ROOT / "manuscript/CRC_NKT_v11_1/supplementary"
S19_ANALYSIS = ROOT / "analysis/posthoc_extension_20261014"
THRESHOLDS = (10, 15, 20, 25, 30, 40)
PAIRS = ("tumor->tumor", "tumor->stroma", "stroma->tumor", "stroma->stroma")


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def count_rows(path: Path) -> int:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return sum(1 for _ in csv.DictReader(handle))


def read_rows(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def key(row: dict[str, str]) -> tuple[str, str, int, int]:
    return row["dataset"], row["sample"], int(row["shift_array_row"]), int(row["shift_array_col"])


def verify_s19() -> None:
    lock = json.loads((S19_ANALYSIS / "S19_DATA_LOCK.json").read_text(encoding="utf-8"))
    assert lock["seed"] is None and len(lock["files"]) == 6
    for relative, record in lock["files"].items():
        path = ROOT / relative
        if sha256(path) != record["sha256"]:
            raise AssertionError(f"S19 data-lock byte drift: {relative}")

    a_rows = read_rows(SUPPLEMENT / "Table_S14a_shift_edge_selection.csv")
    b_rows = read_rows(SUPPLEMENT / "Table_S14b_pair_and_edge_hops.csv")
    f_rows = read_rows(SUPPLEMENT / "Table_S14f_pathology_pair_support.csv")
    s19a = read_rows(SUPPLEMENT / "Table_S19a_pair_threshold_support_by_section.csv")
    s19b = read_rows(SUPPLEMENT / "Table_S19b_pair_threshold_support_by_cohort.csv")
    s19c = read_rows(SUPPLEMENT / "Table_S19c_both_cross_pairs_by_patient.csv")
    assert (len(a_rows), len(b_rows), len(f_rows), len(s19a), len(s19b), len(s19c)) == (1920, 15360, 8, 480, 48, 12)
    offsets = {key(row): row for row in a_rows}
    assert len(offsets) == len(a_rows)
    accepted_by_section: dict[tuple[str, str, str], set[tuple[str, str, int, int]]] = defaultdict(set)
    attempted_by_section: dict[tuple[str, str, str], set[tuple[str, str, int, int]]] = defaultdict(set)
    for offset, row in offsets.items():
        section = row["dataset"], row["sample"], row["patient_id"]
        attempted_by_section[section].add(offset)
        if row["status"] == "PASS":
            accepted_by_section[section].add(offset)
    assert len(attempted_by_section) == 20 and all(len(v) == 96 for v in attempted_by_section.values())
    passing = {section for section in attempted_by_section if len(accepted_by_section[section]) >= 24}
    assert len(passing) == 16

    groups: dict[tuple[str, str, int, int, str], dict[bool, int]] = defaultdict(dict)
    for row in b_rows:
        k = (*key(row), row["pathology_pair"])
        is_high = row["IS_high_source"] == "True"
        assert is_high not in groups[k]
        groups[k][is_high] = int(row["n_compatible"])
    assert len(groups) == 20 * 96 * 4 and all(set(value) == {False, True} for value in groups.values())

    expected_section: dict[tuple[int, str, str, str], tuple[int, int | None]] = {}
    expected_cohort: dict[tuple[int, str, str], tuple[int, int, int]] = {}
    expected_both: dict[tuple[int, str], int] = {}
    for threshold in THRESHOLDS:
        for section, offset_set in attempted_by_section.items():
            dataset, sample, _patient = section
            for pair in PAIRS:
                qualifying = {offset for offset in offset_set if min(groups[(*offset, pair)].values()) >= threshold}
                frozen = len(qualifying & accepted_by_section[section]) if section in passing else None
                expected_section[(threshold, dataset, sample, pair)] = len(qualifying), frozen
        for dataset in {section[0] for section in attempted_by_section}:
            supported_by_pair: dict[str, set[str]] = {}
            for pair in PAIRS:
                selected = [(section, expected_section[(threshold, dataset, section[1], pair)][1])
                            for section in passing if section[0] == dataset]
                qualified_offsets = sum(count for _section, count in selected if count is not None)
                sections = sum(count > 0 for _section, count in selected if count is not None)
                patients = {section[2] for section, count in selected if count is not None and count > 0}
                expected_cohort[(threshold, dataset, pair)] = qualified_offsets, sections, len(patients)
                supported_by_pair[pair] = patients
            expected_both[(threshold, dataset)] = len(supported_by_pair["tumor->stroma"] & supported_by_pair["stroma->tumor"])

    for row in s19a:
        got = expected_section[(int(row["threshold_each_IS_group"]), row["dataset"], row["sample"], row["pathology_pair"])]
        assert int(row["potential_pair_offset_n_all_attempts"]) == got[0]
        assert row["frozen_frame_pair_qualified_offset_n"] == ("" if got[1] is None else str(got[1]))
    for row in s19b:
        k = int(row["threshold_each_IS_group"]), row["dataset"], row["pathology_pair"]
        got = expected_cohort[k]
        assert (int(row["frozen_qualified_pair_offset_n"]), int(row["frozen_supported_section_n"]),
                int(row["frozen_supported_patient_n"])) == got, k
    for row in s19c:
        k = int(row["threshold_each_IS_group"]), row["dataset"]
        assert int(row["both_cross_pairs_supported_same_patient_n"]) == expected_both[k], k
    s14f = {(row["dataset"], row["pathology_pair"]): row for row in f_rows}
    for (threshold, dataset, pair), values in expected_cohort.items():
        if threshold == 30:
            ref = s14f[(dataset, pair)]
            assert values[0] == int(ref["qualified_shift_section_n"])
            assert values[2] == int(ref["qualified_patient_n"])
    for name in ("Table_S19a_pair_threshold_support_by_section.csv", "Table_S19b_pair_threshold_support_by_cohort.csv",
                 "Table_S19c_both_cross_pairs_by_patient.csv"):
        assert sha256(S19_ANALYSIS / name) == sha256(SUPPLEMENT / name)
    print("S19: independent read-only six-threshold recomputation, data lock, 30/30 S14f reconciliation PASS")


def main() -> None:
    manifest = json.loads((ROOT / "SHA256_MANIFEST.json").read_text(encoding="utf-8"))
    assert manifest["version"] == "1.5.4-E4-U1-U2-S19-S20"
    assert manifest["status"] == "release_artifact_external_deposit_unverified"
    files = manifest["files"]
    actual = {p.relative_to(ROOT).as_posix() for p in ROOT.rglob("*") if p.is_file()}
    expected = {row["path"] for row in files} | {"SHA256_MANIFEST.json"}
    if expected - actual:
        raise AssertionError(f"Required files missing: {sorted(expected-actual)}")
    for row in files:
        path = ROOT / row["path"]
        if path.stat().st_size != row["bytes"] or sha256(path) != row["sha256"]:
            raise AssertionError(f"Checksum mismatch: {row['path']}")
    if sha256(ROOT / "scripts/run_crc_U2_known_truth_simulation.py") != manifest["frozen_u2_script_sha256"]:
        raise AssertionError("Frozen U2 script mismatch")
    if sha256(ROOT / "scripts/audit_crc_posthoc_pair_threshold_support_20261014.py") != manifest["posthoc_s19_script_sha256"]:
        raise AssertionError("Post hoc S19 script mismatch")
    if sha256(S19_ANALYSIS / "S19_DATA_LOCK.json") != manifest["s19_data_lock_sha256"]:
        raise AssertionError("S19 data lock mismatch")
    expected_rows = {
        RESULT / "U2_formal_all_attempts.csv": 9000,
        RESULT / "U2_independent_calibration_all_attempts.csv": 3600,
        RESULT / "U2_formal_all_sections.csv": 72861,
        RESULT / "U2_formal_all_patients.csv": 54000,
        RESULT / "U2_scenario_summary.csv": 18,
        RESULT / "U2_sample_size_all_attempts.csv": 1200,
        SUPPLEMENT / "Table_S17a_U2_scenario_summary.csv": 18,
        SUPPLEMENT / "Table_S17d_U2_contributing_patients.csv": 18,
        SUPPLEMENT / "Table_S16a_U1_section_pair_support.csv": 40,
        SUPPLEMENT / "Table_S16b_U1_patient_pair_effects.csv": 44,
        SUPPLEMENT / "Table_S16c_U1_same_patient_equal_pair_mix.csv": 22,
        SUPPLEMENT / "Table_S16d_U1_joint_offset_support_only.csv": 20,
        SUPPLEMENT / "Table_S16e_U1_cohort_estimands.csv": 12,
        SUPPLEMENT / "Table_S19a_pair_threshold_support_by_section.csv": 480,
        SUPPLEMENT / "Table_S19b_pair_threshold_support_by_cohort.csv": 48,
        SUPPLEMENT / "Table_S19c_both_cross_pairs_by_patient.csv": 12,
    }
    for path, expected_count in expected_rows.items():
        found = count_rows(path)
        if found != expected_count:
            raise AssertionError(f"Row-count mismatch for {path.name}: {found} != {expected_count}")
    verify_s19()
    print(f"Verified {len(files)} file hashes and {len(expected_rows)} table denominators; check external release and DOI separately")


if __name__ == "__main__":
    main()
