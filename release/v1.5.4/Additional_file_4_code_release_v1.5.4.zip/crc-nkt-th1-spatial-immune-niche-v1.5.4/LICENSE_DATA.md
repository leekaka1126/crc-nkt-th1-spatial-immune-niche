# License for author-generated analytical outputs

Copyright (c) 2026 Jiaozhen Hao and Minghui Li.

The authors license their **original derived CSV tables, analytical JSON result
files, and original PNG/PDF figures in this bundle** under Creative Commons
Attribution 4.0 International (CC BY 4.0):
https://creativecommons.org/licenses/by/4.0/

Credit Jiaozhen Hao and Minghui Li, cite this version of the bundle, link the
license, and indicate modifications. When reusing analyses derived from a
third-party dataset, separately credit its original creator and dataset DOI;
this license does not supersede third-party rights. Source data, source images,
pathology archives, third-party clinical information and external dependencies
are not relicensed by the authors. The top-level MIT LICENSE applies only to
author-owned software and documentation, not to these analytical outputs.
