# Data sources and rights for v1.5.4 release artifact

This is the versioned packaging artifact. Its public deposit, release and DOI
must be confirmed against external records. Two author-approved licenses apply
to different materials in the bundle:

- The top-level `LICENSE` (MIT) covers original code and documentation by
  Jiaozhen Hao and Minghui Li. `CITATION.cff` describes this software component.
- `LICENSE_DATA.md` (CC BY 4.0) covers the authors' original derived CSV tables,
  analytical JSON results and original PNG/PDF figures. Attribute the two
  authors, link the license and indicate modifications.
- Neither license changes the rights in third-party data, images, annotations,
  metadata, publications, software dependencies or their source archives.

## Public source attribution and adaptation

- GEO GSE294385: https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE294385
- Valdeolivas, Alberto. *Profiling the Heterogeneity of Colorectal Cancer
  Consensus Molecular Subtypes using Spatial Transcriptomics: datasets*.
  Zenodo, 2023, version v4: https://doi.org/10.5281/zenodo.7760264
- Valdeolivas A, Amberg B, Giroud N, et al. *Profiling the heterogeneity of
  colorectal cancer consensus molecular subtypes using spatial transcriptomics*.
  npj Precision Oncology 8, 10 (2024):
  https://doi.org/10.1038/s41698-023-00488-4

The requesting user supplied a screenshot of the Zenodo record's Rights field
showing **Creative Commons Attribution 4.0 International** for record 7760264.
The crop does not display its URL; this is user-provided record attribution,
not an independently captured URL-and-license image. The public Zenodo page
confirms the dataset creator, title, DOI, version and pathology-annotation file.
The CC BY 4.0 terms require credit, a license link and notice of changes:
https://creativecommons.org/licenses/by/4.0/

This bundle does **not** redistribute the original GEO/Zenodo archives,
pathology ZIPs, raw matrices, histology images or private clinical records.
Where applicable, the authors transformed public inputs into pathology
crosswalks, section- and patient-level score/edge summaries, support ledgers,
simulation results and figures. These outputs are not presented as unchanged
copies of the source datasets or as an endorsement by their creators. Cite the
original datasets and publications in any downstream use.

## Deliberate scope exclusions and residual risk

Only the E4/U1/U2/S19/S20 reproducibility files named in the README and manifest
are bundled, not all manuscript S1-S20 supplements. S1 patient-tissue
summaries, S5 treatment-response crosswalks, S8b original diagnosis mapping and
non-core exploratory tables remain outside this archive pending separate
field-level/source review; they were not deleted from the manuscript workspace.

U2 ledgers contain synthetic patients, not a real validation cohort. Public
source sample/patient pseudonyms remain in the core spatial ledgers to permit
cluster-level verification. A heuristic identifier scan does not eliminate
linkage risk; review the final ZIP and public Git history before publication.

S20a/S20b are original author-generated **derived** tables, covered by
`LICENSE_DATA.md` rather than the MIT software license. The S20 source
provenance record keeps source-file hashes but removes machine-local absolute
path prefixes. No original GEO/Zenodo spot matrix, image or pathology archive
is redistributed. The historical S20 reconstruction script needs those public
inputs in a full workspace; the package-only S20 checker verifies archived
ledgers and summaries, not fresh reconstruction of distinct spots.
