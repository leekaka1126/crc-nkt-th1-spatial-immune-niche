# Supplementary Table S17c. U2 computational targets and denominators

The symbols below are defined by the locked simulator, not by CRC biology. All
contrasts are in percentage points and compare the same simulated observed
target positions with translated target positions. The latent stromal-state
probability `q(s)` is known from the specified generating equation, including
at hypothetical translated coordinates outside the sampled tissue footprint.
It is not an observed patient biomarker or a fixed universal effect.

| Symbol | Outcome on eligible edges | Edge/offset rule | Section/patient aggregation | Reported contrast |
| --- | --- | --- | --- | --- |
| `H` | Measured section-relative SS-high q75 label | E4-retained compatible edges, four directed pairs gated at 30/30, dynamic minimum-group weights, E4-accepted offsets | Passing sections averaged within contributing patients; contributing patients equally weighted | Measured E4 statistic |
| `Q` | Known `q(s)` at original and translated target coordinates | Exactly the E4 support, pair gate, dynamic weights and accepted offsets used by `H` | Same selected sections and contributing patients as `H` | Selected-support probability oracle |
| `F_selected_sections` | Known `q(s)` | All original eligible SS-low-source directed edges; original pair weights fixed; all 96 hypothetical translations; each pair requires at least one edge in both IS groups for this oracle | Only E4-passing sections of H-contributing patients; section then patient averaging | Full-original-edge reference on the *selected* sections |
| `F_eligible_patients` | Known `q(s)` | Same full-original-edge rule as `F` | All generated sections of H-contributing patients, including E4-failing sections | Isolates subsequent section-selection term |
| `F` | Known `q(s)` | Same full-original-edge rule | All generated sections of all six generated patients, including those without any E4-passing section | Full-generated-cohort computational reference |

The patient-level full-edge oracle is computed for **all** generated sections.
The saved formal section ledger and an independent aggregation audit found
`full_oracle_patients = 6` in all 9,000 formal cohorts. Thus `F` is **not**
restricted to E4-selected sections. That restriction applies only to the
intermediate `F_selected_sections`. Replacing `F` by the latter would change
the estimand, not merely its name.

For each estimable replicate, the exact four-part identity is

`H − F = (H − Q) + (Q − F_selected_sections) +
(F_selected_sections − F_eligible_patients) +
(F_eligible_patients − F)`.

Figure 5C and S17a report `Q − F_selected_sections`, not `Q − F`. The former
compares selected versus original edge/offset support **within E4-selected
sections and patients**. The other two `F` differences separate section and
patient selection. No part is a measured CRC bias, a causal effect, or an
estimate of how much the real six-patient point estimate should be adjusted.
`S0` deletes one direct immune-field term in the stromal log-odds equation; it
does not impose an exact zero on `H`, `F`, or their difference, and no type-I
error rate or statistical power was estimated.

Denominators are distinct: cohort non-estimability uses all 500 attempted
independent six-patient cohorts per scenario; patient support uses all 3,000
generated patients per scenario; accepted-offset retention is conditional on
an accepted translation; oracle target contrasts use only cohorts where `H`
and `Q` exist. In the separate 200-cohort-per-scenario calibration stream,
`E(H | cohort estimable)` is estimated with Monte Carlo error. Inclusion of
that estimated reference within a nominal bootstrap interval is named
*reference inclusion*, not coverage of a fixed, exactly known parameter.
Offsets and sections are nested technical units, not independent Monte Carlo
replicates. S17d gives the complete 0-to-6 contributing-patient distribution
by scenario; unavailable intervals and non-estimable cohorts remain in the
500-attempt denominator.

Provenance: locked definitions in
`protocol/CRC_U2_known_truth_simulation_LOCKED_v1_2026-10-13.md`;
implementation in `scripts/run_crc_U2_known_truth_simulation.py` (`section_oracles`
and `run_replicate`); saved section and attempt ledgers in
`results/CRC_U2_summary_v1_2026-10-13/`; independent section-to-cohort
aggregation audit in `scripts/audit_crc_U2_review_from_section_ledger.py` and
`reports/CRC_U2_review_ledger_audit_2026-10-13.json`. This audit starts from
saved per-section oracle values. It does **not** independently recalculate
the spot graph, edge-level `q(s)` queries, or original source code of the
historical CRC run. A separate, post hoc four-replicate atomic-edge check that
does recalculate synthetic graph and oracle arithmetic is documented in S17e;
it regenerates inputs with the same frozen simulator and does not recover or
independently execute the historical CRC analysis.
