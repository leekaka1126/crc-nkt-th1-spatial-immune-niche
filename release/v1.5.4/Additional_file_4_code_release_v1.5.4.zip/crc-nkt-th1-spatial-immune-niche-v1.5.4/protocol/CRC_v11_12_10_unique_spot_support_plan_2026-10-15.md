# Post hoc unique-spot support audit (v11.12.10)

Approved by the user on 2026-10-15 before execution. This is a descriptive support audit, not a re-estimation of E4.

- Frame: the 20 archived E4 candidate primary-CRC sections and all 96 fixed translations per section (1,920 section-offset attempts). Include failed attempts and non-estimable pathology pairs.
- Inputs: original Visium spot coordinates, frozen spot-level IS/SS high labels and broad pathology labels, and archived S14a/S14b edge-count ledgers. Source spot scores were previously validated against raw counts; this audit does not rescore expression.
- Reconstruct the original six-neighbor, short-edge, strict tumor/stroma directed graph. Apply the original SS-low-source restriction and the same offset-specific in-tissue, target-pathology and pair-minimum eligibility rules.
- For each section, offset, directed pathology pair and source-IS group, report original, compatible and retained directed-edge counts, plus distinct source spots, original target spots and translated target spots where applicable. A source spot can supply several directed edges. A spot or offset is not an independent patient.
- Reconcile all 15,360 pair/group rows and their original, compatible and retained edge counts with S14b, and offset status/counts with S14a. Abort on mismatch.
- Summarize accepted offsets of passing sections by patient and pathology pair; do not pool offset-level spot counts as independent observations. Preserve zero counts and explicit non-estimability.
- Keep the 30/30 edge gate, frozen section/offset frame, scores, E4 effects and all intervals unchanged. Do not choose a spot threshold or infer a new effect from the support counts.
