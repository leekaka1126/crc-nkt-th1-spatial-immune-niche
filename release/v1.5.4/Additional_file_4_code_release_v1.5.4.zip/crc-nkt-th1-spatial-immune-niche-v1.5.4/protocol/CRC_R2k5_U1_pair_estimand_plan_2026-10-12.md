# R2k5 U1: post hoc patient-level pathology-pair audit

Status: fixed before running the U1 calculation on 2026-10-12. This is a post hoc extension of the frozen E4 analysis, not prospective registration. The author-approved scope is TT and SS pair-specific estimability and an equal-pair mixture only within patients who have both pair estimates. No original E4 score, graph, shift, 30/30 pair gate, 24-accepted-shift section gate, patient estimate, or result table will be overwritten.

## Inputs and units

- Read the existing 15,360-row `Table_S14b_pair_and_edge_hops.csv` as the locked pair/group count ledger, `Table_S14a_shift_edge_selection.csv` as the accepted-offset status ledger, and `Table_S11a_Valdeolivas_by_section.csv` plus the `Primary_CRC` subset of `Table_S11b_GSE294385_harmonized_by_section.csv` for section eligibility. Existing S14i and S11c/d are cross-checks, not substitutes for computing pair effects.
- Dataset-local patient is the biological unit; sections and offsets are nested technical units. No patient identifiers are linked between datasets.
- The numerator and denominator of each rate come from the same retained original directed edges in one section, accepted offset, pair and IS group. `D_pair = (observed_high/high_edges - observed_low/low_edges) - (shifted_high/high_edges - shifted_low/low_edges)`. A pair qualifies only if both group rows have `pair_passed_minimum=True` and each retained count is at least 30.
- A failed section or a non-PASS offset never enters an effect. All candidate sections and failed offsets remain in the eligibility ledger with a reason and NA effect. A non-estimable effect is NA, not zero.

## Fixed descriptive estimands

1. E1 (separate TT and SS): For each passing section, average that pair's `D_pair` over its qualifying offsets among original PASS offsets. Average available section means within a patient, then patients equally within a cohort. A pair requires at least one qualifying offset in an originally passing section to be marked available for the minimal-support description. Report the number of qualifying offsets and sections; do not describe a one-offset result as stable.
2. Strict-support sensitivity for E1: Recalculate section and patient availability with at least 24 pair-qualified offsets in an originally passing section, without changing the original section PASS set. This is a post hoc stricter support description, not a replacement primary rule.
3. E2 (same-patient equal-pair mixture): Define `M_i = (theta_i_TT + theta_i_SS)/2` only for patients with both E1 estimates under the stated support tier. The cohort summary is the equal-patient mean of available `M_i`. Never combine TT from one patient with SS from another. Report the exact patient intersection and the numbers of available patients, sections and offsets for each component.
4. Joint same-section/same-offset support: Count, for each patient, accepted offsets in originally passing sections where TT and SS both pass the fixed pair gate. This is a support diagnostic only; E2 does not require identical edges or offsets, and it must not be called a fixed-edge or biologically equivalent estimand. No new contrast is estimated on this intersection.

## Uncertainty, comparisons and stopping rules

- Descriptive patient bootstrap: 10,000 resamples of the available patient values with replacement, PCG64 seed 42, 2.5th/97.5th percentiles, separately per cohort and estimand. Report the nominal interval and its uncalibrated coverage at small n. If fewer than two patients are estimable, report the individual point(s) and mark cohort interval NE.
- Leave-one-patient-out means are descriptive and only computed if at least two patients contribute. Report all patients, including outliers. No hypothesis test, P value, pooled cross-cohort estimate, clinical threshold or validation claim is planned.
- A common pair name across datasets establishes only algorithmic pair-label comparability. Different original pathology ontologies, measurement distributions, section/offset support and patient selection remain. E2's same-patient mixture does not prove common edge support or a shared biological target population.
- If one pair is largely NE or the same-patient intersection is small, report that failure and stop. Do not lower 30/30 or select an alternate support tier based on the direction or magnitude of results.

## Required outputs

The script will write input SHA-256 values, one row for every candidate section × pair, one row for every dataset-local patient × pair (including NA), an E2 patient table, a cohort estimand table with explicit denominators, a joint-offset support ledger, and a run report. It must reconcile original PASS offsets and original cohort means without altering them.
