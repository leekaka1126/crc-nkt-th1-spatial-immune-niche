# Validation checklist — v1.5.4 release artifact

This checklist is a release gate, **not** a certificate that public deposition or independent review has occurred. Record the operator, date, commands, exit codes, ZIP SHA-256 and any deviations in a separate signed report. Do not silently replace this ZIP after sign-off.

## Content and rights

- [ ] ZIP SHA-256 matches the reviewed artifact; no member is missing or unexpectedly added.
- [ ] `LICENSE` applies only to author-owned software/docs; `LICENSE_DATA.md` applies to original derived CSV/JSON/PNG/PDF outputs. Cite GEO GSE294385 and Valdeolivas/Zenodo 7760264 separately.
- [ ] Confirm that no original GEO/Zenodo raw archives, pathology ZIP, histology images, private clinical records, credential, access token or local absolute path is present in the upload artifact.
- [ ] Confirm S20a/S20b row-level pseudonyms and all other released derived fields are within the two authors' approved public scope.
- [ ] Both authors approve this **new** ZIP hash, version label, attribution and manuscript availability wording. Prior approval of v1.5.2/v1.5.3 does not substitute for this check.

## Computational checks

- [ ] In a clean extraction, `python -B scripts/verify_crc_U2_S19_v1_5_candidate.py` exits 0.
- [ ] In the same clean extraction, `python -B scripts/verify_crc_S20_unique_spot_ledger.py` exits 0.
- [ ] The S20 data lock passes strict column-level verification and records `seed: null` with the user-confirmed post hoc provenance.
- [ ] U1/U2 test suite passes in an independently built environment; record Python and package versions.
- [ ] U1 saved-ledger rerun and one-replicate U2 pilot smoke test finish in fresh output directories; do not confuse these with full 9,000/3,600-run reproduction.
- [ ] If claiming full raw-source S20 reproducibility, parameterize the historical S20 script and have a separate operator regenerate from original public spot coordinates and frozen labels. **Not satisfied by this package's S20 ledger verifier.**
- [ ] Keep E4's historical script-hash/pandas-version discrepancies and all post hoc labels visible; do not promote S19/S20 to validation of the E4 effect.

## External release gate

- [ ] Public repository contains the exact approved artifact and a stable release tag/commit.
- [ ] Zenodo archives that release; record version DOI and unauthenticated download result.
- [ ] Manuscript and supplement use the verified links and accurately state which analyses are reproducible from the deposit.
- [ ] Independent operator's signed report and both authors' final approval are retained outside this ZIP.
