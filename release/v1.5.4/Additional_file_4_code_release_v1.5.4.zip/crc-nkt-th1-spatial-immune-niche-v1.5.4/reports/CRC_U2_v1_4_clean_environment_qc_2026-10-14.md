# v1.4 本地候选包：全新环境复现审计

日期：2026-10-14（Asia/Shanghai）。对象为 `manuscript/CRC_NKT_v11_1/code_release_U2_v1_4_candidate.zip`，SHA256 `cc2c0667231cb98cb65b9761b90427d6b9be234b78e9535556e79031cf399e0b`。本次没有修改原 ZIP，没有向 GitHub/Zenodo 发布，也没有产生 DOI。

## 隔离环境与前置完整性

- 重新解压至 `manuscript/CRC_NKT_v11_1/qc/v11_12_3_clean_env_2026_10_14/bundle`。先以独立 PowerShell 哈希循环核对 manifest 的 158 个文件，零缺失、零长度或 SHA256 差异，然后才执行包内代码。
- 新建 Python 3.14.0 `venv`，`include-system-site-packages = false` 且 `sys.prefix != sys.base_prefix`。Python 临时目录定向至此测试工作区，绕过先前沙箱默认临时目录的权限错误。
- 从包内 `protocol/CRC_U2_requirements_v1_3.txt` 新安装 7 项固定直接依赖：numpy 2.5.1、pandas 2.3.3、scipy 1.18.0、matplotlib 3.11.1、h5py 3.16.0、pyreadr 0.5.6、pytest 9.1.1。`pip check` 返回 `No broken requirements found`。依赖下载采用获准的非沙箱安装；代码测试仍针对重新解压的本地候选包。
- 完整新环境的传递依赖版本为 colorama 0.4.6、contourpy 1.4.0、cycler 0.12.1、fonttools 4.66.1、iniconfig 2.3.1、kiwisolver 1.5.1、packaging 26.3、pillow 12.3.0、pluggy 1.6.0、Pygments 2.21.0、pyparsing 3.3.3、python-dateutil 2.9.0.post0、pytz 2026.5、six 1.17.0、tzdata 2026.5。完整 `pip freeze` 保存于 `protocol/CRC_U2_v1_4_clean_env_win_py314_freeze_2026-10-14.txt`；包内要求文件只固定直接依赖，未来不同时间的传递版本不受它完全约束。

## 实际执行与验收

| 检查 | 结果 | 边界 |
|---|---|---|
| 外层包完整性 | 158 个文件哈希、13 个表行数均通过；嵌套 E4 rc7 的 29 文件哈希通过 | 仅覆盖打包文件，不检查未入包的原始 GEO 数据 |
| 聚焦测试 | U1/U2 8/8；嵌套 E4 6/6，合计 14/14 | 单元/契约测试，不能代表所有数据生成情景 |
| U1 S16 | 从包内 S14/S11 输入重跑；S16a–e、S16g–h 共 7 张 CSV 与稿件对应表逐字节一致 | 这是后验 U1，不能改称预设验证 |
| U1 补图 S11 | 从包内 S16g 生成 PNG，与稿件原图 SHA256 一致 | 图片复现，不验证真实生物身份 |
| U2 试跑 | `G1_D1_S0` 单次 pilot，`PASS/ESTIMABLE`、零错误 | pilot 不属于 9,000 次正式结果 |
| U2 边级抽检 | 4 个状态选取复制、36 张切片，零不一致；容差 1e-10 percentage points | 复用同一生成器输入，不是全模拟独立验证 |
| 保存账本重聚合 | 9,000 正式尝试、72,861 切片、3,600 校准尝试；最大保存值—重算差 1.78e-15 percentage points | 重聚合保存的 section oracle，不是从头重跑全部模拟 |
| G3 分母 | 3,000 尝试、363 NE、2,637 可估、947 个可估 cohort 仅一患者贡献；与 S17a/d 一致 | 947/2,637 = 35.9%，不同于尝试分母的 947/3,000 = 31.6% |
| Figure 5 | 从包内 scenario summary 重新生成 PNG，与原图逐字节一致（SHA256 `f9ab74d193e3088c571123476c94c761ab5fc41e512ceb7a3b411aa9f3562a44`） | 生成的 PDF 哈希因创建时间元数据不同；页面尺寸和渲染像素一致 |

## 结论与未覆盖事项

**PASS — v1.4 候选包在一套全新、系统 site-packages 关闭的 Python 3.14 虚拟环境完成安装和上述最小复现。** 因而 2026-10-13 审校记录中“v1.4 尚未全新环境安装”的状态已被本记录取代。该结论仅针对此 ZIP 的 SHA256 和所列测试，不能扩展成“整篇文章完全可复现”。

尚未执行：9,000 个正式 cohort 从随机种子全量重跑；公开原始 GEO 数据重下载和 E4 全流程重跑；不同操作系统/平台复现；历史 E4 可执行文件的字节级恢复；全部 bulk/ICI/scTCR 旁证分析复现。v1.4 仍是**本地候选**，不是已获作者批准的公开 Release 或永久归档。发布前宜把这次全环境版本清单纳入下一版候选包并重新检查该最终包。
