# Run and verify the v1.5.4 release artifact

Run these commands from a **disposable extracted copy** of the ZIP, not from the archived master. Check the repository and Zenodo record separately for the actual release tag/commit, DOI and public accessibility. No independent external replication is claimed for these exact bytes.

## 1. Identify the exact archive

Record the ZIP SHA-256 supplied alongside the archive. On Windows:

```powershell
Get-FileHash -Algorithm SHA256 .\crc-nkt-th1-spatial-immune-niche-v1.5.4.zip
```

The ZIP should contain a single top-level bundle of files, including `SHA256_MANIFEST.json`, `LICENSE`, `LICENSE_DATA.md`, `CITATION.cff`, this runbook and `VALIDATION_CHECKLIST.md`. Do not include downloaded GEO/Zenodo inputs in any re-upload of this bundle.

## 2. Environment and read-only package verification

Tested target: Windows 11, CPython 3.14.0. The exact prior v1.4 environment freeze is retained for provenance; use `protocol/CRC_U2_requirements_v1_3.txt` for the direct dependencies here. With Python on `PATH` and the current directory set to the extracted bundle root:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r protocol/CRC_U2_requirements_v1_3.txt
.\.venv\Scripts\python.exe -m pip check
.\.venv\Scripts\python.exe -B scripts/verify_crc_U2_S19_v1_5_candidate.py
.\.venv\Scripts\python.exe -B scripts/verify_crc_S20_unique_spot_ledger.py
.\.venv\Scripts\python.exe -B -m pytest -p no:cacheprovider scripts/tests/test_crc_U2_known_truth.py scripts/tests/test_crc_R2k5_U1_pair_estimands.py -q
```

The first verifier checks the whole-bundle SHA manifest, the E4/U1/U2/S19 saved table denominators and a separately coded S19 six-threshold recomputation. The S20 verifier checks four locked CSV byte hashes, all 15,360 S20a keys/counts against S14b, 1,920 statuses against S14a, spot-count bounds and all S20b patient-pair-group summaries. These are *ledger-level* checks; S20 spot identities cannot be recovered from S20a alone.

To check S20's column-level data lock, run the standalone `version_dataset.py` tool used at packaging with `verify --manifest analysis/posthoc_extension_20261015/S20_DATA_LOCK.json --base . --strict`. The package verifiers already require byte-identical CSVs; the additional tool reports which column drifted.

## 3. Optional smoke reruns in fresh output folders

The U1 and U2 commands are listed in `README.md` under “Local smoke test.” Run them only in a disposable extraction; they write new files. A one-replicate U2 pilot establishes that the software starts and completes; it is not a repetition of the 9,000 formal or 3,600 independent-calibration simulations. `scripts/audit_crc_posthoc_pair_threshold_support_20261014.py` writes to its analysis directory and should be run in a **second** disposable copy before comparing its outputs with the archived S19 tables.

The nested E4 `manuscript/CRC_NKT_v11_1/code_release_v11_10_0_rc7/README.md` documents an end-to-end raw-input rerun from public GEO/Zenodo archives. Its input hashes and the historical E4 script-hash caveat must be respected. The raw source archives are not included in this artifact.

## 4. Scope of S20 reproduction

`scripts/audit_v11_12_10_unique_spot_support.py` is the archived **original full-workspace** S20 graph reconstruction. It requires the original public archives, generated per-spot score/annotation tables, the full-workspace `run_valdeolivas_pathology_matched_replication.py` and the frozen section-selection table at the paths encoded in that script. This artifact does **not** make that script portable merely by including it. It is retained for code inspection and provenance; do not claim a clean-room raw-spot S20 rerun from this ZIP alone. To add that claim later, parameterize those inputs, run from fresh public archives in an independent environment, and compare S20a/S20b hashes or documented numerical equivalence.

S20 is post hoc support-only. It preserves failed translations and non-estimable pair/groups. Distinct spots, directed edges, translations and sections are not independent patients. The 30/30 edge gate and published E4 effect are unchanged.

## 5. Before public release

Complete `VALIDATION_CHECKLIST.md`, obtain both authors' approval of the **new** v1.5.4 ZIP hash and rights scope, and independently repeat the clean-environment checks. Only after uploading the exact approved artifact should manuscript availability language be updated with a verified repository URL, release tag/commit and archival DOI. A release of code does not freeze the article text.
